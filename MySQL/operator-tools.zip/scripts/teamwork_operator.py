from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.models.user import User
from app.schemas.user import Actor
from app.services.team_members import utcnow
from scripts.seed_admin import load_operator_context


@dataclass(frozen=True)
class TeamworkApproval:
    approval_id: str
    operation: str
    operator_user_id: int
    operator_principal: str
    database_identity: str
    database_host: str
    database_port: int
    expires_at: datetime
    scope: dict[str, Any]


@contextmanager
def approved_job(approval_id, operation, scope):
    context = load_operator_context()
    verify = getattr(context, "verify_teamwork_approval", None)
    if verify is None:
        raise RuntimeError(
            "The trusted adapter must implement scoped Team Work approvals"
        )
    approval = verify(approval_id, operation, scope)
    if (
        approval.approval_id != approval_id
        or approval.operation != operation
        or approval.scope != scope
        or approval.expires_at <= utcnow()
        or not approval.operator_principal
        or not approval.operator_user_id
    ):
        raise RuntimeError("A current, scoped, mapped operator approval is required")
    with context.open_session() as db, db.begin():
        if (
            db.bind.dialect.name != "mysql"
            or db.bind.url.database != approval.database_identity
            or db.bind.url.host != approval.database_host
            or (db.bind.url.port or 3306) != approval.database_port
        ):
            raise RuntimeError("Operator database does not match approval")
        user = db.get(User, approval.operator_user_id)
        if user is None or not user.is_active or user.needs_registration:
            raise RuntimeError("An active registered operator mapping is required")
        db.info["teamwork_write"] = True
        db.info["teamwork_operator_context"] = context
        actor = Actor(
            user.id, user.user_name, user.token_version, "operator-" + approval_id
        )
        yield db, actor, approval


def record_cleanup_outcome(context, approval, actor, action, team_id, upload_id):
    """Finish only an already committed cleanup intent, even if its grant expired.

    This grants no fresh storage operation. Every new cleanup batch still needs a
    live approval. The outcome is bound to the original actor/database/intent.
    """
    from sqlalchemy import select

    from app.models.audit_log import AuditLog
    from app.services.team_members import write_audit

    if action not in ("staging_cleanup_completed", "staging_cleanup_retry_required"):
        raise RuntimeError("Invalid cleanup outcome")
    with context.open_session() as db, db.begin():
        if (
            db.bind.url.database != approval.database_identity
            or db.bind.url.host != approval.database_host
            or (db.bind.url.port or 3306) != approval.database_port
            or approval.operator_user_id != actor.user_id
        ):
            raise RuntimeError("Outcome database/actor mismatch")
        intent = db.scalar(
            select(AuditLog.id)
            .where(
                AuditLog.action == "staging_cleanup_fenced",
                AuditLog.actor_user_id == actor.user_id,
                AuditLog.team_id == team_id,
                AuditLog.resource_id == upload_id,
                AuditLog.detail["approval_id"].as_string() == approval.approval_id,
            )
            .limit(1)
        )
        if intent is None:
            raise RuntimeError("No committed cleanup intent")
        write_audit(
            db,
            actor_user_id=actor.user_id,
            action=action,
            team_id=team_id,
            resource_id=upload_id,
            detail={"approval_id": approval.approval_id, "intent_audit_id": intent},
        )
