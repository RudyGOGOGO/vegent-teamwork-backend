"""Export the offline HTTP handoff from the actual runtime schema registry."""

import argparse
import json
from pathlib import Path

from app.main import create_app

NOTES = """
## Client protocol notes

All62 new routes require application Bearer authentication; bootstrap remains the existing IAM-only identity route. No new endpoint, token claim, role, restore/enrolment permission or public documentation route is added. IDs are positive safe JSON integers; User IDs, identity Team membership IDs and Project membership IDs are separate domains that can contain the same numeric value. Use the exact named field/path, never infer provenance from the integer.

Team Work uses cursor-only pagination; unknown/duplicate query keys and page= return422. Booleans are literal true/false strings. A page can be shorter than limit because the transport target is1 MiB. Follow has_more/next_cursor until complete. Cursors are signed and route/filter/scope-bound; INVALID_CURSOR422 means restart that traversal. Identity signing-secret rotation invalidates cursors, with up to five-minute cache overlap across environments. Do not turn an invalid cursor or failed fetch into a revoked-all cache update.

Team list pages are fresh per-request observations, not a pinned whole-Team snapshot across requests. Mutable sorting can move an item across a cursor. Before marking an omitted cached Project grey, verify its qualified detail endpoint returns an application PROJECT_NOT_FOUND/NOT_FOUND404; an unknown-route/Gateway404 with a different body is a configuration failure, not revocation; failures/401/403/409/422/503 or incomplete traversal are not evidence that every cached Project was revoked. Never invent a server tombstone for a never-fetched Project. The actual frontend grey-cache implementation/test remains a separate handoff.

### Errors and versions

Known application errors use ErrorEnvelope={error:{code,message,request_id,current?}}, including422; FastAPI detail[] is not emitted. See operation responses for possible statuses/current types. TEAM_ACCESS_DENIED403 includes unknown Team; PROJECT_NOT_FOUND and NOT_FOUND are404. INHERITED_MEMBERSHIP409 includes current.members_href. TEAMWORK_NOT_ENABLED503 is maintenance; TEAMWORK_RECONCILIATION_REQUIRED503 requires audited repair; STAGING_POLICY_REQUIRED/STORAGE_NOT_CONFIGURED/PROVIDER_NOT_CONFIGURED503 require configuration. Other storage/provider/DB503 may be transient. Preserve the draft; version-conflict current is a permitted current projection, not a replacement for the user's edits.

Every mutation requires canonical lowercase UUIDv4 Idempotency-Key. Reuse it only for an uncertain retry of the same normalized method/path/body/query/version. Ordinary replay returns a current authorized projection of the original committed effect; it does not reexecute that effect or return a stored historical body. Access loss remains404/403, and an add later removed can replay404. E61 prepared is its original committed batch count with current session state. E42 replay preserves its original safe sync protocol result/version together. Operation.committed_version describes the original operation, not necessarily the current DTO version. Keys are retained without a24-hour expiry/purge guarantee; do not reuse UUIDs later.

Entity If-Match is a quoted positive integer from the correct version basis in the table. Context If-Match is64 lowercase hex, raw or quoted; it is not an entity version. If-None-Match is supported only on the initial Context manifest without section/cursor, after current authorization; successful unchanged response is304 with no body. A malformed value is422; an out-of-date value is409. Project member operations use root Project.version, not a membership version. Resource lifecycle uses entity_version, not the logical resource version.

### Delete/body matrix

E04 Project-member and E10 comment DELETE consume no body. E24 Category, E31 Project, E38 task, E51 resource and E56 Context-item DELETE require LifecycleBody with confirm:true. Archive/unarchive, seal, prepare and commit endpoints marked empty in the table require {}. Six non-Project DELETE kinds replay204 for the same committed key within an authorized enclosing scope. Project delete remains404 even with the same key; after an uncertain DELETE treat that as probable success, not proof of original nonexistence, and reconcile without resurrecting data.

### TextRef and complete imports

TextValue is {inline,ref}; fields are not plain strings. Long text is a TextRef with kind/object_id/field/resource_version/context_version/utf8_bytes/href. Up to2,048 characters are inline; resolve ref.href with If-Match=context_version and Unicode-character offset/limit, following next_offset until complete. A fragment is at most131,072 characters. This is a transport bound, not a total Context quota. Do not request internal/revision/S3 fields through the static selector.

Context contains all10 own-node sections, including comments/tombstones, not file bytes. The first manifest contains short section pages, not complete collections. Traverse every section and TextRef at one hash; CONTEXT_CHANGED409 restarts the whole collection with bounded jitter/backoff, then pause/preserve the draft after three immediate attempts. Child Context is independent: a root contains child summaries/links, not an automatic recursive import of unselected child work or file bytes.

Persist an immutable local snapshot before requesting an import receipt. Key it by a new local_import_id UUID plus cloud Team/node/contract/context_version, containing all collected metadata/text and local application state. Receipt is an actor-scoped version claim, not server proof of traversal, local application, a cloud snapshot or a backup. Receipt failure does not delete the local snapshot. Import again creates a new snapshot/UUID and preserves the prior one; compare its stored hash to a freshly authorized manifest to detect divergence. Lost local data cannot be restored from a receipt; refetch/import explicitly. No GET imports endpoint or local path/device/session capability is included. Archived/orphaned Project reads/imports are permitted; can_import is independent of write-disabled reasons. The backend protocol collector test is not a browser/local-core integration test.

### PR sync and conversion

Owner supplies repository_ref values out-of-band. Sync failure503 leaves stored PR mirrors readable. Noneligible or unmapped reviewer IDs remain external with reviewer_mapping_complete=false and their external name; reviewers never grant membership. Sync commits one provider page per request, not an atomic repository snapshot. Each continuation requires a fresh key and If-Match equal to the previous returned project_version; on an intervening write re-read the Project version and retry the same continuation with a new request key/version. Explicit external_pr_ids uses one ID per call. Running/continuation means incomplete sync; continue to completed or display partial/interrupted state with per-PR synced_at. A failed page leaves earlier pages; do not label them one coherent provider snapshot. No external PR create/merge/close/diff operation exists.

Conversion is planning->sealed->preparing->ready->committed. Prepare processes at most50 selected plan items, uses the current session version plus its seal-guard cursor and a fresh key, and repeats until ready; commit then publishes once. The cursor is not an offset. No prepared row is visible before publication. Sealed actor/member epoch drift returns409 PLAN_MEMBERS_CHANGED and requires cancel/restart; no reseal endpoint exists. Selected resources must be verified; no implicit children/files or local ownership proof is inferred. New staging requires positive owner-selected expiry values; no default/no-expiry policy is silently chosen. Legacy NULL-expiry staging is quarantined for the reviewed operator sweep.

### Resource capabilities and warnings

Direct S3 capabilities are deliberately excluded from list/Context. Authorization replay reuses its intent/effect and can issue a newly authorized URL/expiry; it is not byte-identical URL replay. Actual owner TTL is required in1–900seconds; the code ceiling is not a selected owner value or immediate revocation. Existing URLs can survive membership/resource/Project loss until expiry. Archive preserves read/download access. Do not proxy file bytes through Lambda or automatically rotate credentials to imply otherwise.

Single PUT handles small files and a declared full-object SHA256 within its physical ceiling. Without declared full-object SHA256, multipart starts at100MiB. Multipart requires each part's lowercase hex checksum_sha256; the signed PUT requires the returned checksum header. The client must include all part checksums in ordered completion XML, inspect the S3 response body even on HTTP200, then request HEAD-based confirmation. Composite SHA256 is not full-file SHA256 and ETag is not a hash substitute. The current S3 object ceiling follows10,000×5GiB parts; no obsolete5TiB product cap is imposed. Live S3/CORS/checksum/slow-completion/expiry acceptance remains pending.

Possible-secret hint (4 patterns only) is warn-only for top-level content/note/context/body/answer/background/goals/description/progress_note and those fields in a typed conversion payload. It is not DLP, does not scan resource bytes and is not persisted. Warning failure cannot veto a committed write. Task/PR/comment changes do not auto-update qualitative progress; parent counts/last activity are own-node only, Team totals count matching roots+children once. Comment totals include tombstones; task totals include archived nondeleted tasks. Category retirement is display-only movement to No Category with retained internal references.

### Required owner handoff and remaining gates

The primary resource workload is small design documents and implementation plans. Prioritize the conditional single-PUT/HEAD-confirm/version/download/retry path; multipart is retained compatibility rather than a new enhancement target.

No Team Work application limiter/429 is implemented. Owner ingress admission and Gateway method/stage throttling are mandatory before pilot reliance, with stricter E17/E42/E18/E19/E57 buckets and evidenced rate/burst values. Gateway method buckets alone are not per-user limits; owner must qualify the actual principal/IP control and429 response shape. Reserved concurrency is not admission. No provisioned throttle or latency guarantee is assumed.

Hand off qualified URL/stage/VPN/DNS requirements, this contract version, actual media types, URL TTL, upload/conversion expiries, repository_ref values and error/admission settings without credentials or capabilities. No configuration-discovery endpoint is added to the frozen62-route inventory. Real AWS/RDS/S3/provider/performance and browser/local-snapshot/grey-cache/retry integration remain explicitly pending. Read the deployment guide and feedback response before pilot qualification.
"""


def export(output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    schema = create_app().openapi()
    (output_dir / "openapi.json").write_text(
        json.dumps(schema, indent=2, ensure_ascii=True) + "\n"
    )
    rows = schema["x-teamwork-header-version-table"]
    lines = [
        "# Vegent Team Work Frontend API Contract",
        "",
        "Generated from runtime schema. Contract: **2.1-r3**. Local candidate only; owner-environment gates remain open. This is an API handoff, not a frontend implementation or second design.",
        "",
        "## Endpoint header/version/body table",
        "",
        "All rows use Bearer. K means a required UUIDv4 Idempotency-Key. Context hash and entity versions are different domains.",
        "",
        "| ID | Method/path | K | If-Match | Body |",
        "| --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        version = row["version"] + (
            "; required"
            if row["if_match_required"]
            else "; conditional"
            if row["id"] == "E11"
            else ""
        )
        lines.append(
            f"| {row['id']} | `{row['method']} {row['path']}` | {'yes' if row['idempotency_key'] else 'no'} | {version} | {row['body']} |"
        )
    lines += [NOTES.strip(), ""]
    (output_dir / "FRONTEND_API_CONTRACT.md").write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(
        description="Export the offline Vegent Team Work HTTP contract"
    )
    parser.add_argument("--output-dir", required=True, type=Path)
    export(parser.parse_args().output_dir)


if __name__ == "__main__":
    main()
