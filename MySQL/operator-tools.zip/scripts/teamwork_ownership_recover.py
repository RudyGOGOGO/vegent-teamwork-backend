import argparse
import json

from sqlalchemy import select

from app.models.team import Team
from app.models.user import User
from app.services.team_members import utcnow
from app.teamwork.models import Project
from app.teamwork.permissions import eligible_members
from app.teamwork.services.common import event, label, touch
from scripts.teamwork_operator import approved_job


def recover_ownership(db, actor, approval, project_id, target_user_id):
    if approval.scope != {"project_id": project_id, "target_user_id": target_user_id}:
        raise RuntimeError("Recovery approval target mismatch")
    node = db.get(Project, project_id)
    if (
        node is None
        or node.node_depth
        or not node.published_at
        or node.status == "deleted"
    ):
        raise RuntimeError("An existing root Project is required")
    list(
        db.scalars(
            select(User)
            .where(
                User.id.in_(
                    sorted({actor.user_id, node.creator_user_id, target_user_id})
                )
            )
            .order_by(User.id)
            .with_for_update()
        )
    )
    team = db.scalar(select(Team).where(Team.id == node.team_id).with_for_update())
    node = db.scalar(
        select(Project)
        .where(Project.id == project_id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    if not team.is_active:
        raise RuntimeError("Team must be active")
    users = {
        u.id: u for member, u, epoch in db.execute(eligible_members(node.id, db=db))
    }
    if node.ownership_state == "assigned" and node.creator_user_id in users:
        raise RuntimeError("Assigned ownership cannot be replaced by recovery")
    if target_user_id not in users:
        raise RuntimeError("Recovery may not enrol a new member")
    old = node.creator_user_id
    node.creator_user_id = target_user_id
    node.creator_name_snapshot = label(users[target_user_id])
    node.ownership_state = "assigned"
    node.ownership_lost_at = None
    node.ownership_updated_at = utcnow()
    touch(node)
    event(
        actor,
        node,
        "project_owner_recovered",
        db=db,
        detail={
            "approval_id": approval.approval_id,
            "old_creator_user_id": old,
            "new_creator_user_id": target_user_id,
            "operator_principal": approval.operator_principal,
        },
    )
    return {"project_id": node.id, "version": node.version}


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Vegent reviewed orphan ownership recovery"
    )
    parser.add_argument("--approval-id", required=True)
    parser.add_argument("--project-id", required=True, type=int)
    parser.add_argument("--target-user-id", required=True, type=int)
    args = parser.parse_args(argv)
    with approved_job(
        args.approval_id,
        "teamwork_ownership_recover",
        {"project_id": args.project_id, "target_user_id": args.target_user_id},
    ) as (
        db,
        actor,
        approval,
    ):
        result = recover_ownership(
            db, actor, approval, args.project_id, args.target_user_id
        )
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(
            "Operator ownership recovery failed; inspect approved redacted evidence"
        ) from None
