import hashlib
import json
import shutil
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

root = Path(__file__).resolve().parents[1]
build = root / "build"
build.mkdir(exist_ok=True)
stage = build / "runtime"
if stage.exists():
    shutil.rmtree(stage)
stage.mkdir()
requirements = subprocess.check_output(
    [
        "uv",
        "export",
        "--locked",
        "--no-dev",
        "--no-emit-project",
        "--format",
        "requirements-txt",
    ],
    cwd=root,
    text=True,
)
(build / "requirements.txt").write_text(requirements)
subprocess.run(
    [
        "uv",
        "pip",
        "install",
        "--python-platform",
        "x86_64-manylinux2014",
        "--python-version",
        "3.12",
        "--only-binary",
        ":all:",
        "--no-installer-metadata",
        "--target",
        str(stage),
        "-r",
        str(build / "requirements.txt"),
    ],
    cwd=root,
    check=True,
)
# Wheels can contain upstream test suites and SDK example credentials. They are
# not runtime dependencies and are excluded while licenses/service models remain.
for path in sorted(stage.rglob("*"), reverse=True):
    if path.is_file() and (
        any(
            part in ("tests", "test", "__pycache__")
            for part in path.relative_to(stage).parts
        )
        or path.name.startswith("test_")
        and path.suffix == ".py"
        or path.name.startswith("examples-")
        and path.suffix == ".json"
    ):
        path.unlink()

for name in ("app", "certs"):
    shutil.copytree(
        root / name, stage / name, ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
    )
for name in ("lambda_handler.py", "security-policy.lock.json", "LICENSE", "NOTICE.md"):
    shutil.copy(root / name, stage / name)
archive = build / "vegent-identity.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as output:
    for path in sorted(stage.rglob("*")):
        if path.is_file():
            info = ZipInfo(
                str(path.relative_to(stage)), date_time=(1980, 1, 1, 0, 0, 0)
            )
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            output.writestr(info, path.read_bytes())
manifest = {
    "artifact": archive.name,
    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "ca_sha256": hashlib.sha256(
        (root / "certs/rds-ca-bundle.pem").read_bytes()
    ).hexdigest(),
    "qualification": "UNVERIFIED_CANDIDATE",
    "policy": json.loads((root / "security-policy.lock.json").read_text()),
}
(build / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest))
