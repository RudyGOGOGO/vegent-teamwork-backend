import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse
import importlib
import json
import os
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Protocol

from sqlalchemy import select

from app.core.security import (
    create_unusable_password_hash,
    hash_proof,
    validate_verizon_email,
)
from app.models.system_config import SystemConfig
from app.models.team import Team
from app.models.team_member import TeamMember
from app.models.user import User
from app.services.auth import revoke_user_sessions
from app.services.team_members import lock_users, utcnow, write_audit


@dataclass(frozen=True)
class ApprovedOperation:
    approval_id: str
    operation: str
    operator_user_id: int | None
    operator_principal: str
    database_identity: str
    target_email: str | None
    expires_at: datetime


class OperatorContext(Protocol):
    def verify_approval(self, approval_id, operation, target_email): ...
    def open_session(self): ...
    def deliver_unlock_proof(self, target_email, token, expires_at): ...


def load_operator_context():
    location = os.environ.get("VEGENT_OPERATOR_ADAPTER", "")
    if ":" not in location:
        raise RuntimeError("An approved operator adapter is required")
    module, factory = location.split(":", 1)
    return getattr(importlib.import_module(module), factory)()


def seed_admin(*, db, approval_id):
    existing = db.scalar(
        select(User).where(User.email == "wei.zhang11@verizon.com").with_for_update()
    )
    if existing:
        team = db.scalar(select(Team).where(Team.team_name == "Verizon"))
        state = db.scalar(
            select(SystemConfig).where(
                SystemConfig.config_key == "admin_password_initialized"
            )
        )
        member = (
            db.scalar(
                select(TeamMember).where(
                    TeamMember.team_id == team.id,
                    TeamMember.user_id == existing.id,
                    TeamMember.status == "active",
                )
            )
            if team
            else None
        )
        if (
            existing.user_name != "wei.zhang11"
            or existing.role != "admin"
            or not existing.is_active
            or not team
            or team.slug != "verizon"
            or team.created_by_user_id != existing.id
            or not member
            or member.team_role != "team_admin"
            or not state
            or json.loads(state.config_value).get("admin_user_id") != existing.id
        ):
            raise RuntimeError("Seed state conflict")
        return existing.id
    if db.scalar(select(User.id).where(User.user_name == "wei.zhang11")) or db.scalar(
        select(Team.id).where(Team.team_name == "Verizon")
    ):
        raise RuntimeError("Seed collision")
    user = User(
        user_name="wei.zhang11",
        email="wei.zhang11@verizon.com",
        password_hash=create_unusable_password_hash(),
        display_name="Wei Zhang",
        bio="",
        role="admin",
        auth_source="password",
        is_active=True,
        needs_registration=True,
        token_version=0,
        preferences="{}",
    )
    db.add(user)
    db.flush()
    team = Team(
        team_name="Verizon",
        slug="verizon",
        description="Root Team for Vegent pilot. System Admin seeded here for verification.",
        created_by_user_id=user.id,
    )
    db.add(team)
    db.flush()
    db.add(
        TeamMember(
            team_id=team.id,
            user_id=user.id,
            team_role="team_admin",
            status="active",
            invited_by_user_id=user.id,
            joined_at=utcnow(),
        )
    )
    db.add_all(
        [
            SystemConfig(
                config_key="admin_password_initialized",
                config_value=json.dumps({"completed": False, "admin_user_id": user.id}),
                updated_by=user.id,
            ),
            SystemConfig(
                config_key="identity_admin_guard", config_value="{}", updated_by=user.id
            ),
        ]
    )
    write_audit(
        db,
        actor_user_id=user.id,
        action="team_created",
        team_id=team.id,
        detail={"seed": True, "approval_id": approval_id},
    )
    return user.id


def recover_admin(*, db, approval_id, operator_user_id, email, operator_principal):
    email = validate_verizon_email(email)
    guard = db.scalar(
        select(SystemConfig)
        .where(SystemConfig.config_key == "identity_admin_guard")
        .with_for_update()
    )
    if not guard:
        raise RuntimeError("Missing administrator guard")
    admins = db.scalars(select(User.id).where(User.role == "admin")).all()
    rows = lock_users(db, operator_user_id, *admins)
    if operator_user_id not in rows:
        raise RuntimeError("Operator mapping is required")
    if db.scalar(select(User.id).where(User.email == email)):
        raise RuntimeError("Recovery identity collision")
    for uid in admins:
        revoke_user_sessions(rows[uid], db=db)
    token = secrets.token_urlsafe(32)
    expires = utcnow() + timedelta(hours=24)
    user = User(
        user_name=email.split("@")[0][:36] + "-" + secrets.token_hex(6),
        email=email,
        password_hash=create_unusable_password_hash(),
        role="admin",
        auth_source="password",
        is_active=True,
        needs_registration=True,
        token_version=1,
        unlock_token_hash=hash_proof("unlock", token),
        unlock_expires_at=expires,
        preferences="{}",
    )
    db.add(user)
    db.flush()
    write_audit(
        db,
        actor_user_id=operator_user_id,
        action="operator_admin_recovered",
        target_user_id=user.id,
        detail={"approval_id": approval_id, "operator_principal": operator_principal},
    )
    return user.id, token, expires


def main(argv=None):
    parser = argparse.ArgumentParser(description="Vegent audited operator jobs")
    parser.add_argument("operation", choices=["seed", "recover-admin"])
    parser.add_argument("--approval-id", required=True)
    parser.add_argument("--operator-user-id", type=int)
    parser.add_argument("--email")
    args = parser.parse_args(argv)
    context = load_operator_context()
    approval = context.verify_approval(args.approval_id, args.operation, args.email)
    if (
        approval.approval_id != args.approval_id
        or approval.operation != args.operation
        or approval.target_email != args.email
        or approval.expires_at <= utcnow()
        or not approval.operator_principal
        or not approval.database_identity
    ):
        raise RuntimeError("Approval validation failed")
    if args.operation == "recover-admin" and (
        not args.email
        or not args.operator_user_id
        or approval.operator_user_id != args.operator_user_id
    ):
        raise RuntimeError("Recovery approval mismatch")
    with context.open_session() as db, db.begin():
        if db.bind.url.database != approval.database_identity:
            raise RuntimeError("Database approval mismatch")
        if args.operation == "seed":
            seed_admin(db=db, approval_id=approval.approval_id)
        else:
            result = recover_admin(
                db=db,
                approval_id=approval.approval_id,
                operator_user_id=approval.operator_user_id,
                email=args.email,
                operator_principal=approval.operator_principal,
            )
    if args.operation == "recover-admin":
        context.deliver_unlock_proof(args.email, result[1], result[2])
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(
            "Operator job failed; inspect approved redacted evidence"
        ) from None
