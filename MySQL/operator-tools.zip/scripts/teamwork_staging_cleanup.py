import argparse
import json
import os
from datetime import timedelta

from botocore.exceptions import ClientError
from sqlalchemy import and_, or_, select
from sqlalchemy.orm import aliased

from app.services.team_members import utcnow, write_audit
from app.teamwork.config import storage_config
from app.teamwork.models import (
    Project,
    ProjectConversionSession,
    ProjectResource,
    ProjectResourceVersion,
    ResourceUpload,
)
from app.teamwork.services.storage import s3_client
from scripts.teamwork_operator import approved_job, record_cleanup_outcome


def cleanup(approval_id, *, after_id=0, limit=50, conversion_after_id=0):
    try:
        quiescence = int(os.environ["VEGENT_TEAMWORK_CLEANUP_QUIESCENCE_SECONDS"])
    except (KeyError, ValueError):
        raise RuntimeError(
            "An explicit approved quiescence policy is required"
        ) from None
    if quiescence < 0 or limit <= 0 or after_id < 0 or conversion_after_id < 0:
        raise RuntimeError("Invalid cleanup policy/work unit")
    legacy_age = os.environ.get("VEGENT_TEAMWORK_LEGACY_STAGING_MAX_AGE_SECONDS")
    legacy_age = int(legacy_age) if legacy_age is not None else None
    if legacy_age is not None and legacy_age <= 0:
        raise RuntimeError("Invalid legacy staging age policy")
    cfg = storage_config()
    intents = []
    with approved_job(
        approval_id,
        "teamwork_staging_cleanup",
        {"kind": "expired_staging_cleanup", "bucket": cfg.bucket, "prefix": cfg.prefix},
    ) as (db, actor, approval):
        context = db.info.get("teamwork_operator_context")
        if context is None:
            raise RuntimeError("A captured verified operator context is required")
        if legacy_age is None and db.scalar(
            select(ResourceUpload.id)
            .where(
                ResourceUpload.expires_at.is_(None),
                ResourceUpload.status.in_(
                    [
                        "pending",
                        "uploading",
                        "verifying",
                        "awaiting_completion",
                        "verified",
                    ]
                ),
            )
            .limit(1)
        ):
            raise RuntimeError(
                "Legacy NULL-expiry staging requires an explicit age policy"
            )
        terminal_sessions = ("committed", "cancelled", "expired", "failed")
        if legacy_age is None and db.scalar(
            select(ProjectConversionSession.id)
            .where(
                ProjectConversionSession.expires_at.is_(None),
                ProjectConversionSession.status.not_in(terminal_sessions),
            )
            .limit(1)
        ):
            raise RuntimeError(
                "Legacy NULL-expiry staging requires an explicit age policy"
            )
        conversion_candidates = list(
            db.scalars(
                select(ProjectConversionSession)
                .where(
                    ProjectConversionSession.id > conversion_after_id,
                    ProjectConversionSession.status.not_in(terminal_sessions),
                    or_(
                        ProjectConversionSession.expires_at <= utcnow(),
                        and_(
                            ProjectConversionSession.expires_at.is_(None),
                            ProjectConversionSession.updated_at
                            <= utcnow() - timedelta(seconds=legacy_age),
                        )
                        if legacy_age
                        else False,
                    ),
                )
                .order_by(ProjectConversionSession.id)
                .limit(limit)
            )
        )
        legacy = (
            and_(
                ResourceUpload.expires_at.is_(None),
                ResourceUpload.updated_at <= utcnow() - timedelta(seconds=legacy_age),
            )
            if legacy_age
            else False
        )
        rows = db.scalars(
            select(ResourceUpload)
            .where(
                ResourceUpload.id > after_id,
                ResourceUpload.status != "published",
                or_(
                    ResourceUpload.status.in_(["cancelled", "failed", "expired"]),
                    ResourceUpload.expires_at <= utcnow(),
                    legacy,
                ),
            )
            .order_by(ResourceUpload.id)
            .limit(limit)
        ).all()
        from app.models.team import Team

        for tid in sorted(
            {row.team_id for row in rows}
            | {row.team_id for row in conversion_candidates}
        ):
            db.scalar(select(Team).where(Team.id == tid).with_for_update())
        expired_conversions = 0
        for candidate in conversion_candidates:
            session = db.scalar(
                select(ProjectConversionSession)
                .where(ProjectConversionSession.id == candidate.id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            eligible = (
                session.expires_at is not None
                and session.expires_at <= utcnow()
                or session.expires_at is None
                and legacy_age is not None
                and session.updated_at <= utcnow() - timedelta(seconds=legacy_age)
            )
            if session.status not in terminal_sessions and eligible:
                session.status = "expired"
                session.version += 1
                session.updated_at = utcnow()
                expired_conversions += 1
                write_audit(
                    db,
                    actor_user_id=actor.user_id,
                    action="conversion_staging_expired",
                    team_id=session.team_id,
                    resource_id=session.id,
                    detail={
                        "approval_id": approval_id,
                        "legacy_max_age_seconds": legacy_age,
                    },
                )
        next_conversion_id = (
            conversion_candidates[-1].id
            if len(conversion_candidates) == limit
            else None
        )
        for candidate in rows:
            session = (
                db.scalar(
                    select(ProjectConversionSession)
                    .where(ProjectConversionSession.id == candidate.conversion_id)
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
                if candidate.conversion_id
                else None
            )
            row = db.scalar(
                select(ResourceUpload)
                .where(ResourceUpload.id == candidate.id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            if row.status == "published":
                continue
            terminal = row.status in ("cancelled", "failed", "expired")
            expired = row.expires_at is not None and row.expires_at <= utcnow()
            legacy_expired = (
                row.expires_at is None
                and legacy_age is not None
                and row.updated_at <= utcnow() - timedelta(seconds=legacy_age)
            )
            if not (terminal or expired or legacy_expired):
                continue
            if session and session.status == "committed":
                continue
            if (
                row.last_url_expires_at
                and row.last_url_expires_at + timedelta(seconds=quiescence) > utcnow()
            ):
                continue
            root = aliased(Project)
            referenced = (
                select(ProjectResourceVersion.id)
                .join(
                    ProjectResource,
                    ProjectResource.id == ProjectResourceVersion.resource_id,
                )
                .join(Project, Project.id == ProjectResource.project_id)
                .outerjoin(root, Project.parent_project_id == root.id)
                .where(
                    ProjectResourceVersion.s3_object_key == row.object_key,
                    Project.published_at.is_not(None),
                    or_(
                        Project.parent_project_id.is_(None),
                        root.published_at.is_not(None),
                    ),
                )
            )
            if db.scalar(referenced):
                continue
            if not row.object_key.startswith(cfg.prefix + "/uploads/"):
                raise RuntimeError("Unexpected staging key scope")
            row.status = "expired"
            row.version += 1
            if session:
                session.status = "expired"
                session.version += 1
            intents.append((row.id, row.team_id, row.object_key, row.multipart_id))
            write_audit(
                db,
                actor_user_id=actor.user_id,
                action="staging_cleanup_fenced",
                team_id=row.team_id,
                resource_id=row.id,
                detail={
                    "approval_id": approval_id,
                    "legacy_max_age_seconds": legacy_age,
                },
            )
        next_id = rows[-1].id if len(rows) == limit else None
    client = s3_client(cfg) if intents else None
    removed = 0
    failed = 0
    for uid, team_id, key, mid in intents:
        try:
            if mid:
                try:
                    client.abort_multipart_upload(
                        Bucket=cfg.bucket, Key=key, UploadId=mid
                    )
                except ClientError as exc:
                    if exc.response.get("Error", {}).get("Code") != "NoSuchUpload":
                        raise
            # Every paginator page is inspected; subsequent runs rediscover late arrivals.
            for batch in client.get_paginator("list_multipart_uploads").paginate(
                Bucket=cfg.bucket, Prefix=key
            ):
                for item in batch.get("Uploads", []):
                    if item["Key"] == key:
                        client.abort_multipart_upload(
                            Bucket=cfg.bucket, Key=key, UploadId=item["UploadId"]
                        )
            for batch in client.get_paginator("list_object_versions").paginate(
                Bucket=cfg.bucket, Prefix=key
            ):
                for item in batch.get("Versions", []) + batch.get("DeleteMarkers", []):
                    if item["Key"] == key:
                        client.delete_object(
                            Bucket=cfg.bucket, Key=key, VersionId=item["VersionId"]
                        )
            client.delete_object(Bucket=cfg.bucket, Key=key)
            removed += 1
            outcome = "staging_cleanup_completed"
        except Exception:
            failed += 1
            outcome = "staging_cleanup_retry_required"
        record_cleanup_outcome(context, approval, actor, outcome, team_id, uid)
    return {
        "intents_processed": removed,
        "retry_required": failed,
        "conversion_intents_expired": expired_conversions,
        "next_conversion_after_id": next_conversion_id,
        "next_after_id": next_id,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Vegent approved expired staging cleanup"
    )
    parser.add_argument("--approval-id", required=True)
    parser.add_argument("--after-id", type=int, default=0)
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--conversion-after-id", type=int, default=0)
    args = parser.parse_args(argv)
    print(
        json.dumps(
            cleanup(
                args.approval_id,
                after_id=args.after_id,
                limit=args.limit,
                conversion_after_id=args.conversion_after_id,
            )
        )
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(
            "Operator cleanup failed; inspect approved redacted evidence"
        ) from None
