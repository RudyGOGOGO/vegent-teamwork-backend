import argparse
import json

from sqlalchemy import or_, select

from app.models.audit_log import AuditLog
from app.models.team import Team
from app.models.team_member import TeamMember
from app.models.user import User
from app.schemas.user import Actor
from app.services.team_members import write_audit
from app.teamwork.models import ProjectMember
from app.teamwork.services.cascade import MembershipRemoval, cascade_team_removal
from scripts.teamwork_operator import approved_job


def reconcile(db, actor, approval, *, after_id=0, limit=50):
    rows = db.execute(
        select(ProjectMember, TeamMember, User)
        .join(TeamMember, TeamMember.id == ProjectMember.team_membership_id)
        .join(User, User.id == ProjectMember.user_id)
        .where(
            ProjectMember.status == "active",
            ProjectMember.id > after_id,
            or_(
                TeamMember.status != "active",
                User.is_active.is_(False),
                TeamMember.user_id != ProjectMember.user_id,
                TeamMember.team_id != ProjectMember.team_id,
            ),
        )
        .order_by(ProjectMember.id)
        .limit(limit)
    ).all()
    total = 0
    for member, epoch, user in rows:
        if epoch.user_id != member.user_id or epoch.team_id != member.team_id:
            raise RuntimeError("Grant integrity requires operator inspection")
        if epoch.status == "removed":
            time = epoch.removed_at
            source_id = epoch.removed_by_user_id
        else:
            evidence = db.scalar(
                select(AuditLog)
                .where(
                    AuditLog.target_user_id == user.id,
                    AuditLog.action == "user_deactivated",
                )
                .order_by(AuditLog.id.desc())
                .limit(1)
            )
            if evidence is None:
                raise RuntimeError("Missing membership-loss provenance")
            time = evidence.created_at
            source_id = evidence.actor_user_id
        source = db.get(User, source_id)
        if source is None or time is None:
            raise RuntimeError("Missing actual removal actor/time")
        db.scalar(select(User).where(User.id == user.id).with_for_update())
        db.scalar(select(Team).where(Team.id == member.team_id).with_for_update())
        source_actor = Actor(
            source.id, source.user_name, source.token_version, "reconcile-provenance"
        )
        result = cascade_team_removal(
            MembershipRemoval(
                source_actor,
                member.team_id,
                member.user_id,
                member.team_membership_id,
                time,
            ),
            db=db,
        )
        total += result.memberships
        write_audit(
            db,
            actor_user_id=actor.user_id,
            action="teamwork_reconciled",
            team_id=member.team_id,
            target_user_id=member.user_id,
            detail={
                "approval_id": approval.approval_id,
                "source_actor_user_id": source.id,
                "source_membership_id": epoch.id,
                "memberships_repaired": result.memberships,
            },
        )
    return {
        "repaired": total,
        "next_after_id": rows[-1][0].id if len(rows) == limit else None,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Vegent audited membership reconciliation"
    )
    parser.add_argument("--approval-id", required=True)
    parser.add_argument("--after-id", type=int, default=0)
    parser.add_argument("--limit", type=int, default=50)
    args = parser.parse_args(argv)
    if args.limit <= 0 or args.after_id < 0:
        raise RuntimeError("Invalid work cursor")
    with approved_job(
        args.approval_id, "teamwork_reconcile", {"kind": "membership_reconciliation"}
    ) as (db, actor, approval):
        result = reconcile(
            db, actor, approval, after_id=args.after_id, limit=args.limit
        )
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(
            "Operator reconciliation failed; inspect approved redacted evidence"
        ) from None
