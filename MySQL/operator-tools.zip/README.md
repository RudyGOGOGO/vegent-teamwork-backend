# Vegent Identity + Team Work Service

One Python3.12 Lambda extends the existing private identity service with the approved `2.1-r3` Team Work contract, using the same MySQL database. Source, tests and build intermediates live here. The compact delivery, generated OpenAPI, deployment guide, preserved requirements and verification results are in `/Users/weizhang/Desktop/VegentUpstream/TeamWork/`.

## Local development

Run `uv sync --locked`, `make package`, then `make verify`. The sequential MySQL tests reset only disposable databases `vegent_identity` and `vegent_teamwork_test` at127.0.0.1:13316 on MySQL8.4. Do not redirect them to a pilot/production database or run multiple test workers against the same fixture. SQLite cannot verify these constraints/locks. A dedicated local container can be started with `docker run --name vegent-identity-test -e MYSQL_ALLOW_EMPTY_PASSWORD=yes -e MYSQL_DATABASE=vegent_identity -p 127.0.0.1:13316:3306 -d mysql:8.4`; create only the second disposable database there if absent. An existing stopped fixture uses `docker start vegent-identity-test`.

`make verify` covers local identity/Team Work regressions and package boundaries. The separate `tests/performance/test_bcrypt_lambda.py` deliberately fails closed without its real owner-environment adapter and explicit benchmark flag. Local cost4 fixtures do not qualify the pinned candidate cost12 for Lambda. No mocked test certifies owner IAM, VPN, S3 behavior or runtime capacity.

## Runtime and operators

Handler `lambda_handler.handler`; Python3.12 / AL2023 / x86_64. Deploy the new combined candidate rather than modifying the preserved auth-only ZIP. Keep `VEGENT_TEAMWORK_ENABLED=false` until the compatible schema has been installed and verified by the owner. It controls both the new routes and atomic identity-removal cascade. The selected profile has no global-admin private Project bypass or operator enrolment.

The identity schema remains seven tables; eight additive Team Work revisions add21 tables after the verified source predecessor0007. Runtime imports/cold starts never migrate/seed. The review SQL must not be executed in addition to the Alembic chain. Operator jobs require the owner's trusted adapter, real mapped actor, current scoped authorization and exact database name/host/port. No credentials or permissive adapter are shipped.

See the delivered deployment guide for exact environment/secret fields, DB chain, direct multipart protocol, owner adapter contract, scoped cleanup/recovery, maintenance and rollback. Retain additive history and object versions; no unapproved purge/restore route/job is implemented. All production resource creation, routing, database-instance creation, seed/deployment and environment qualification remain owner-managed. No commit/push is performed by this task.


Implementation feedback remediation adds complete offline OpenAPI/error/client-contract export (`uv run python -m scripts.export_teamwork_contract --output-dir <existing-delivery-Design-directory>`), SQL paging/aggregates, parent-first child archive, token-count mention retention/current labels, accurate prepare replay, eligible reviewer maps, stale-epoch readiness denial and reviewed staging cleanup. New staging requires explicit positive expiry settings. S3 capability TTL must be owner-selected within1–900seconds, with residual native-presign exposure. This is mitigation, not immediate revocation; real admission/RDS/S3/provider/client qualification remains open. The detailed English checklist response is in the TeamWork Verification directory.

Primary resource workload is small design documents and implementation plans. Validate ordinary conditional single PUT, versioned metadata and authorized short-lived download/retry first; multipart is retained compatibility, not a new enhancement target.
