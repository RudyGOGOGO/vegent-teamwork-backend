from alembic import op

revision = "tw_003"
down_revision = "tw_002"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE project_progress_events (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n project_version BIGINT NOT NULL,\n event_type VARCHAR(20) NOT NULL,\n actor_user_id INT NOT NULL,\n actor_name_snapshot VARCHAR(100) NOT NULL,\n old_status VARCHAR(20) NOT NULL,\n new_status VARCHAR(20) NOT NULL,\n old_note LONGTEXT NOT NULL,\n new_note LONGTEXT NOT NULL,\n created_at DATETIME(6) NOT NULL,\n KEY idx_progress_history(project_id,created_at,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n FOREIGN KEY(actor_user_id) REFERENCES users(id),\n CHECK(event_type IN ('progress_changed','archived','unarchived')),\n CHECK(old_status IN ('not_started','in_progress','blocked','in_review','completed','on_hold')),\n CHECK(new_status IN ('not_started','in_progress','blocked','in_review','completed','on_hold'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE project_activity_events (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n event_type VARCHAR(50) NOT NULL,\n actor_user_id INT NOT NULL,\n actor_name_snapshot VARCHAR(100) NOT NULL,\n object_type VARCHAR(40) NOT NULL,\n object_id BIGINT NULL,\n object_version BIGINT NULL,\n safe_detail JSON NOT NULL,\n created_at DATETIME(6) NOT NULL,\n KEY idx_project_activity(project_id,created_at,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n FOREIGN KEY(actor_user_id) REFERENCES users(id)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError("Additive schema is retained; roll back the application alias.")
