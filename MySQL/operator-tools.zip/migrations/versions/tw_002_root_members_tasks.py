from alembic import op

revision = "tw_002"
down_revision = "tw_001"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE project_members (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n team_id BIGINT NOT NULL,\n root_depth_guard TINYINT NOT NULL DEFAULT 0,\n user_id INT NOT NULL,\n team_membership_id BIGINT NOT NULL,\n status VARCHAR(20) NOT NULL DEFAULT 'active',\n added_by_user_id INT NOT NULL,\n added_by_name_snapshot VARCHAR(100) NOT NULL,\n joined_at DATETIME(6) NOT NULL,\n removed_by_user_id INT NULL,\n removed_at DATETIME(6) NULL,\n removal_reason VARCHAR(40) NULL,\n active_user_id INT GENERATED ALWAYS AS\n   (CASE WHEN status='active' THEN user_id ELSE NULL END) STORED,\n UNIQUE KEY uq_project_active_member(project_id,active_user_id),\n KEY idx_project_member_cascade(team_id,user_id,status,project_id,id),\n KEY idx_project_member_epoch(team_membership_id,status,project_id),\n FOREIGN KEY(project_id,team_id,root_depth_guard) REFERENCES projects(id,team_id,node_depth),\n FOREIGN KEY(user_id) REFERENCES users(id),\n FOREIGN KEY(team_membership_id) REFERENCES team_members(id),\n FOREIGN KEY(added_by_user_id) REFERENCES users(id),\n FOREIGN KEY(removed_by_user_id) REFERENCES users(id),\n CHECK(root_depth_guard=0),\n CHECK(status IN ('active','removed')),\n CHECK((status='active' AND removed_at IS NULL AND removed_by_user_id IS NULL AND removal_reason IS NULL)\n    OR (status='removed' AND removed_at IS NOT NULL AND removed_by_user_id IS NOT NULL AND removal_reason IS NOT NULL))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE project_tasks (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n title VARCHAR(255) NOT NULL,\n description LONGTEXT NOT NULL,\n status VARCHAR(20) NOT NULL DEFAULT 'todo',\n lifecycle_status VARCHAR(20) NOT NULL DEFAULT 'active',\n created_by_user_id INT NOT NULL,\n created_by_name_snapshot VARCHAR(100) NOT NULL,\n driver_user_id INT NOT NULL,\n driver_name_snapshot VARCHAR(100) NOT NULL,\n assignee_user_id INT NULL,\n assignee_name_snapshot VARCHAR(100) NULL,\n version BIGINT NOT NULL DEFAULT 1,\n created_at DATETIME(6) NOT NULL,\n updated_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_task_project(project_id,id),\n KEY idx_task_counts(project_id,lifecycle_status,status,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n FOREIGN KEY(created_by_user_id) REFERENCES users(id),\n FOREIGN KEY(driver_user_id) REFERENCES users(id),\n FOREIGN KEY(assignee_user_id) REFERENCES users(id),\n CHECK(status IN ('todo','in_progress','blocked','done')),\n CHECK(lifecycle_status IN ('active','archived','deleted')),\n CHECK(version>=1)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError("Additive schema is retained; roll back the application alias.")
