from alembic import op

revision = "tw_006"
down_revision = "tw_005"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE project_comments (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n task_id BIGINT NULL,\n pr_id BIGINT NULL,\n resource_id BIGINT NULL,\n parent_comment_id BIGINT NULL,\n author_user_id INT NOT NULL,\n author_project_member_id BIGINT NOT NULL,\n author_name_snapshot VARCHAR(100) NOT NULL,\n author_role_snapshot VARCHAR(20) NOT NULL,\n content TEXT NOT NULL,\n status VARCHAR(20) NOT NULL DEFAULT 'active',\n version BIGINT NOT NULL DEFAULT 1,\n created_at DATETIME(6) NOT NULL,\n updated_at DATETIME(6) NOT NULL,\n edited_at DATETIME(6) NULL,\n deleted_at DATETIME(6) NULL,\n deleted_by_user_id INT NULL,\n UNIQUE KEY uq_comment_project(project_id,id),\n KEY idx_comment_page(project_id,created_at,id),\n KEY idx_comment_author(project_id,author_user_id,created_at,id),\n KEY idx_comment_parent(project_id,parent_comment_id,created_at,id),\n KEY idx_comment_task(project_id,task_id,created_at,id),\n KEY idx_comment_pr(project_id,pr_id,created_at,id),\n KEY idx_comment_resource(project_id,resource_id,created_at,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n FOREIGN KEY(author_user_id) REFERENCES users(id),\n FOREIGN KEY(author_project_member_id) REFERENCES project_members(id),\n FOREIGN KEY(deleted_by_user_id) REFERENCES users(id),\n FOREIGN KEY(project_id,parent_comment_id) REFERENCES project_comments(project_id,id),\n FOREIGN KEY(project_id,task_id) REFERENCES project_tasks(project_id,id),\n FOREIGN KEY(project_id,pr_id) REFERENCES project_prs(project_id,id),\n FOREIGN KEY(project_id,resource_id) REFERENCES project_resources(project_id,id),\n CHECK(status IN ('active','edited','deleted')),\n CHECK(author_role_snapshot IN ('creator','member')),\n CHECK(CHAR_LENGTH(content) BETWEEN 1 AND 4000 AND OCTET_LENGTH(content)<=16384),\n CHECK((task_id IS NOT NULL)+(pr_id IS NOT NULL)+(resource_id IS NOT NULL)<=1),\n CHECK((status='deleted' AND deleted_at IS NOT NULL AND deleted_by_user_id IS NOT NULL)\n    OR (status<>'deleted' AND deleted_at IS NULL AND deleted_by_user_id IS NULL)),\n CHECK(version>=1)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE comment_mentions (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n comment_id BIGINT NOT NULL,\n mentioned_user_id INT NOT NULL,\n mentioned_name_snapshot VARCHAR(100) NOT NULL,\n status VARCHAR(20) NOT NULL DEFAULT 'active',\n changed_version BIGINT NOT NULL,\n created_at DATETIME(6) NOT NULL,\n updated_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_comment_user_mention(comment_id,mentioned_user_id),\n KEY idx_mentions_me(mentioned_user_id,status,comment_id),\n FOREIGN KEY(comment_id) REFERENCES project_comments(id),\n FOREIGN KEY(mentioned_user_id) REFERENCES users(id),\n CHECK(status IN ('active','removed'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE project_comment_revisions (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n comment_id BIGINT NOT NULL,\n version BIGINT NOT NULL,\n actor_user_id INT NOT NULL,\n status VARCHAR(20) NOT NULL,\n content TEXT NOT NULL,\n mentions_snapshot JSON NOT NULL,\n created_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_comment_revision(comment_id,version),\n FOREIGN KEY(comment_id) REFERENCES project_comments(id),\n FOREIGN KEY(actor_user_id) REFERENCES users(id),\n CHECK(status IN ('active','edited','deleted'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError("Additive schema is retained; roll back the application alias.")
