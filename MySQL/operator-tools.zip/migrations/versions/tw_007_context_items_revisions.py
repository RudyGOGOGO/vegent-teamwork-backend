from alembic import op

revision = "tw_007"
down_revision = "tw_006"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE project_context_items (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n kind VARCHAR(20) NOT NULL,\n title VARCHAR(255) NOT NULL,\n context_text LONGTEXT NOT NULL,\n body LONGTEXT NOT NULL,\n answer LONGTEXT NULL,\n state VARCHAR(20) NOT NULL,\n author_user_id INT NOT NULL,\n author_name_snapshot VARCHAR(100) NOT NULL,\n decided_at DATETIME(6) NULL,\n version BIGINT NOT NULL DEFAULT 1,\n deleted_at DATETIME(6) NULL,\n created_at DATETIME(6) NOT NULL,\n updated_at DATETIME(6) NOT NULL,\n KEY idx_context_items(project_id,kind,state,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n FOREIGN KEY(author_user_id) REFERENCES users(id),\n CHECK((kind='decision' AND state IN ('proposed','accepted','superseded','withdrawn'))\n    OR (kind='open_question' AND state IN ('open','answered','closed')))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE project_context_item_revisions (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n item_id BIGINT NOT NULL,\n version BIGINT NOT NULL,\n actor_user_id INT NOT NULL,\n snapshot JSON NOT NULL,\n created_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_context_item_revision(item_id,version),\n FOREIGN KEY(item_id) REFERENCES project_context_items(id),\n FOREIGN KEY(actor_user_id) REFERENCES users(id)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError("Additive schema is retained; roll back the application alias.")
