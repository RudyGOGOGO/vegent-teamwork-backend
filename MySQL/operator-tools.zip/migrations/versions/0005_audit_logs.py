from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE audit_logs (\n  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  team_id BIGINT NULL,\n  actor_user_id INT NULL,\n  action VARCHAR(50) NOT NULL,\n  target_user_id INT NULL,\n  target_email VARCHAR(100) NULL,\n  resource_type VARCHAR(50) NULL,\n  resource_id BIGINT NULL,\n  detail JSON NULL,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  KEY idx_audit_team (team_id,created_at,id),\n  KEY idx_audit_actor (actor_user_id,created_at),\n  KEY idx_audit_target (target_user_id,created_at),\n  CONSTRAINT fk_audit_team FOREIGN KEY (team_id) REFERENCES teams(id),\n  CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_id) REFERENCES users(id),\n  CONSTRAINT fk_audit_target FOREIGN KEY (target_user_id) REFERENCES users(id),\n  CONSTRAINT ck_audit_actor CHECK (\n    actor_user_id IS NOT NULL OR action IN ('login_failed','auth_rate_limited'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
