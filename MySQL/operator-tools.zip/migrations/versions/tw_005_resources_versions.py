from alembic import op

revision = "tw_005"
down_revision = "tw_004"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE project_resources (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n name LONGTEXT NOT NULL,\n status VARCHAR(20) NOT NULL DEFAULT 'active',\n created_by_user_id INT NOT NULL,\n current_version BIGINT NOT NULL DEFAULT 0,\n entity_version BIGINT NOT NULL DEFAULT 1,\n created_at DATETIME(6) NOT NULL,\n updated_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_resource_project(project_id,id),\n KEY idx_resource_list(project_id,status,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n FOREIGN KEY(created_by_user_id) REFERENCES users(id),\n CHECK(status IN ('active','archived','deleted'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE project_resource_versions (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n resource_id BIGINT NOT NULL,\n resource_version BIGINT NOT NULL,\n name LONGTEXT NOT NULL,\n media_type VARCHAR(255) NOT NULL,\n size_bytes BIGINT NOT NULL,\n checksum_algorithm VARCHAR(32) NULL,\n checksum_type VARCHAR(20) NULL,\n checksum_value TEXT CHARACTER SET ascii COLLATE ascii_bin NULL,\n uploaded_by_user_id INT NOT NULL,\n uploader_name_snapshot VARCHAR(100) NOT NULL,\n s3_object_key VARCHAR(1024) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,\n s3_version_id VARCHAR(1024) CHARACTER SET ascii COLLATE ascii_bin NULL,\n created_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_resource_version(resource_id,resource_version),\n FOREIGN KEY(resource_id) REFERENCES project_resources(id),\n FOREIGN KEY(uploaded_by_user_id) REFERENCES users(id),\n CHECK(size_bytes>=0),\n CHECK(checksum_type IS NULL OR checksum_type IN ('FULL_OBJECT','COMPOSITE'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError("Additive schema is retained; roll back the application alias.")
