from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE invitations (\n  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  team_id BIGINT NOT NULL,\n  invitee_name VARCHAR(100) NOT NULL,\n  invitee_email VARCHAR(100) COLLATE utf8mb4_bin NOT NULL,\n  invitee_bio TEXT NULL,\n  team_role VARCHAR(20) NOT NULL,\n  invited_by_user_id INT NOT NULL,\n  status VARCHAR(20) NOT NULL DEFAULT 'pending',\n  invite_token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,\n  expires_at DATETIME(6) NOT NULL,\n  claimed_user_id INT NULL,\n  claimed_at DATETIME(6) NULL,\n  pending_email VARCHAR(100) COLLATE utf8mb4_bin GENERATED ALWAYS AS\n    (CASE WHEN status='pending' THEN invitee_email ELSE NULL END) STORED,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)\n    ON UPDATE CURRENT_TIMESTAMP(6),\n  UNIQUE KEY uq_invitation_hash (invite_token_hash),\n  UNIQUE KEY uq_team_pending_email (team_id,pending_email),\n  KEY idx_invitation_team_email (team_id,invitee_email,status),\n  KEY idx_invitation_inviter (invited_by_user_id,created_at),\n  KEY idx_invitation_status (team_id,status,created_at,id),\n  KEY idx_invitation_expiry (status,expires_at),\n  KEY idx_invitation_claimed (claimed_user_id),\n  CONSTRAINT fk_invitation_team FOREIGN KEY (team_id) REFERENCES teams(id),\n  CONSTRAINT fk_invitation_inviter FOREIGN KEY (invited_by_user_id) REFERENCES users(id),\n  CONSTRAINT fk_invitation_claimed FOREIGN KEY (claimed_user_id) REFERENCES users(id),\n  CONSTRAINT ck_invitation_role CHECK (team_role IN ('team_admin','team_member')),\n  CONSTRAINT ck_invitation_status CHECK (status IN ('pending','claimed','revoked','expired')),\n  CONSTRAINT ck_invitation_email CHECK (\n    CHAR_LENGTH(invitee_email) > 0 AND\n    BINARY invitee_email = BINARY LOWER(TRIM(invitee_email))),\n  CONSTRAINT ck_invitation_claim CHECK (\n    (status='claimed' AND claimed_user_id IS NOT NULL AND claimed_at IS NOT NULL) OR\n    (status<>'claimed' AND claimed_user_id IS NULL AND claimed_at IS NULL))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
