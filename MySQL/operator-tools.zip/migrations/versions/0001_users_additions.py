from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


DDL = "CREATE TABLE users (\n  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  user_name VARCHAR(50) NOT NULL,\n  password_hash VARCHAR(256) NOT NULL,\n  email VARCHAR(100) COLLATE utf8mb4_bin NOT NULL,\n  git_info JSON NULL,\n  is_active BOOLEAN NOT NULL DEFAULT TRUE,\n  role VARCHAR(20) NOT NULL DEFAULT 'user',\n  auth_source VARCHAR(20) NOT NULL DEFAULT 'password',\n  preferences VARCHAR(4096) NOT NULL DEFAULT '{}',\n  display_name VARCHAR(100) NULL,\n  bio TEXT NULL,\n  needs_registration BOOLEAN NOT NULL DEFAULT FALSE,\n  token_version INT NOT NULL DEFAULT 0,\n  unlock_token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,\n  unlock_expires_at DATETIME(6) NULL,\n  unlock_used_at DATETIME(6) NULL,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)\n    ON UPDATE CURRENT_TIMESTAMP(6),\n  UNIQUE KEY uq_users_user_name (user_name),\n  UNIQUE KEY uq_users_email_lower (email),\n  UNIQUE KEY uq_users_unlock_hash (unlock_token_hash),\n  KEY idx_users_admin (role,is_active),\n  CONSTRAINT ck_users_role CHECK (role IN ('admin','user')),\n  CONSTRAINT ck_users_version CHECK (token_version >= 0),\n  CONSTRAINT ck_users_email CHECK (\n    CHAR_LENGTH(email) > 0 AND BINARY email = BINARY LOWER(TRIM(email)))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"


def upgrade():
    import os

    from sqlalchemy import inspect, text

    connection = op.get_bind()
    metadata = inspect(connection)
    if "users" not in metadata.get_table_names():
        op.execute(DDL)
        return
    if os.environ.get("VEGENT_APPROVE_EXISTING_USERS_IMPORT") != "true":
        raise RuntimeError("Existing users require explicit reviewed import approval")
    invalid = connection.scalar(
        text(
            "SELECT COUNT(*) FROM users WHERE email IS NULL OR TRIM(email) = '' OR CHAR_LENGTH(email) > 100 OR role NOT IN ('admin','user')"
        )
    )
    duplicates = connection.execute(
        text(
            "SELECT LOWER(TRIM(email)) FROM users GROUP BY LOWER(TRIM(email)) HAVING COUNT(*) > 1 LIMIT 1"
        )
    ).first()
    if invalid or duplicates:
        raise RuntimeError("Existing user identities require owner resolution")
    connection.execute(text("UPDATE users SET email = LOWER(TRIM(email))"))
    connection.execute(
        text("ALTER TABLE users MODIFY email VARCHAR(100) COLLATE utf8mb4_bin NOT NULL")
    )
    columns = {column["name"] for column in metadata.get_columns("users")}
    additions = {
        "display_name": "VARCHAR(100) NULL",
        "bio": "TEXT NULL",
        "needs_registration": "BOOLEAN NOT NULL DEFAULT FALSE",
        "token_version": "INT NOT NULL DEFAULT 0",
        "unlock_token_hash": "CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL",
        "unlock_expires_at": "DATETIME(6) NULL",
        "unlock_used_at": "DATETIME(6) NULL",
    }
    for name, definition in additions.items():
        if name not in columns:
            connection.execute(
                text(f"ALTER TABLE users ADD COLUMN {name} {definition}")
            )
    indexes = {item["name"] for item in inspect(connection).get_indexes("users")}
    for name, fields in {
        "uq_users_user_name": "user_name",
        "uq_users_email_lower": "email",
        "uq_users_unlock_hash": "unlock_token_hash",
        "idx_users_admin": "role,is_active",
    }.items():
        if name not in indexes:
            unique = "UNIQUE" if name.startswith("uq_") else ""
            connection.execute(
                text(f"ALTER TABLE users ADD {unique} INDEX {name} ({fields})")
            )
    checks = {
        item["name"] for item in inspect(connection).get_check_constraints("users")
    }
    definitions = {
        "ck_users_role": "role IN ('admin','user')",
        "ck_users_version": "token_version >= 0",
        "ck_users_email": "CHAR_LENGTH(email) > 0 AND BINARY email = BINARY LOWER(TRIM(email))",
    }
    for name, expression in definitions.items():
        if name not in checks:
            connection.execute(
                text(f"ALTER TABLE users ADD CONSTRAINT {name} CHECK ({expression})")
            )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
