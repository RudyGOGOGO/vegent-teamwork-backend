from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE refresh_tokens (\n  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  user_id INT NOT NULL,\n  token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,\n  token_version INT NOT NULL,\n  device_id VARCHAR(100) NULL,\n  expires_at DATETIME(6) NOT NULL,\n  revoked BOOLEAN NOT NULL DEFAULT FALSE,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  UNIQUE KEY uq_refresh_hash (token_hash),\n  KEY idx_refresh_user (user_id,revoked,expires_at),\n  CONSTRAINT fk_refresh_user FOREIGN KEY (user_id) REFERENCES users(id),\n  CONSTRAINT ck_refresh_version CHECK (token_version >= 0)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
