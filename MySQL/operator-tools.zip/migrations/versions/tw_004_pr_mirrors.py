from alembic import op

revision = "tw_004"
down_revision = "tw_003"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE project_prs (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n project_id BIGINT NOT NULL,\n provider VARCHAR(20) NOT NULL,\n repository_ref VARCHAR(255) NOT NULL,\n external_pr_id VARCHAR(255) NOT NULL,\n title LONGTEXT NOT NULL,\n url LONGTEXT NOT NULL,\n branch LONGTEXT NOT NULL,\n status VARCHAR(20) NOT NULL,\n reviewer_mapping_complete BOOLEAN NOT NULL DEFAULT FALSE,\n synced_at DATETIME(6) NOT NULL,\n version BIGINT NOT NULL DEFAULT 1,\n UNIQUE KEY uq_pr_external(project_id,provider,repository_ref,external_pr_id),\n UNIQUE KEY uq_pr_project(project_id,id),\n KEY idx_pr_counts(project_id,status,id),\n FOREIGN KEY(project_id) REFERENCES projects(id),\n CHECK(provider IN ('github','stash')),\n CHECK(status IN ('open','merged','closed'))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )
    op.execute(
        "CREATE TABLE project_pr_reviewers (\n id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n pr_id BIGINT NOT NULL,\n external_reviewer_id VARCHAR(255) NOT NULL,\n user_id INT NULL,\n display_name VARCHAR(255) NOT NULL,\n is_current BOOLEAN NOT NULL DEFAULT TRUE,\n updated_at DATETIME(6) NOT NULL,\n UNIQUE KEY uq_pr_reviewer(pr_id,external_reviewer_id),\n KEY idx_review_me(user_id,pr_id),\n FOREIGN KEY(pr_id) REFERENCES project_prs(id),\n FOREIGN KEY(user_id) REFERENCES users(id)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError("Additive schema is retained; roll back the application alias.")
