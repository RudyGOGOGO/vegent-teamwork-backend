from enum import Enum


class TeamRole(str, Enum):
    team_admin = "team_admin"
    team_member = "team_member"


class GlobalRole(str, Enum):
    admin = "admin"
    user = "user"


class TeamAction(str, Enum):
    view = "view"
    edit = "edit"
    deactivate = "deactivate"
    view_members = "view_members"
    view_invitations = "view_invitations"
    view_history = "view_history"
    invite = "invite"
    revoke = "revoke"
    resend = "resend"
    change_role = "change_role"
    remove_member = "remove_member"
    accept = "accept"
