from pydantic import Field, SecretStr, field_validator

from app.schemas.auth import DTO
from app.schemas.roles import TeamRole


class TeamCreate(DTO):
    team_name: str = Field(min_length=2, max_length=100)
    description: str | None = Field(default=None, max_length=4000)

    @field_validator("team_name", mode="before")
    @classmethod
    def trim(cls, value):
        return value.strip() if isinstance(value, str) else value


class TeamUpdate(DTO):
    team_name: str | None = Field(default=None, min_length=2, max_length=100)
    description: str | None = Field(default=None, max_length=4000)

    @field_validator("team_name", mode="before")
    @classmethod
    def name(cls, value):
        if value is None:
            raise ValueError("Invalid name")
        return value.strip() if isinstance(value, str) else value


class InvitationCreate(DTO):
    invitee_name: str = Field(min_length=1, max_length=100)
    invitee_bio: str | None = Field(default=None, max_length=4000)
    team_role: TeamRole
    invitee_email: str = Field(min_length=1, max_length=100)


class InvitationAccept(DTO):
    invite_token: SecretStr = Field(min_length=1, max_length=256)


class TeamRoleUpdate(DTO):
    team_role: TeamRole


class PageQuery(DTO):
    page: int = Field(default=1, ge=1)
    limit: int = Field(default=20, ge=1, le=100)
