from pydantic import BaseModel, ConfigDict, EmailStr, Field, SecretStr, field_validator


class ServiceError(Exception):
    def __init__(self, code: str, status_code: int):
        self.code, self.status_code = code, status_code


class DTO(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EmailRequest(DTO):
    email: EmailStr = Field(max_length=100)

    @field_validator("email", mode="before")
    @classmethod
    def normalize(cls, value):
        return value.strip().lower() if isinstance(value, str) else value


class AccountStatusRequest(EmailRequest):
    pass


class LoginRequest(EmailRequest):
    password: SecretStr = Field(max_length=1000)


class RegisterRequest(LoginRequest):
    invite_token: SecretStr = Field(min_length=1, max_length=256)


class UnlockCompletionRequest(EmailRequest):
    new_password: SecretStr = Field(max_length=1000)
    unlock_token: SecretStr = Field(min_length=1, max_length=256)


class RefreshRequest(DTO):
    refresh_token: SecretStr = Field(min_length=1, max_length=256)


class LogoutRequest(RefreshRequest):
    pass


class BootstrapRequest(DTO):
    password: SecretStr = Field(max_length=1000)


class AccessToken(DTO):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 3600


class Tokens(AccessToken):
    refresh_token: str
    refresh_expires_in: int = 2592000


class AccountStatusResponse(DTO):
    status: str


class HealthResponse(DTO):
    status: str
    service: str = "vegent-identity"
