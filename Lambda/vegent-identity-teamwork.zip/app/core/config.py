import json
import os
import threading
import time
from pathlib import Path

import boto3
from botocore.config import Config
from pydantic import BaseModel, ConfigDict, SecretStr

from app.schemas.auth import ServiceError


class IdentitySecret(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    SECRET_KEY: SecretStr
    ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    REFRESH_TOKEN_EXPIRE_DAYS: int
    DATABASE_HOST: str
    DATABASE_PORT: int
    DATABASE_NAME: str
    DATABASE_USER: str
    DATABASE_PASSWORD: SecretStr
    INVITE_TOKEN_PEPPER: SecretStr
    UNLOCK_TOKEN_PEPPER: SecretStr


_cache = None
_expires = 0.0
_lock = threading.Lock()


def get_identity_secret(*, force_refresh=False):
    global _cache, _expires
    with _lock:
        if _cache is not None and not force_refresh and time.monotonic() < _expires:
            return _cache
        try:
            client = boto3.client(
                "secretsmanager",
                region_name=os.environ["AWS_REGION"],
                config=Config(
                    connect_timeout=1, read_timeout=2, retries={"max_attempts": 1}
                ),
            )
            raw = client.get_secret_value(
                SecretId=os.environ["VEGENT_IDENTITY_SECRET_ID"]
            )
            value = IdentitySecret.model_validate_json(raw["SecretString"])
            if (
                value.ALGORITHM != "HS256"
                or value.ACCESS_TOKEN_EXPIRE_MINUTES != 60
                or value.REFRESH_TOKEN_EXPIRE_DAYS != 30
            ):
                raise ValueError()
            if (
                min(
                    len(value.SECRET_KEY.get_secret_value().encode()),
                    len(value.INVITE_TOKEN_PEPPER.get_secret_value().encode()),
                    len(value.UNLOCK_TOKEN_PEPPER.get_secret_value().encode()),
                )
                < 32
            ):
                raise ValueError()
        except Exception:
            raise ServiceError("SERVICE_UNAVAILABLE", 503) from None
        _cache, _expires = value, time.monotonic() + 300
        return value


def get_bcrypt_cost():
    try:
        data = json.loads(
            (Path(__file__).parents[2] / "security-policy.lock.json").read_text()
        )
        cost = data["bcrypt_cost"]
        if type(cost) is not int or not 4 <= cost <= 16:
            raise ValueError()
        return cost
    except Exception:
        raise ServiceError("SERVICE_UNAVAILABLE", 503) from None
