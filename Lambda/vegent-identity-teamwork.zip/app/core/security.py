import hashlib
import os
import secrets
from datetime import datetime, timezone
from functools import lru_cache

import bcrypt
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import EmailStr, TypeAdapter

from app.core.config import get_bcrypt_cost, get_identity_secret
from app.db.session import get_session_factory
from app.models.user import User
from app.schemas.auth import ServiceError
from app.schemas.user import Actor

bearer = HTTPBearer(auto_error=False)


def normalize_email(email: str) -> str:
    try:
        return str(TypeAdapter(EmailStr).validate_python(email.strip().lower()))
    except Exception:
        raise ServiceError("VALIDATION_ERROR", 422) from None


def validate_verizon_email(email: str) -> str:
    email = normalize_email(email)
    if len(email) > 100 or not email.endswith("@verizon.com"):
        raise ServiceError("VALIDATION_ERROR", 422)
    return email


def validate_password(password: str) -> None:
    if len(password) < 12 or len(password.encode("utf-8")) > 72 or "\0" in password:
        raise ServiceError("VALIDATION_ERROR", 422)


def get_password_hash(password: str) -> str:
    validate_password(password)
    return bcrypt.hashpw(
        password.encode(), bcrypt.gensalt(rounds=get_bcrypt_cost())
    ).decode()


def create_unusable_password_hash() -> str:
    return get_password_hash(secrets.token_urlsafe(32))


def verify_password(plain_password: str, password_hash: str) -> bool:
    try:
        if len(plain_password.encode()) > 72:
            return False
        return bcrypt.checkpw(plain_password.encode(), password_hash.encode())
    except (ValueError, TypeError):
        return False


def hash_proof(kind: str, token: str) -> str:
    pepper = ""
    if kind != "refresh":
        value = get_identity_secret()
        pepper = getattr(
            value, "INVITE_TOKEN_PEPPER" if kind == "invite" else "UNLOCK_TOKEN_PEPPER"
        ).get_secret_value()
    return hashlib.sha256((pepper + token).encode()).hexdigest()


def create_access_token(claims: dict) -> str:
    return jwt.encode(
        claims, get_identity_secret().SECRET_KEY.get_secret_value(), algorithm="HS256"
    )


def verify_token(token: str, *, now=None) -> dict:
    try:
        claims = jwt.decode(
            token,
            get_identity_secret().SECRET_KEY.get_secret_value(),
            algorithms=["HS256"],
            issuer="vegent-identity",
            audience="vegent",
            options={
                "require_exp": True,
                "require_iat": True,
                "require_sub": True,
                "leeway": 30,
            },
        )
        if not all(
            key in claims
            for key in ("sub", "user_id", "token_version", "iat", "exp", "iss", "aud")
        ):
            raise ValueError()
        if claims["iss"] != "vegent-identity" or claims["aud"] != "vegent":
            raise ValueError()
        for key in ("user_id", "token_version", "iat", "exp"):
            if type(claims.get(key)) is not int:
                raise ValueError()
        if (
            claims["user_id"] <= 0
            or claims["token_version"] < 0
            or claims["exp"] - claims["iat"] != 3600
            or claims["iat"] > int(datetime.now(timezone.utc).timestamp()) + 30
            or "scope" in claims
            or "token_use" in claims
        ):
            raise ValueError()
        return claims
    except (JWTError, ValueError, KeyError, TypeError):
        raise ServiceError("INVALID_TOKEN", 401) from None


def assert_current_actor(actor: Actor, *, db) -> User:
    user = db.get(User, actor.user_id, populate_existing=True)
    if (
        not user
        or not user.is_active
        or user.needs_registration
        or user.user_name != actor.user_name
        or user.token_version != actor.token_version
    ):
        raise ServiceError("INVALID_TOKEN", 401)
    return user


def get_current_user(
    request: Request, credentials: HTTPAuthorizationCredentials = Depends(bearer)
) -> Actor:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise ServiceError("INVALID_TOKEN", 401)
    claims = verify_token(credentials.credentials)
    actor = Actor(
        claims["user_id"],
        claims["sub"],
        claims["token_version"],
        getattr(request.state, "request_id", ""),
    )
    with get_session_factory()() as db:
        assert_current_actor(actor, db=db)
    return actor


def require_system_admin(actor: Actor, *, db) -> User:
    user = assert_current_actor(actor, db=db)
    if user.role != "admin":
        raise ServiceError("FORBIDDEN", 403)
    return user


def get_admin_user(actor: Actor = Depends(get_current_user)) -> Actor:
    with get_session_factory()() as db:
        require_system_admin(actor, db=db)
    return actor


def verify_bootstrap_iam(request: Request) -> str:
    try:
        if os.environ.get("VEGENT_BOOTSTRAP_ENABLED", "false").lower() != "true":
            raise ValueError()
        ctx = request.scope["aws.event"]["requestContext"]
        role = os.environ["VEGENT_BOOTSTRAP_ROLE_ARN"]
        parts = role.split(":")
        if parts[2] != "iam" or parts[5] != "role/vegent-identity-bootstrap-admin":
            raise ValueError()
        identity = ctx["identity"]["userArn"]
        expected = f"arn:{parts[1]}:sts::{parts[4]}:assumed-role/vegent-identity-bootstrap-admin/"
        if (
            not identity.startswith(expected)
            or not identity[len(expected) :]
            or ctx["apiId"] != os.environ["VEGENT_API_ID"]
            or ctx["stage"] != os.environ["VEGENT_API_STAGE"]
        ):
            raise ValueError()
        return identity
    except (KeyError, ValueError, TypeError, IndexError):
        raise ServiceError("FORBIDDEN", 403) from None


@lru_cache(maxsize=4)
def dummy_password_hash(cost):
    return bcrypt.hashpw(
        secrets.token_urlsafe(32).encode(), bcrypt.gensalt(rounds=cost)
    ).decode()
