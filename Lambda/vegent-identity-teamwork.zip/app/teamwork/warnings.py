import re

_PATTERN = re.compile(
    r"(?i)(?:password|secret|token|api[_-]?key)\s*[:=]|-----BEGIN [A-Z ]*PRIVATE KEY-----|\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|https?://[^\s/]+:[^\s/]+@"
)


def discussion_warnings(text: str):
    try:
        if _PATTERN.search(text):
            return [
                {
                    "type": "possible_secret",
                    "message": "Possible-secret hint (4 patterns only): review this shared text before sharing.",
                }
            ]
        return []
    except Exception:
        return [
            {
                "type": "validator_unavailable",
                "message": "Secret-pattern checking was unavailable; review before sharing.",
            }
        ]


def safe_discussion_warnings(text: str):
    messages = {
        "possible_secret": "Possible-secret hint (4 patterns only): review this shared text before sharing.",
        "validator_unavailable": "Secret-pattern checking was unavailable; review before sharing.",
    }
    try:
        kinds = {item["type"] for item in discussion_warnings(text)}
        if not kinds <= messages.keys():
            raise ValueError()
        return [{"type": kind, "message": messages[kind]} for kind in sorted(kinds)]
    except Exception:
        return [
            {
                "type": "validator_unavailable",
                "message": messages["validator_unavailable"],
            }
        ]


def shared_text(body):
    """Only manually supplied shared fields; never load resources or private sources."""
    fields = {
        "content",
        "note",
        "context",
        "body",
        "answer",
        "background",
        "goals",
        "description",
        "progress_note",
    }
    values = [
        value
        for name, value in body.items()
        if name in fields and isinstance(value, str)
    ]
    if isinstance(body.get("payload"), dict):
        values.append(shared_text(body["payload"]))
    return "\n".join(values)
