from contextlib import contextmanager

from sqlalchemy import event
from sqlalchemy.orm import Session

from app.db.session import get_engine, get_session_factory
from app.teamwork.errors import fail


@contextmanager
def write_session():
    with get_session_factory()() as db, db.begin():
        yield db


@contextmanager
def read_projection_session():
    with (
        get_engine()
        .connect()
        .execution_options(isolation_level="REPEATABLE READ") as connection
    ):
        with Session(connection, expire_on_commit=False) as db, db.begin():
            yield db


@event.listens_for(Session, "after_flush")
def enforce_safe_issued_ids(db, context):
    if not db.info.get("teamwork_write"):
        return
    for row in db.new:
        if row.__class__.__module__.startswith("app.teamwork.models"):
            value = getattr(row, "id", None)
            if value is not None and not 1 <= value <= 2**53 - 1:
                fail("IDENTIFIER_CAPACITY", 409)
