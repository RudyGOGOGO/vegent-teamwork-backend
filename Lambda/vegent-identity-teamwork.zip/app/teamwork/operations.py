from dataclasses import dataclass
from uuid import UUID

from sqlalchemy import select

from app.services.team_members import utcnow
from app.teamwork.cursors import digest
from app.teamwork.errors import fail
from app.teamwork.models import TeamworkMutationKey


@dataclass
class OperationInput:
    key: str
    method_path: str
    body: dict
    expected_version: str | None = None


@dataclass
class OperationState:
    row: TeamworkMutationKey
    replayed: bool


def valid_uuid(value):
    try:
        parsed = UUID(value)
        if parsed.version != 4 or str(parsed) != value:
            raise ValueError()
        return value
    except (ValueError, TypeError, AttributeError):
        fail("VALIDATION_ERROR", 422)


def begin_operation(actor, key, request, *, db):
    valid_uuid(key)
    signature = digest(
        {
            "path": request.method_path,
            "body": request.body,
            "version": request.expected_version,
        }
    )
    row = db.scalar(
        select(TeamworkMutationKey)
        .where(
            TeamworkMutationKey.actor_user_id == actor.user_id,
            TeamworkMutationKey.operation_key == key,
        )
        .with_for_update()
    )
    if row is not None:
        if row.request_hash != signature:
            fail("IDEMPOTENCY_CONFLICT", 409)
        return OperationState(row, bool(row.response_ref))
    row = TeamworkMutationKey(
        actor_user_id=actor.user_id,
        operation_key=key,
        request_hash=signature,
        method_path=request.method_path,
        response_ref={},
        response_status=200,
        created_at=utcnow(),
    )
    db.add(row)
    db.flush()
    return OperationState(row, False)


def complete_operation(state, ref, *, db):
    if not state.replayed:
        state.row.response_ref = ref
        state.row.response_status = ref.get("status", 200)
        db.flush()


def operation_view(state):
    return {
        "idempotency_replayed": state.replayed,
        "committed_version": state.row.response_ref.get("version"),
    }


def expected_version(value):
    try:
        if value is None or not value.startswith('"') or not value.endswith('"'):
            raise ValueError()
        number = int(value[1:-1])
        if number <= 0 or value != f'"{number}"':
            raise ValueError()
        return number
    except (ValueError, TypeError):
        fail("INVALID_VERSION", 422)
