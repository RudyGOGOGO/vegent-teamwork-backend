import json
import os
from dataclasses import dataclass

from app.teamwork.errors import fail


@dataclass(frozen=True)
class StorageConfig:
    bucket: str
    prefix: str
    ttl: int
    media_types: frozenset[str]
    region: str


def storage_config() -> StorageConfig:
    try:
        bucket = os.environ["VEGENT_TEAMWORK_S3_BUCKET"]
        prefix = os.environ["VEGENT_TEAMWORK_S3_PREFIX"].strip("/")
        ttl = int(os.environ["VEGENT_TEAMWORK_URL_TTL_SECONDS"])
        types = json.loads(os.environ["VEGENT_TEAMWORK_ALLOWED_MEDIA_TYPES"])
        region = os.environ["AWS_REGION"]
        if (
            not prefix.isascii()
            or len(prefix) > 979
            or "\x00" in prefix
            or not bucket
            or not prefix
            or ttl <= 0
            or ttl > 900
            or not isinstance(types, list)
            or not types
            or not all(isinstance(x, str) and "/" in x for x in types)
        ):
            raise ValueError()
        return StorageConfig(bucket, prefix, ttl, frozenset(types), region)
    except (ValueError, KeyError, TypeError):
        fail("STORAGE_NOT_CONFIGURED", 503)


def expiry_seconds(kind: str):
    value = os.environ.get("VEGENT_TEAMWORK_" + kind.upper() + "_EXPIRY_SECONDS")
    if value is None:
        fail("STAGING_POLICY_REQUIRED", 503)
    try:
        number = int(value)
        if number <= 0:
            raise ValueError()
        return number
    except ValueError:
        fail("SERVICE_NOT_CONFIGURED", 503)
