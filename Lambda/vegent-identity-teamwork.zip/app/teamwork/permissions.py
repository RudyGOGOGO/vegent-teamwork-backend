from dataclasses import dataclass
from enum import StrEnum

from sqlalchemy import and_, select
from sqlalchemy.orm import load_only

from app.models.team import Team
from app.models.team_member import TeamMember
from app.models.user import User
from app.teamwork.errors import fail
from app.teamwork.models import Project, ProjectMember


class Action(StrEnum):
    READ = "read"
    IMPORT = "import"
    CREATE_SUBPROJECT = "create_subproject"
    EDIT_INFO = "edit_info"
    MANAGE_MEMBERS = "manage_members"
    TRANSFER_OWNERSHIP = "transfer_ownership"
    WRITE_WORK = "write_work"
    ARCHIVE = "archive"
    UNARCHIVE = "unarchive"
    DELETE = "delete"


@dataclass
class TeamGrant:
    team: Team
    membership: TeamMember
    user: User


@dataclass
class ProjectGrant:
    team: Team
    membership: TeamMember
    user: User
    node: Project
    root: Project
    project_member: ProjectMember
    orphaned: bool
    lifecycle: str

    @property
    def creator(self):
        return not self.orphaned and self.root.creator_user_id == self.user.id


def eligible_members(root_id: int, *, db):
    return (
        select(ProjectMember, User, TeamMember)
        .join(
            TeamMember,
            and_(
                TeamMember.id == ProjectMember.team_membership_id,
                TeamMember.team_id == ProjectMember.team_id,
                TeamMember.user_id == ProjectMember.user_id,
            ),
        )
        .join(User, User.id == ProjectMember.user_id)
        .options(
            load_only(
                User.id,
                User.user_name,
                User.email,
                User.display_name,
                User.is_active,
                raiseload=True,
            )
        )
        .where(
            ProjectMember.project_id.in_(root_id)
            if isinstance(root_id, (list, tuple, set))
            else ProjectMember.project_id == root_id,
            ProjectMember.status == "active",
            TeamMember.status == "active",
            User.is_active.is_(True),
        )
        .order_by(ProjectMember.id)
    )


def require_team(actor, team_id: int, *, db) -> TeamGrant:
    write = bool(db.info.get("teamwork_write"))
    cache_key = (actor.user_id, actor.user_name, actor.token_version, team_id)
    cached = (
        db.info.get("teamwork_team_grants", {}).get(cache_key) if not write else None
    )
    if cached is not None:
        return cached
    user = db.scalar(
        select(User).where(User.id == actor.user_id).with_for_update(read=not write)
    )
    if (
        user is None
        or not user.is_active
        or user.needs_registration
        or user.user_name != actor.user_name
        or user.token_version != actor.token_version
    ):
        fail("INVALID_TOKEN", 401)
    team = db.scalar(
        select(Team).where(Team.id == team_id).with_for_update(read=not write)
    )
    member = db.scalar(
        select(TeamMember).where(
            TeamMember.team_id == team_id,
            TeamMember.user_id == user.id,
            TeamMember.status == "active",
        )
    )
    if team is None or not team.is_active or member is None:
        fail("TEAM_ACCESS_DENIED", 403)
    checked = db.info.setdefault("teamwork_reconciliation_checked", set())
    if team_id not in checked:
        from sqlalchemy import or_

        stale = db.scalar(
            select(ProjectMember.id)
            .join(TeamMember, TeamMember.id == ProjectMember.team_membership_id)
            .where(
                ProjectMember.team_id == team_id,
                ProjectMember.status == "active",
                or_(
                    TeamMember.status != "active",
                    TeamMember.team_id != ProjectMember.team_id,
                    TeamMember.user_id != ProjectMember.user_id,
                ),
            )
            .limit(1)
        )
        if stale is not None:
            fail("TEAMWORK_RECONCILIATION_REQUIRED", 503)
        checked.add(team_id)
    grant = TeamGrant(team, member, user)
    if not write:
        db.info.setdefault("teamwork_team_grants", {})[cache_key] = grant
    return grant


def resolve_root(node_id: int, *, db):
    node = db.get(Project, node_id)
    if node is None:
        fail("PROJECT_NOT_FOUND", 404)
    root = db.get(Project, node.parent_project_id) if node.parent_project_id else node
    if root is None:
        fail("PROJECT_NOT_FOUND", 404)
    return root


def require_project(
    actor, team_id: int, node_id: int, action=Action.READ, *, db
) -> ProjectGrant:
    team = require_team(actor, team_id, db=db)
    node = db.get(
        Project, node_id, populate_existing=bool(db.info.get("teamwork_write"))
    )
    if node is None or node.team_id != team_id:
        fail("PROJECT_NOT_FOUND", 404)
    root = resolve_root(node_id, db=db)
    write = bool(db.info.get("teamwork_write"))
    db.scalar(
        select(Project).where(Project.id == root.id).with_for_update(read=not write)
    )
    if node.id != root.id:
        db.scalar(
            select(Project).where(Project.id == node.id).with_for_update(read=not write)
        )
    if (
        not node.published_at
        or not root.published_at
        or node.status == "deleted"
        or root.status == "deleted"
    ):
        fail("PROJECT_NOT_FOUND", 404)
    snapshots = db.info.setdefault("eligible_snapshot_rows", {})
    grants = snapshots.get(root.id) if not write else None
    if grants is None:
        grants = list(db.execute(eligible_members(root.id, db=db)))
        if not write:
            snapshots[root.id] = grants
    own = next((m for m, u, t in grants if u.id == actor.user_id), None)
    if own is None:
        fail("PROJECT_NOT_FOUND", 404)
    orphan = root.ownership_state == "unassigned" or not any(
        u.id == root.creator_user_id for m, u, t in grants
    )
    lifecycle = "archived" if "archived" in (root.status, node.status) else "active"
    result = ProjectGrant(
        team.team, team.membership, team.user, node, root, own, orphan, lifecycle
    )
    action = Action(action)
    if action in (Action.READ, Action.IMPORT):
        return result
    if node.node_depth and action in (Action.MANAGE_MEMBERS, Action.TRANSFER_OWNERSHIP):
        fail(
            "INHERITED_MEMBERSHIP",
            409,
            current={
                "members_href": f"/api/teams/{team_id}/projects/{root.id}/members"
            },
        )
    if action == Action.TRANSFER_OWNERSHIP:
        if node.node_depth:
            fail("INHERITED_MEMBERSHIP", 409)
        if not (result.creator or orphan and team.membership.team_role == "team_admin"):
            fail("FORBIDDEN", 403)
        if lifecycle == "archived" and not orphan:
            fail("PROJECT_ARCHIVED", 409)
        return result
    if orphan:
        fail("OWNERSHIP_REQUIRED", 409)
    if (
        action
        in (Action.MANAGE_MEMBERS, Action.ARCHIVE, Action.UNARCHIVE, Action.DELETE)
        and not result.creator
    ):
        fail("FORBIDDEN", 403)
    if action == Action.MANAGE_MEMBERS and node.node_depth:
        fail("INHERITED_MEMBERSHIP", 409)
    if action == Action.UNARCHIVE and node.node_depth and root.status == "archived":
        fail("PARENT_ARCHIVED", 409)
    if (
        action not in (Action.ARCHIVE, Action.UNARCHIVE, Action.DELETE)
        and lifecycle == "archived"
    ):
        fail("PROJECT_ARCHIVED", 409)
    if action == Action.CREATE_SUBPROJECT and node.node_depth:
        fail("NOT_PARENT_PROJECT", 422)
    return result


def require_eligible(grant, user_id: int, *, db):
    row = next(
        (
            m
            for m, u, t in db.execute(eligible_members(grant.root.id, db=db))
            if u.id == user_id
        ),
        None,
    )
    if row is None:
        fail("INELIGIBLE_MEMBER", 422)
    return row
