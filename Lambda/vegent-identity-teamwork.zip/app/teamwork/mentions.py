import re
import unicodedata
from dataclasses import dataclass

from app.teamwork.errors import fail
from app.teamwork.permissions import eligible_members

_TOKEN = re.compile(r"@\[([^\[\]\r\n]{1,100})\]\(user:([1-9][0-9]*)\)")


@dataclass(frozen=True)
class MentionToken:
    start: int
    end: int
    user_id: int
    name: str


def parse_mentions(content: str):
    result = []
    index = 0
    while True:
        index = content.find("@[", index)
        if index < 0:
            break
        slash = index - 1
        while slash >= 0 and content[slash] == "\\":
            slash -= 1
        if (index - slash - 1) % 2:
            index += 2
            continue
        match = _TOKEN.match(content, index)
        if not match or int(match[2]) > 2**53 - 1:
            fail("INVALID_MENTION", 422)
        result.append(MentionToken(index, match.end(), int(match[2]), match[1]))
        index = match.end()
    if len(result) > 20 or len({t.user_id for t in result}) > 10:
        fail("INVALID_MENTION", 422)
    return result


def canonical_label(user):
    for value in (user.display_name or "", user.user_name):
        value = (
            unicodedata.normalize("NFC", value)
            .replace("[", "［")
            .replace("]", "］")
            .replace("\r", " ")
            .replace("\n", " ")
            .strip()
        )
        if 1 <= len(value) <= 100:
            return value
    fail("SERVICE_INTEGRITY", 503)


def validate_content(content):
    content = unicodedata.normalize(
        "NFC", content.replace("\r\n", "\n").replace("\r", "\n")
    )
    if (
        not content.strip()
        or not 1 <= len(content) <= 4000
        or len(content.encode()) > 16384
    ):
        fail("VALIDATION_ERROR", 422)
    return content


def segments(content, tokens):
    result = []
    start = 0
    for token in tokens:
        result.append(content[start : token.start])
        start = token.end
    result.append(content[start:])
    return result


def validate_mentions(tokens, grant, previous_version=None, *, db, content=None):
    users = {u.id: u for m, u, t in db.execute(eligible_members(grant.root.id, db=db))}
    old = previous_version.content if previous_version else ""
    old_tokens = parse_mentions(old) if old else []
    # Historical token identity/count is stable; editing prose is not a new mention.
    from collections import Counter

    remaining = Counter(
        (t.user_id, t.name) for t in old_tokens if t.user_id not in users
    )
    replacements = []
    labels = {}
    for t in tokens:
        if t.user_id not in users:
            identity = (t.user_id, t.name)
            if remaining[identity] <= 0:
                fail("INVALID_MENTION", 422)
            remaining[identity] -= 1
            new_name = t.name
        else:
            new_name = canonical_label(users[t.user_id])
        labels.setdefault(t.user_id, new_name)
        replacements.append((t, new_name))
    value = content
    for t, new_name in reversed(replacements):
        value = value[: t.start] + f"@[{new_name}](user:{t.user_id})" + value[t.end :]
    validate_content(value)
    return value, labels
