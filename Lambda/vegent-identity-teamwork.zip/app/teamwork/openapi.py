"""Publish actual error/header/paging semantics without opening a documentation route."""

import json
from pathlib import Path

from fastapi.openapi.utils import get_openapi
from pydantic import BaseModel, ConfigDict, TypeAdapter

from app.teamwork.schemas.responses import Comment, Progress, ProjectDetail, Task


class VersionCurrent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    version: int


class ResourceVersionCurrent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    entity_version: int


class InheritedMembersCurrent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    members_href: str


class ApplicationError(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str
    message: str
    request_id: str
    current: (
        VersionCurrent
        | ResourceVersionCurrent
        | InheritedMembersCurrent
        | ProjectDetail
        | Task
        | Comment
        | Progress
        | None
    ) = None


class ErrorEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")
    error: ApplicationError


VERSION_BASES = {
    **dict.fromkeys(("E03", "E04", "E05"), "root Project.version"),
    **dict.fromkeys(("E23", "E24"), "Category.version"),
    **dict.fromkeys(
        ("E26", "E27", "E29", "E30", "E31", "E39", "E42"), "Project.version"
    ),
    **dict.fromkeys(("E09", "E10"), "Comment.version"),
    **dict.fromkeys(("E34", "E35", "E36", "E37", "E38"), "Task.version"),
    **dict.fromkeys(
        ("E49", "E50", "E51"), "Resource.entity_version (not its logical version)"
    ),
    **dict.fromkeys(("E55", "E56"), "ContextItem.version"),
    **dict.fromkeys(
        ("E15", "E16", "E59", "E60", "E61", "E62"), "ConversionSession.version"
    ),
    **dict.fromkeys(("E46", "E47", "E48"), "UploadState.version"),
}
EMPTY_POSTS = {"E16", "E29", "E30", "E36", "E37", "E49", "E50", "E60", "E61"}
CONFIRM_DELETES = {"E24", "E31", "E38", "E51", "E56"}
ID_DOMAINS = {
    "E03": "body.user_id is users.id from Team discovery, not team_members.id or project_members.id. Integer namespaces can overlap; the server interprets this field only as a User ID.",
    "E04": "path.project_member_id is project_members.id, resolved with path.project_id. It is not users.id or the identity Team membership ID. Numeric coincidence cannot identify a caller's mistaken namespace.",
    "E05": "body.new_creator_user_id is users.id of an already eligible root Project member, not a membership-row ID.",
}
PAGING = {
    "mode": "cursor_only",
    "default_limit": 50,
    "short_pages_are_valid": True,
    "continuation": "Follow has_more and next_cursor, not item count. Page byte target is 1 MiB; no total collection quota.",
    "scope": "HMAC scope binds route, Team/node, filters/order and actor where viewer-specific. Context cursors bind shared context_version; they are not standalone list cursors.",
    "rotation": "INVALID_CURSOR 422: restart that traversal after signing-secret rotation or scope drift; preserve drafts and do not mark all cached Projects revoked. Secret caches can overlap for five minutes.",
    "inputs": "Unknown or duplicate query keys, page=, nonliteral booleans and invalid IDs return422. IDs are positive safe JSON integers <=2^53-1.",
}
TEXT = {
    "shape": "TextValue={inline,ref}; exactly one is non-null. TextRef is data, not a credential or file URL.",
    "inline_characters": 2048,
    "max_fragment_characters": 131072,
    "resolve": "GET ref.href using If-Match=context_version; follow next_offset until complete. Offsets count Unicode characters, not UTF-8 bytes.",
    "consistency": "All sections and TextRefs must share one context_version. CONTEXT_CHANGED409 restarts complete traversal with bounded retries; after three immediate attempts pause/preserve the local draft.",
}
ERROR_MEANINGS = {
    "401": "Missing/expired/invalid Bearer token; refresh or authenticate.",
    "403": "TEAM_ACCESS_DENIED (including unknown Team) or FORBIDDEN action; no System Admin private Project bypass.",
    "404": "PROJECT_NOT_FOUND or NOT_FOUND; inaccessible/deleted/nonexistent scope is indistinguishable. No revoked/deleted Project tombstone is returned.",
    "409": "VERSION_CONFLICT, CONTEXT_CHANGED, IDEMPOTENCY_CONFLICT or state conflict. INHERITED_MEMBERSHIP includes current.members_href. Current is emitted only after the applicable permission check; preserve the caller's draft.",
    "422": "Application ErrorEnvelope, never FastAPI detail[]. Includes VALIDATION_ERROR, INVALID_CURSOR, INVALID_VERSION, INVALID_MENTION, INVALID_FILTER and storage/checksum validation errors.",
    "503": "TEAMWORK_NOT_ENABLED means flag-off; TEAMWORK_RECONCILIATION_REQUIRED means maintenance until audited repair; STAGING_POLICY_REQUIRED/STORAGE_NOT_CONFIGURED/PROVIDER_NOT_CONFIGURED mean missing configuration. SERVICE_UNAVAILABLE/STORAGE_UNAVAILABLE/PROVIDER_UNAVAILABLE may be transient. Distinguish by code.",
    "429": "Identity public-auth admission limit; Retry-After60seconds. Team Work has no application429.",
    "500": "INTERNAL_ERROR; unexpected failure or response-contract bug. Do not echo input or automatically revoke cached Projects.",
}


def install_openapi(app):
    def build():
        if app.openapi_schema:
            return app.openapi_schema
        schema = get_openapi(title=app.title, version="2.1-r3", routes=app.routes)
        components = schema.setdefault("components", {}).setdefault("schemas", {})
        error_schema = TypeAdapter(ErrorEnvelope).json_schema(
            ref_template="#/components/schemas/{model}"
        )
        components.update(error_schema.pop("$defs", {}))
        components["ErrorEnvelope"] = error_schema
        inventory = {
            x["id"]: x
            for x in json.loads(
                Path(__file__).with_name("endpoint_inventory.json").read_text()
            )
        }
        header_table = []
        for path, methods in schema["paths"].items():
            for method, operation in methods.items():
                if not isinstance(operation, dict) or "responses" not in operation:
                    continue
                e = operation.get("operationId")
                team = e in inventory
                codes = (
                    {401, 403, 422, 500, 503} if path != "/api/health" else {500, 503}
                )
                if method != "get" or e in ("E02", "E11", "E58"):
                    codes.add(409)
                if (
                    "{project_id}" in path
                    or "{conversion_id}" in path
                    or "{upload_id}" in path
                    or "{category_id}" in path
                    or not team
                ):
                    codes.add(404)
                if path in {
                    "/api/auth/account-status",
                    "/api/auth/register-by-invite",
                    "/api/auth/login",
                    "/api/auth/refresh",
                    "/api/auth/complete-registration-after-unlock",
                }:
                    codes.add(429)
                for code in sorted(codes):
                    operation["responses"][str(code)] = {
                        "description": ERROR_MEANINGS[str(code)],
                        "headers": {
                            "Cache-Control": {"schema": {"const": "no-store"}},
                            "X-Request-ID": {"schema": {"type": "string"}},
                        },
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/ErrorEnvelope"}
                            }
                        },
                    }
                if 429 in codes:
                    operation["responses"]["429"]["headers"]["Retry-After"] = {
                        "schema": {"const": "60"}
                    }
                if path == "/api/health":
                    operation["responses"]["503"]["content"]["application/json"][
                        "schema"
                    ] = {
                        "type": "object",
                        "properties": {"status": {"const": "unavailable"}},
                        "required": ["status"],
                    }
                if not team:
                    continue
                version = VERSION_BASES.get(e, "none")
                if e in ("E11", "E58"):
                    version = (
                        "shared context_version (64 lowercase hex; quotes accepted)"
                    )
                for parameter in operation.get("parameters", []):
                    name = parameter["name"].lower()
                    if name == "idempotency-key":
                        parameter["description"] = (
                            "Canonical lowercase UUIDv4; retain the same key only for the same method/path/body/query/version. Reauthorize before replay."
                        )
                        parameter["schema"].update(
                            {
                                "type": "string",
                                "format": "uuid",
                                "pattern": "^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
                            }
                        )
                    if name == "if-match":
                        parameter["description"] = version + (
                            "; required for section/cursor traversal."
                            if e == "E11"
                            else "; quoted positive integer for entity versions."
                        )
                        parameter["schema"]["pattern"] = (
                            '^(?:[0-9a-f]{64}|"[0-9a-f]{64}")$'
                            if e in ("E11", "E58")
                            else '^"[1-9][0-9]*"$'
                        )
                    if name in ("user_id", "project_member_id"):
                        parameter["description"] = ID_DOMAINS.get(
                            e, "Identity users.id; never a membership-row ID."
                        )
                if e in ("E11", "E58"):
                    operation["x-text-ref-contract"] = TEXT
                if e == "E11":
                    operation["responses"]["304"] = {
                        "description": "Initial manifest only, after current authorization; If-None-Match with section/cursor is422. No body."
                    }
                operation["x-pagination-contract"] = {
                    **PAGING,
                    "applicable": e != "E58"
                    and any(
                        p["name"] == "cursor" for p in operation.get("parameters", [])
                    ),
                }
                operation["x-request-contract"] = {
                    "version_basis": version,
                    "idempotency": "current authorized projection of the committed effect; not a stored historical response body",
                    "body": "required empty JSON object {}"
                    if e in EMPTY_POSTS
                    else "required LifecycleBody with confirm:true"
                    if e in CONFIRM_DELETES
                    else "no body"
                    if inventory[e]["request"] is None
                    else inventory[e]["request"],
                    "id_domains": ID_DOMAINS.get(e),
                    "replay": "Project delete remains404 after deletion, even with the same key; preserve that key and treat404 after an uncertain DELETE as probable success, not proof of original nonexistence."
                    if e == "E31"
                    else "Successful DELETE with the same key replays204 while current enclosing scope/action remains authorized. Access loss is never bypassed.",
                }
                if e in ("E15", "E17", "E44", "E46", "E47"):
                    operation["x-capability-contract"] = (
                        "Replay preserves the intent/effect and reauthorizes; it can mint a fresh bounded capability. It does not replay an original URL or retract an issued URL. Owner TTL required, code ceiling900seconds; real expiry/revocation-window qualification pending."
                    )
                if e == "E42":
                    operation["x-sync-contract"] = (
                        "Per-page commits, not atomic repository sync. Each continuation requires a fresh UUIDv4 key and If-Match equal to the last returned project_version. Resume running pages to completed; failure leaves previously committed per-PR mirrors. Show partial/incomplete sync until completion; repository_ref comes from the owner handoff. Sync503 does not block reading stored mirrors."
                    )
                if e in ("E13", "E15", "E16", "E59", "E60", "E61", "E62"):
                    operation["x-conversion-contract"] = (
                        "planning->sealed->preparing->ready->committed. Prepare uses fresh key/current session version and seal-guard cursor; repeat to ready, then commit. Epoch change409 requires cancel/restart; no reseal path. Staging expiries are required owner configuration, with no lifetime default."
                    )
                if e == "E12":
                    operation["x-import-contract"] = (
                        "Receipt is an actor-scoped version claim, not proof of traversal or local application. Collect all10 sections/pages/TextRefs at one hash, persist an immutable local snapshot by local_import_id, then request receipt. A failed receipt does not destroy the local snapshot. Actual frontend integration is pending."
                    )
                operation["description"] = (
                    operation.get("description", "") + "\n" + ID_DOMAINS.get(e, "")
                ).strip()
                header_table.append(
                    {
                        "id": e,
                        "method": method.upper(),
                        "path": path,
                        "idempotency_key": method != "get",
                        "if_match_required": inventory[e]["version_required"]
                        or e == "E58",
                        "version": version,
                        "body": operation["x-request-contract"]["body"],
                    }
                )
        schema["x-teamwork-header-version-table"] = sorted(
            header_table, key=lambda row: row["id"]
        )
        schema["x-teamwork-text-contract"] = TEXT
        schema["x-teamwork-throttle-contract"] = (
            "No application Team Work limiter or application429. Mandatory owner Gateway per-user/key and per-IP/method admission configuration before pilot, with stricter download/sync/heavy-read buckets; exact rate/burst values and429 response mapping must be qualified and handed over. Reserved concurrency is not admission control."
        )
        schema["x-teamwork-counts-contract"] = (
            "Parent counts and last_activity_at are own-node only; Team totals sum matching roots+children once. Comment counts include tombstones; task counts include archived nondeleted tasks."
        )
        # This component documents the internal handler, not FastAPI's discarded detail[] body.
        components.pop("HTTPValidationError", None)
        components.pop("ValidationError", None)
        app.openapi_schema = schema
        return schema

    app.openapi = build
