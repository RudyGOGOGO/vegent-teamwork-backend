import base64
import hashlib
import hmac
import json

from app.core import config
from app.teamwork.errors import fail


def canonical(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    ).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def key():
    secret = config.get_identity_secret().SECRET_KEY.get_secret_value().encode()
    return hmac.new(
        secret, b"Vegent TeamWork cursor signing v1", hashlib.sha256
    ).digest()


def encode_cursor(payload):
    data = canonical(payload)
    return (
        base64.urlsafe_b64encode(data + hmac.new(key(), data, hashlib.sha256).digest())
        .decode()
        .rstrip("=")
    )


def decode_cursor(value, expected_scope):
    try:
        raw = base64.b64decode(
            value + "=" * (-len(value) % 4), altchars=b"-_", validate=True
        )
        data, tag = raw[:-32], raw[-32:]
        if not hmac.compare_digest(hmac.new(key(), data, hashlib.sha256).digest(), tag):
            raise ValueError()
        result = json.loads(data)
        if result.get("scope") != expected_scope:
            raise ValueError()
        return result
    except (ValueError, TypeError, KeyError, UnicodeError):
        fail("INVALID_CURSOR", 422)
