from sqlalchemy import (
    BigInteger,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    SmallInteger,
    UniqueConstraint,
)
from sqlalchemy.dialects.mysql import CHAR, DATETIME, JSON, VARCHAR

from app.db.base import Base


class TeamworkMutationKey(Base):
    __tablename__ = "teamwork_mutation_keys"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    actor_user_id = Column(Integer(), nullable=False)
    operation_key = Column(
        CHAR(36, charset="ascii", collation="ascii_bin"), nullable=False
    )
    request_hash = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=False
    )
    method_path = Column(
        VARCHAR(255, charset="ascii", collation="ascii_bin"), nullable=False
    )
    response_ref = Column(JSON(), nullable=False)
    response_status = Column(SmallInteger(), nullable=False)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    expires_at = Column(DATETIME(fsp=6), nullable=True)
    __table_args__ = (
        UniqueConstraint(
            "actor_user_id", "operation_key", name="uq_mutation_actor_key"
        ),
        Index("idx_mutation_expiry", "expires_at", "id"),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"]),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ProjectImportReceipt(Base):
    __tablename__ = "project_import_receipts"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    imported_by_user_id = Column(Integer(), nullable=False)
    local_import_id = Column(
        CHAR(36, charset="ascii", collation="ascii_bin"), nullable=False
    )
    context_version = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=False
    )
    imported_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint(
            "imported_by_user_id", "local_import_id", name="uq_import_actor_id"
        ),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["imported_by_user_id"], ["users.id"]),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
