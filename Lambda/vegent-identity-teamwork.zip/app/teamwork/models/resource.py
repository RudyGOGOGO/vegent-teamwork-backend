from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import (
    DATETIME,
    LONGTEXT,
    TEXT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class ProjectResource(Base):
    __tablename__ = "project_resources"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    name = deferred(Column(LONGTEXT(), nullable=False))
    status = Column(VARCHAR(20), nullable=False, server_default=text("'active'"))
    created_by_user_id = Column(Integer(), nullable=False)
    current_version = Column(BigInteger(), nullable=False, server_default=text("0"))
    entity_version = Column(BigInteger(), nullable=False, server_default=text("1"))
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("project_id", "id", name="uq_resource_project"),
        Index("idx_resource_list", "project_id", "status", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        CheckConstraint("status IN ('active','archived','deleted')"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ProjectResourceVersion(Base):
    __tablename__ = "project_resource_versions"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    resource_id = Column(BigInteger(), nullable=False)
    resource_version = Column(BigInteger(), nullable=False)
    name = deferred(Column(LONGTEXT(), nullable=False))
    media_type = Column(VARCHAR(255), nullable=False)
    size_bytes = Column(BigInteger(), nullable=False)
    checksum_algorithm = Column(VARCHAR(32), nullable=True)
    checksum_type = Column(VARCHAR(20), nullable=True)
    checksum_value = Column(TEXT(charset="ascii", collation="ascii_bin"), nullable=True)
    uploaded_by_user_id = Column(Integer(), nullable=False)
    uploader_name_snapshot = Column(VARCHAR(100), nullable=False)
    s3_object_key = Column(
        VARCHAR(1024, charset="ascii", collation="ascii_bin"), nullable=False
    )
    s3_version_id = Column(
        VARCHAR(1024, charset="ascii", collation="ascii_bin"), nullable=True
    )
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("resource_id", "resource_version", name="uq_resource_version"),
        ForeignKeyConstraint(["resource_id"], ["project_resources.id"]),
        ForeignKeyConstraint(["uploaded_by_user_id"], ["users.id"]),
        CheckConstraint("size_bytes>=0"),
        CheckConstraint(
            "checksum_type IS NULL OR checksum_type IN ('FULL_OBJECT','COMPOSITE')"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
