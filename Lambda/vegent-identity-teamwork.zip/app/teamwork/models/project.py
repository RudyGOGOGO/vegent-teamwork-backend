from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import (
    CHAR,
    DATETIME,
    LONGTEXT,
    TINYINT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class Project(Base):
    __tablename__ = "projects"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger(), nullable=False)
    parent_project_id = Column(BigInteger(), nullable=True)
    node_depth = Column(TINYINT(), nullable=False, server_default=text("0"))
    parent_depth_guard = Column(TINYINT(), nullable=False, server_default=text("0"))
    category_id = Column(BigInteger(), nullable=True)
    name = Column(VARCHAR(255), nullable=False)
    background = deferred(Column(LONGTEXT(), nullable=False))
    goals = deferred(Column(LONGTEXT(), nullable=False))
    source_created_at = Column(DATETIME(fsp=6), nullable=True)
    created_by_user_id = Column(Integer(), nullable=False)
    created_by_name = Column(VARCHAR(100), nullable=False)
    creator_user_id = Column(Integer(), nullable=True)
    creator_name_snapshot = Column(VARCHAR(100), nullable=True)
    ownership_state = Column(VARCHAR(20), nullable=True)
    ownership_lost_at = Column(DATETIME(fsp=6), nullable=True)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'active'"))
    deleted_from_status = Column(VARCHAR(20), nullable=True)
    deletion_batch_id = Column(
        CHAR(36, charset="ascii", collation="ascii_bin"), nullable=True
    )
    deleted_at = Column(DATETIME(fsp=6), nullable=True)
    deleted_by_user_id = Column(Integer(), nullable=True)
    delete_reason = deferred(Column(LONGTEXT(), nullable=True))
    progress_status = Column(
        VARCHAR(20), nullable=False, server_default=text("'not_started'")
    )
    progress_note = deferred(Column(LONGTEXT(), nullable=False))
    progress_note_author_id = Column(Integer(), nullable=False)
    progress_note_author_name = Column(VARCHAR(100), nullable=False)
    progress_note_updated_at = Column(DATETIME(fsp=6), nullable=False)
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    context_revision = Column(BigInteger(), nullable=False, server_default=text("1"))
    published_at = Column(DATETIME(fsp=6), nullable=True)
    lifecycle_updated_at = Column(DATETIME(fsp=6), nullable=False)
    membership_updated_at = Column(DATETIME(fsp=6), nullable=False)
    ownership_updated_at = Column(DATETIME(fsp=6), nullable=False)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    last_activity_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("id", "team_id", "node_depth", name="uq_project_parent_type"),
        UniqueConstraint("id", "team_id", name="uq_project_team"),
        Index(
            "idx_project_list",
            "team_id",
            "parent_project_id",
            "status",
            "last_activity_at",
            "id",
        ),
        Index("idx_project_category", "team_id", "category_id", "created_at", "id"),
        Index(
            "idx_project_owner", "team_id", "creator_user_id", "ownership_state", "id"
        ),
        ForeignKeyConstraint(["team_id"], ["teams.id"]),
        ForeignKeyConstraint(
            ["category_id", "team_id"], ["categories.id", "categories.team_id"]
        ),
        ForeignKeyConstraint(
            ["parent_project_id", "team_id", "parent_depth_guard"],
            ["projects.id", "projects.team_id", "projects.node_depth"],
        ),
        ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        ForeignKeyConstraint(["creator_user_id"], ["users.id"]),
        ForeignKeyConstraint(["progress_note_author_id"], ["users.id"]),
        ForeignKeyConstraint(["deleted_by_user_id"], ["users.id"]),
        CheckConstraint("parent_depth_guard=0"),
        CheckConstraint(
            "(node_depth=0 AND parent_project_id IS NULL AND creator_user_id IS NOT NULL\n        AND ownership_state IS NOT NULL AND ownership_state IN ('assigned','unassigned'))\n    OR (node_depth=1 AND parent_project_id IS NOT NULL AND category_id IS NULL\n        AND creator_user_id IS NULL AND creator_name_snapshot IS NULL\n        AND ownership_state IS NULL AND ownership_lost_at IS NULL)"
        ),
        CheckConstraint(
            "node_depth=1 OR\n   (ownership_state='assigned' AND ownership_lost_at IS NULL) OR\n   (ownership_state='unassigned' AND ownership_lost_at IS NOT NULL)"
        ),
        CheckConstraint("status IN ('active','archived','deleted')"),
        CheckConstraint(
            "progress_status IN ('not_started','in_progress','blocked','in_review','completed','on_hold')"
        ),
        CheckConstraint("version>=1 AND context_revision>=1"),
        CheckConstraint(
            "(status='deleted' AND deleted_at IS NOT NULL AND deleted_by_user_id IS NOT NULL\n        AND deleted_from_status IN ('active','archived') AND deletion_batch_id IS NOT NULL)\n    OR (status<>'deleted' AND deleted_at IS NULL AND deleted_by_user_id IS NULL\n        AND deleted_from_status IS NULL AND deletion_batch_id IS NULL AND delete_reason IS NULL)"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
