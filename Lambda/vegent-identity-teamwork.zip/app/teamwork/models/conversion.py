from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import CHAR, DATETIME, JSON, VARCHAR

from app.db.base import Base


class ProjectConversionSession(Base):
    __tablename__ = "project_conversion_sessions"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger(), nullable=False)
    created_by_user_id = Column(Integer(), nullable=False)
    client_conversion_id = Column(
        CHAR(36, charset="ascii", collation="ascii_bin"), nullable=False
    )
    mode = Column(VARCHAR(20), nullable=False)
    existing_parent_id = Column(BigInteger(), nullable=True)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'planning'"))
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    plan_digest = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=True
    )
    committed_project_id = Column(BigInteger(), nullable=True)
    sealed_actor_team_membership_id = Column(BigInteger(), nullable=True)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    expires_at = Column(DATETIME(fsp=6), nullable=True)
    __table_args__ = (
        UniqueConstraint(
            "created_by_user_id",
            "client_conversion_id",
            name="uq_conversion_actor_client",
        ),
        ForeignKeyConstraint(["team_id"], ["teams.id"]),
        ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        ForeignKeyConstraint(["existing_parent_id"], ["projects.id"]),
        ForeignKeyConstraint(["committed_project_id"], ["projects.id"]),
        ForeignKeyConstraint(["sealed_actor_team_membership_id"], ["team_members.id"]),
        CheckConstraint("mode IN ('root','subproject')"),
        CheckConstraint(
            "(mode='root' AND existing_parent_id IS NULL) OR (mode='subproject' AND existing_parent_id IS NOT NULL)"
        ),
        CheckConstraint(
            "status IN ('planning','sealed','preparing','ready','committed','failed','cancelled','expired')"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ProjectConversionItem(Base):
    __tablename__ = "project_conversion_items"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    conversion_id = Column(BigInteger(), nullable=False)
    client_item_id = Column(
        CHAR(36, charset="ascii", collation="ascii_bin"), nullable=False
    )
    kind = Column(VARCHAR(20), nullable=False)
    node_key = Column(CHAR(36, charset="ascii", collation="ascii_bin"), nullable=False)
    payload = Column(JSON(), nullable=False)
    request_hash = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=False
    )
    prepared_object_id = Column(BigInteger(), nullable=True)
    validated_team_membership_id = Column(BigInteger(), nullable=True)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("conversion_id", "client_item_id", name="uq_conversion_item"),
        Index("idx_conversion_plan", "conversion_id", "kind", "id"),
        ForeignKeyConstraint(["conversion_id"], ["project_conversion_sessions.id"]),
        ForeignKeyConstraint(["validated_team_membership_id"], ["team_members.id"]),
        CheckConstraint("validated_team_membership_id IS NULL OR kind='member'"),
        CheckConstraint("kind IN ('node','task','member','resource')"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
