from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import (
    DATETIME,
    LONGTEXT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class ProjectPR(Base):
    __tablename__ = "project_prs"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    provider = Column(VARCHAR(20), nullable=False)
    repository_ref = Column(VARCHAR(255), nullable=False)
    external_pr_id = Column(VARCHAR(255), nullable=False)
    title = deferred(Column(LONGTEXT(), nullable=False))
    url = deferred(Column(LONGTEXT(), nullable=False))
    branch = deferred(Column(LONGTEXT(), nullable=False))
    status = Column(VARCHAR(20), nullable=False)
    reviewer_mapping_complete = Column(
        Boolean(), nullable=False, server_default=text("FALSE")
    )
    synced_at = Column(DATETIME(fsp=6), nullable=False)
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    __table_args__ = (
        UniqueConstraint(
            "project_id",
            "provider",
            "repository_ref",
            "external_pr_id",
            name="uq_pr_external",
        ),
        UniqueConstraint("project_id", "id", name="uq_pr_project"),
        Index("idx_pr_counts", "project_id", "status", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        CheckConstraint("provider IN ('github','stash')"),
        CheckConstraint("status IN ('open','merged','closed')"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ProjectPRReviewer(Base):
    __tablename__ = "project_pr_reviewers"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    pr_id = Column(BigInteger(), nullable=False)
    external_reviewer_id = Column(VARCHAR(255), nullable=False)
    user_id = Column(Integer(), nullable=True)
    display_name = Column(VARCHAR(255), nullable=False)
    is_current = Column(Boolean(), nullable=False, server_default=text("TRUE"))
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("pr_id", "external_reviewer_id", name="uq_pr_reviewer"),
        Index("idx_review_me", "user_id", "pr_id"),
        ForeignKeyConstraint(["pr_id"], ["project_prs.id"]),
        ForeignKeyConstraint(["user_id"], ["users.id"]),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
