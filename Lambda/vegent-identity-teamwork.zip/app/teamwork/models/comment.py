from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, JSON, TEXT, VARCHAR

from app.db.base import Base


class ProjectComment(Base):
    __tablename__ = "project_comments"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    task_id = Column(BigInteger(), nullable=True)
    pr_id = Column(BigInteger(), nullable=True)
    resource_id = Column(BigInteger(), nullable=True)
    parent_comment_id = Column(BigInteger(), nullable=True)
    author_user_id = Column(Integer(), nullable=False)
    author_project_member_id = Column(BigInteger(), nullable=False)
    author_name_snapshot = Column(VARCHAR(100), nullable=False)
    author_role_snapshot = Column(VARCHAR(20), nullable=False)
    content = Column(TEXT(), nullable=False)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'active'"))
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    edited_at = Column(DATETIME(fsp=6), nullable=True)
    deleted_at = Column(DATETIME(fsp=6), nullable=True)
    deleted_by_user_id = Column(Integer(), nullable=True)
    __table_args__ = (
        UniqueConstraint("project_id", "id", name="uq_comment_project"),
        Index("idx_comment_page", "project_id", "created_at", "id"),
        Index("idx_comment_author", "project_id", "author_user_id", "created_at", "id"),
        Index(
            "idx_comment_parent", "project_id", "parent_comment_id", "created_at", "id"
        ),
        Index("idx_comment_task", "project_id", "task_id", "created_at", "id"),
        Index("idx_comment_pr", "project_id", "pr_id", "created_at", "id"),
        Index("idx_comment_resource", "project_id", "resource_id", "created_at", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["author_user_id"], ["users.id"]),
        ForeignKeyConstraint(["author_project_member_id"], ["project_members.id"]),
        ForeignKeyConstraint(["deleted_by_user_id"], ["users.id"]),
        ForeignKeyConstraint(
            ["project_id", "parent_comment_id"],
            ["project_comments.project_id", "project_comments.id"],
        ),
        ForeignKeyConstraint(
            ["project_id", "task_id"], ["project_tasks.project_id", "project_tasks.id"]
        ),
        ForeignKeyConstraint(
            ["project_id", "pr_id"], ["project_prs.project_id", "project_prs.id"]
        ),
        ForeignKeyConstraint(
            ["project_id", "resource_id"],
            ["project_resources.project_id", "project_resources.id"],
        ),
        CheckConstraint("status IN ('active','edited','deleted')"),
        CheckConstraint("author_role_snapshot IN ('creator','member')"),
        CheckConstraint(
            "CHAR_LENGTH(content) BETWEEN 1 AND 4000 AND OCTET_LENGTH(content)<=16384"
        ),
        CheckConstraint(
            "(task_id IS NOT NULL)+(pr_id IS NOT NULL)+(resource_id IS NOT NULL)<=1"
        ),
        CheckConstraint(
            "(status='deleted' AND deleted_at IS NOT NULL AND deleted_by_user_id IS NOT NULL)\n    OR (status<>'deleted' AND deleted_at IS NULL AND deleted_by_user_id IS NULL)"
        ),
        CheckConstraint("version>=1"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class CommentMention(Base):
    __tablename__ = "comment_mentions"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    comment_id = Column(BigInteger(), nullable=False)
    mentioned_user_id = Column(Integer(), nullable=False)
    mentioned_name_snapshot = Column(VARCHAR(100), nullable=False)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'active'"))
    changed_version = Column(BigInteger(), nullable=False)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint(
            "comment_id", "mentioned_user_id", name="uq_comment_user_mention"
        ),
        Index("idx_mentions_me", "mentioned_user_id", "status", "comment_id"),
        ForeignKeyConstraint(["comment_id"], ["project_comments.id"]),
        ForeignKeyConstraint(["mentioned_user_id"], ["users.id"]),
        CheckConstraint("status IN ('active','removed')"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ProjectCommentRevision(Base):
    __tablename__ = "project_comment_revisions"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    comment_id = Column(BigInteger(), nullable=False)
    version = Column(BigInteger(), nullable=False)
    actor_user_id = Column(Integer(), nullable=False)
    status = Column(VARCHAR(20), nullable=False)
    content = Column(TEXT(), nullable=False)
    mentions_snapshot = Column(JSON(), nullable=False)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("comment_id", "version", name="uq_comment_revision"),
        ForeignKeyConstraint(["comment_id"], ["project_comments.id"]),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"]),
        CheckConstraint("status IN ('active','edited','deleted')"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
