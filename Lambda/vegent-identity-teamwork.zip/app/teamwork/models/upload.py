from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import (
    CHAR,
    DATETIME,
    JSON,
    LONGTEXT,
    TEXT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class ResourceUpload(Base):
    __tablename__ = "resource_uploads"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger(), nullable=False)
    project_id = Column(BigInteger(), nullable=True)
    conversion_id = Column(BigInteger(), nullable=True)
    conversion_item_id = Column(BigInteger(), nullable=True)
    resource_id = Column(BigInteger(), nullable=True)
    actor_user_id = Column(Integer(), nullable=False)
    client_upload_id = Column(
        CHAR(36, charset="ascii", collation="ascii_bin"), nullable=False
    )
    name = deferred(Column(LONGTEXT(), nullable=False))
    media_type = Column(VARCHAR(255), nullable=False)
    declared_size = Column(BigInteger(), nullable=False)
    declared_sha256 = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=True
    )
    upload_kind = Column(VARCHAR(20), nullable=False)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'pending'"))
    object_key = Column(
        VARCHAR(1024, charset="ascii", collation="ascii_bin"), nullable=False
    )
    multipart_id = deferred(Column(LONGTEXT(), nullable=True))
    part_manifest_sealed_at = Column(DATETIME(fsp=6), nullable=True)
    verification_cursor = Column(Integer(), nullable=False, server_default=text("0"))
    verified_part_count = Column(Integer(), nullable=False, server_default=text("0"))
    verified_size_bytes = Column(BigInteger(), nullable=False, server_default=text("0"))
    part_manifest_hash = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=True
    )
    completion_authorized_at = Column(DATETIME(fsp=6), nullable=True)
    verified_object_version = Column(
        VARCHAR(1024, charset="ascii", collation="ascii_bin"), nullable=True
    )
    verified_checksum = Column(JSON(), nullable=True)
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    expires_at = Column(DATETIME(fsp=6), nullable=True)
    last_url_expires_at = Column(DATETIME(fsp=6), nullable=True)
    __table_args__ = (
        UniqueConstraint(
            "actor_user_id", "client_upload_id", name="uq_upload_actor_client"
        ),
        Index("idx_upload_cleanup", "status", "expires_at", "id"),
        ForeignKeyConstraint(["team_id"], ["teams.id"]),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["conversion_id"], ["project_conversion_sessions.id"]),
        ForeignKeyConstraint(["conversion_item_id"], ["project_conversion_items.id"]),
        ForeignKeyConstraint(["resource_id"], ["project_resources.id"]),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"]),
        CheckConstraint("(project_id IS NOT NULL)+(conversion_id IS NOT NULL)=1"),
        CheckConstraint("declared_size>=0"),
        CheckConstraint("upload_kind IN ('single_put','multipart')"),
        CheckConstraint(
            "status IN ('pending','uploading','verifying','awaiting_completion','verified','published','failed','cancelled','expired')"
        ),
        CheckConstraint(
            "verification_cursor BETWEEN 0 AND 10000 AND verified_part_count BETWEEN 0 AND 10000"
        ),
        CheckConstraint("verified_size_bytes>=0"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ResourceUploadPart(Base):
    __tablename__ = "resource_upload_parts"
    upload_id = Column(BigInteger(), nullable=False, primary_key=True)
    part_number = Column(Integer(), nullable=False, primary_key=True)
    expected_size = Column(BigInteger(), nullable=False)
    checksum_algorithm = Column(VARCHAR(32), nullable=True)
    expected_checksum = Column(
        TEXT(charset="ascii", collation="ascii_bin"), nullable=True
    )
    observed_etag = Column(
        VARCHAR(255, charset="ascii", collation="ascii_bin"), nullable=True
    )
    observed_size = Column(BigInteger(), nullable=True)
    observed_checksum = Column(JSON(), nullable=True)
    verified_at = Column(DATETIME(fsp=6), nullable=True)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        ForeignKeyConstraint(["upload_id"], ["resource_uploads.id"]),
        CheckConstraint("part_number BETWEEN 1 AND 10000"),
        CheckConstraint("expected_size>=0"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
