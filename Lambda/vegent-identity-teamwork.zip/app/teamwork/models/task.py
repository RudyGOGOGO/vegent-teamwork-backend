from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import (
    DATETIME,
    LONGTEXT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class ProjectTask(Base):
    __tablename__ = "project_tasks"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    title = Column(VARCHAR(255), nullable=False)
    description = deferred(Column(LONGTEXT(), nullable=False))
    status = Column(VARCHAR(20), nullable=False, server_default=text("'todo'"))
    lifecycle_status = Column(
        VARCHAR(20), nullable=False, server_default=text("'active'")
    )
    created_by_user_id = Column(Integer(), nullable=False)
    created_by_name_snapshot = Column(VARCHAR(100), nullable=False)
    driver_user_id = Column(Integer(), nullable=False)
    driver_name_snapshot = Column(VARCHAR(100), nullable=False)
    assignee_user_id = Column(Integer(), nullable=True)
    assignee_name_snapshot = Column(VARCHAR(100), nullable=True)
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("project_id", "id", name="uq_task_project"),
        Index("idx_task_counts", "project_id", "lifecycle_status", "status", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        ForeignKeyConstraint(["driver_user_id"], ["users.id"]),
        ForeignKeyConstraint(["assignee_user_id"], ["users.id"]),
        CheckConstraint("status IN ('todo','in_progress','blocked','done')"),
        CheckConstraint("lifecycle_status IN ('active','archived','deleted')"),
        CheckConstraint("version>=1"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
