from sqlalchemy import (
    BigInteger,
    Column,
    Computed,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR

from app.db.base import Base


class Category(Base):
    __tablename__ = "categories"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger(), nullable=False)
    name = Column(VARCHAR(255), nullable=False)
    created_by_user_id = Column(Integer(), nullable=False)
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    deleted_at = Column(DATETIME(fsp=6), nullable=True)
    active_name = Column(
        VARCHAR(255),
        Computed(
            "CASE WHEN deleted_at IS NULL THEN name ELSE NULL END", persisted=True
        ),
        nullable=True,
    )
    __table_args__ = (
        UniqueConstraint("team_id", "active_name", name="uq_category_active_name"),
        UniqueConstraint("id", "team_id", name="uq_category_team"),
        Index("idx_category_order", "team_id", "created_at", "id"),
        ForeignKeyConstraint(["team_id"], ["teams.id"]),
        ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
