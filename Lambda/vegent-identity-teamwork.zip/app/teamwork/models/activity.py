from sqlalchemy import BigInteger, Column, ForeignKeyConstraint, Index, Integer
from sqlalchemy.dialects.mysql import DATETIME, JSON, VARCHAR

from app.db.base import Base


class ProjectActivityEvent(Base):
    __tablename__ = "project_activity_events"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    event_type = Column(VARCHAR(50), nullable=False)
    actor_user_id = Column(Integer(), nullable=False)
    actor_name_snapshot = Column(VARCHAR(100), nullable=False)
    object_type = Column(VARCHAR(40), nullable=False)
    object_id = Column(BigInteger(), nullable=True)
    object_version = Column(BigInteger(), nullable=True)
    safe_detail = Column(JSON(), nullable=False)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        Index("idx_project_activity", "project_id", "created_at", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"]),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
