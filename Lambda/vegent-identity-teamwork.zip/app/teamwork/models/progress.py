from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
)
from sqlalchemy.dialects.mysql import (
    DATETIME,
    LONGTEXT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class ProjectProgressEvent(Base):
    __tablename__ = "project_progress_events"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    project_version = Column(BigInteger(), nullable=False)
    event_type = Column(VARCHAR(20), nullable=False)
    actor_user_id = Column(Integer(), nullable=False)
    actor_name_snapshot = Column(VARCHAR(100), nullable=False)
    old_status = Column(VARCHAR(20), nullable=False)
    new_status = Column(VARCHAR(20), nullable=False)
    old_note = deferred(Column(LONGTEXT(), nullable=False))
    new_note = deferred(Column(LONGTEXT(), nullable=False))
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        Index("idx_progress_history", "project_id", "created_at", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"]),
        CheckConstraint("event_type IN ('progress_changed','archived','unarchived')"),
        CheckConstraint(
            "old_status IN ('not_started','in_progress','blocked','in_review','completed','on_hold')"
        ),
        CheckConstraint(
            "new_status IN ('not_started','in_progress','blocked','in_review','completed','on_hold')"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
