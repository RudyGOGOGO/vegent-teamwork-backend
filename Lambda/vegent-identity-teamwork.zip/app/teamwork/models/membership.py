from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    Computed,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, TINYINT, VARCHAR

from app.db.base import Base


class ProjectMember(Base):
    __tablename__ = "project_members"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    team_id = Column(BigInteger(), nullable=False)
    root_depth_guard = Column(TINYINT(), nullable=False, server_default=text("0"))
    user_id = Column(Integer(), nullable=False)
    team_membership_id = Column(BigInteger(), nullable=False)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'active'"))
    added_by_user_id = Column(Integer(), nullable=False)
    added_by_name_snapshot = Column(VARCHAR(100), nullable=False)
    joined_at = Column(DATETIME(fsp=6), nullable=False)
    removed_by_user_id = Column(Integer(), nullable=True)
    removed_at = Column(DATETIME(fsp=6), nullable=True)
    removal_reason = Column(VARCHAR(40), nullable=True)
    active_user_id = Column(
        Integer(),
        Computed(
            "CASE WHEN status='active' THEN user_id ELSE NULL END", persisted=True
        ),
        nullable=True,
    )
    __table_args__ = (
        UniqueConstraint(
            "project_id", "active_user_id", name="uq_project_active_member"
        ),
        Index(
            "idx_project_member_cascade",
            "team_id",
            "user_id",
            "status",
            "project_id",
            "id",
        ),
        Index("idx_project_member_epoch", "team_membership_id", "status", "project_id"),
        ForeignKeyConstraint(
            ["project_id", "team_id", "root_depth_guard"],
            ["projects.id", "projects.team_id", "projects.node_depth"],
        ),
        ForeignKeyConstraint(["user_id"], ["users.id"]),
        ForeignKeyConstraint(["team_membership_id"], ["team_members.id"]),
        ForeignKeyConstraint(["added_by_user_id"], ["users.id"]),
        ForeignKeyConstraint(["removed_by_user_id"], ["users.id"]),
        CheckConstraint("root_depth_guard=0"),
        CheckConstraint("status IN ('active','removed')"),
        CheckConstraint(
            "(status='active' AND removed_at IS NULL AND removed_by_user_id IS NULL AND removal_reason IS NULL)\n    OR (status='removed' AND removed_at IS NOT NULL AND removed_by_user_id IS NOT NULL AND removal_reason IS NOT NULL)"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
