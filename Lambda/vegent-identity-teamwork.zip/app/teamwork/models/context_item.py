from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import (
    DATETIME,
    JSON,
    LONGTEXT,
    VARCHAR,
)
from sqlalchemy.orm import deferred

from app.db.base import Base


class ProjectContextItem(Base):
    __tablename__ = "project_context_items"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    project_id = Column(BigInteger(), nullable=False)
    kind = Column(VARCHAR(20), nullable=False)
    title = Column(VARCHAR(255), nullable=False)
    context_text = deferred(Column(LONGTEXT(), nullable=False))
    body = deferred(Column(LONGTEXT(), nullable=False))
    answer = deferred(Column(LONGTEXT(), nullable=True))
    state = Column(VARCHAR(20), nullable=False)
    author_user_id = Column(Integer(), nullable=False)
    author_name_snapshot = Column(VARCHAR(100), nullable=False)
    decided_at = Column(DATETIME(fsp=6), nullable=True)
    version = Column(BigInteger(), nullable=False, server_default=text("1"))
    deleted_at = Column(DATETIME(fsp=6), nullable=True)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    updated_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        Index("idx_context_items", "project_id", "kind", "state", "id"),
        ForeignKeyConstraint(["project_id"], ["projects.id"]),
        ForeignKeyConstraint(["author_user_id"], ["users.id"]),
        CheckConstraint(
            "(kind='decision' AND state IN ('proposed','accepted','superseded','withdrawn'))\n    OR (kind='open_question' AND state IN ('open','answered','closed'))"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )


class ProjectContextItemRevision(Base):
    __tablename__ = "project_context_item_revisions"
    id = Column(BigInteger(), nullable=False, primary_key=True, autoincrement=True)
    item_id = Column(BigInteger(), nullable=False)
    version = Column(BigInteger(), nullable=False)
    actor_user_id = Column(Integer(), nullable=False)
    snapshot = Column(JSON(), nullable=False)
    created_at = Column(DATETIME(fsp=6), nullable=False)
    __table_args__ = (
        UniqueConstraint("item_id", "version", name="uq_context_item_revision"),
        ForeignKeyConstraint(["item_id"], ["project_context_items.id"]),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"]),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
