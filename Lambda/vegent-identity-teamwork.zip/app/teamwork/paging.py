from app.teamwork.cursors import canonical, decode_cursor, encode_cursor
from app.teamwork.errors import fail

TARGET_BYTES = 1024 * 1024


def page(items, *, scope, limit=50, cursor=None, projection_version=None):
    if not isinstance(limit, int) or limit <= 0:
        fail("VALIDATION_ERROR", 422)
    after = decode_cursor(cursor, scope).get("after") if cursor else None
    start = 0
    if after is not None:
        for i, item in enumerate(items):
            identity = item.get("_cursor_key", item.get("id", item.get("user_id")))
            if str(identity) == after:
                start = i + 1
                break
        else:
            fail("INVALID_CURSOR", 422)
    selected = []
    size = 0
    index = start
    for item in items[start:]:
        clean = {k: v for k, v in item.items() if k != "_cursor_key"}
        amount = len(canonical(clean))
        if selected and (len(selected) >= limit or size + amount > TARGET_BYTES):
            break
        selected.append(clean)
        size += amount
        index += 1
    more = index < len(items)
    last = (
        items[index - 1].get(
            "_cursor_key", items[index - 1].get("id", items[index - 1].get("user_id"))
        )
        if more
        else None
    )
    return {
        "items": selected,
        "next_cursor": encode_cursor({"scope": scope, "after": str(last)})
        if more
        else None,
        "has_more": more,
        "projection_version": projection_version,
    }


def sql_page(
    query,
    model,
    projector,
    *,
    db,
    scope,
    order,
    limit=50,
    cursor=None,
    projection_version=None,
    row_mode=False,
    key_values=None,
    prepare_rows=None,
):
    """Traverse a SQL keyset without loading or projecting the complete collection."""
    from datetime import datetime

    from sqlalchemy import and_, or_

    if limit <= 0:
        fail("VALIDATION_ERROR", 422)
    saved = decode_cursor(cursor, scope).get("key") if cursor else None

    def after_condition(values):
        terms = []
        for index, (column, descending) in enumerate(order):
            value = values[index]
            try:
                if column.type.python_type is datetime and isinstance(value, str):
                    value = datetime.fromisoformat(value)
                elif column.type.python_type is int:
                    value = int(value)
            except (ValueError, TypeError):
                fail("INVALID_CURSOR", 422)
            equals = []
            for previous in range(index):
                field, _ = order[previous]
                old = values[previous]
                if field.type.python_type is datetime and isinstance(old, str):
                    old = datetime.fromisoformat(old)
                equals.append(field == old)
            terms.append(
                and_(*equals, column < value if descending else column > value)
            )
        return or_(*terms)

    if saved is not None and (not isinstance(saved, list) or len(saved) != len(order)):
        fail("INVALID_CURSOR", 422)
    ordered = query.order_by(None).order_by(
        *(c.desc() if descending else c.asc() for c, descending in order)
    )
    selected = []
    size = 0
    last = saved
    has_more = False
    while len(selected) < limit:
        chunk = ordered.where(after_condition(last)) if last else ordered
        statement = chunk.limit(min(100, limit - len(selected) + 1))
        rows = list(db.execute(statement).all() if row_mode else db.scalars(statement))
        if not rows:
            break
        if prepare_rows:
            prepare_rows(rows)
        stop = False
        for row in rows:
            item = projector(row)
            amount = len(canonical(item))
            if selected and (len(selected) >= limit or size + amount > TARGET_BYTES):
                has_more = True
                stop = True
                break
            selected.append(item)
            size += amount
            last = (
                key_values(row)
                if key_values
                else [getattr(row, column.key) for column, descending in order]
            )
            if len(selected) >= limit:
                has_more = (
                    db.execute(ordered.where(after_condition(last)).limit(1)).first()
                    is not None
                )
                stop = True
                break
        if stop:
            break
    return {
        "items": selected,
        "next_cursor": encode_cursor({"scope": scope, "key": last})
        if has_more
        else None,
        "has_more": has_more,
        "projection_version": projection_version,
    }
