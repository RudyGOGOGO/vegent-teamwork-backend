from fastapi.responses import JSONResponse


def teamwork_error_response(request, error):
    body = {
        "code": error.code,
        "message": "Request could not be completed",
        "request_id": getattr(request.state, "request_id", ""),
    }
    if error.current is not None:
        body["current"] = error.current
    return JSONResponse(
        {"error": body},
        status_code=error.status_code,
        headers={
            "Cache-Control": "no-store",
            "X-Request-ID": getattr(request.state, "request_id", ""),
        },
    )


def mutation_response(data, operation, warnings=None):
    return {"data": data, "operation": operation, "warnings": warnings or []}
