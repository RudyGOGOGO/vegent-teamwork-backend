from app.schemas.auth import ServiceError


class TeamworkError(ServiceError):
    def __init__(self, code: str, status_code: int, *, current=None):
        super().__init__(code, status_code)
        self.current = current


def fail(code: str, status: int, *, current=None):
    raise TeamworkError(code, status, current=current)
