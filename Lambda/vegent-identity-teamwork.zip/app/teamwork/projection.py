from dataclasses import dataclass

from sqlalchemy import func, select

from app.models.audit_log import AuditLog
from app.models.team_member import TeamMember
from app.models.user import User
from app.teamwork.cursors import digest
from app.teamwork.models import (
    Category,
    CommentMention,
    Project,
    ProjectComment,
    ProjectContextItem,
    ProjectMember,
    ProjectPR,
    ProjectProgressEvent,
    ProjectPRReviewer,
    ProjectResource,
    ProjectResourceVersion,
    ProjectTask,
)
from app.teamwork.permissions import eligible_members
from app.teamwork.services.common import iso

PROGRESS_STATES = (
    "not_started",
    "in_progress",
    "blocked",
    "in_review",
    "completed",
    "on_hold",
)
TASK_STATES = ("todo", "in_progress", "blocked", "done")
TEXT_COLUMNS = {
    "project": Project,
    "task": ProjectTask,
    "pr": ProjectPR,
    "resource": ProjectResourceVersion,
    "context_item": ProjectContextItem,
    "progress_event": ProjectProgressEvent,
}


@dataclass
class SharedProjection:
    data: dict
    context_version: str
    members: dict
    root: Project
    node: Project


def actor_display(user_id, snapshot, users, *, db):
    if user_id in users:
        name = users[user_id].display_name or users[user_id].user_name
    else:
        name = (
            snapshot
            or db.scalar(select(User.user_name).where(User.id == user_id))
            or "Former member"
        )
    return {
        "user_id": user_id,
        "name": name,
        "membership_status": "active" if user_id in users else "former_member",
    }


def text_value(kind, row, field, node_id, hash_value, *, db, resource_version=None):
    column = getattr(
        TEXT_COLUMNS[kind], "context_text" if field == "context" else field
    )
    cached = db.info.get("teamwork_text_previews", {}).get((kind, row.id, field))
    if cached is not None:
        length, byte_length, preview = cached
    else:
        length, byte_length, preview = db.execute(
            select(
                func.char_length(column),
                func.octet_length(column),
                func.substring(column, 1, 2049),
            ).where(TEXT_COLUMNS[kind].id == row.id)
        ).one()
    if length is None:
        return None
    if length <= 2048:
        return {"inline": preview, "ref": None}
    object_id = row.resource_id if kind == "resource" else row.id
    version_query = f"&resource_version={resource_version}" if resource_version else ""
    href = f"/api/teams/{row.team_id if kind == 'project' else db.get(Project, node_id).team_id}/projects/{node_id}/context/text?kind={kind}&object_id={object_id}&field={field}{version_query}"
    return {
        "inline": None,
        "ref": {
            "kind": kind,
            "object_id": object_id,
            "field": field,
            "resource_version": resource_version,
            "context_version": hash_value,
            "utf8_bytes": byte_length,
            "href": href,
        },
    }


def project_projection(grant, *, db, node=None):
    node = node or grant.node
    root = grant.root
    cache = db.info.setdefault("teamwork_projections", {})
    if not db.info.get("teamwork_write") and node.id in cache:
        return cache[node.id]
    if not db.info.get("teamwork_write") and node.id not in db.info.get(
        "teamwork_statistics", {}
    ):
        prefetch_projection_inputs([node.id], db=db)
    membership_rows = (
        db.info.get("eligible_snapshot_rows", {}).get(root.id)
        if not db.info.get("teamwork_write")
        else None
    )
    if membership_rows is None:
        membership_rows = list(db.execute(eligible_members(root.id, db=db)))
        if not db.info.get("teamwork_write"):
            db.info.setdefault("eligible_snapshot_rows", {})[root.id] = membership_rows
    members = {user.id: user for member, user, epoch in membership_rows}
    orphan = root.ownership_state == "unassigned" or root.creator_user_id not in members
    category = db.get(Category, root.category_id) if root.category_id else None
    category_ref = (
        {
            "id": category.id,
            "name": category.name,
            "created_at": iso(category.created_at),
            "version": category.version,
        }
        if category and category.deleted_at is None
        else None
    )
    statistics = db.info.get("teamwork_statistics", {}).get(node.id)
    if statistics is not None:
        tasks = statistics["tasks"].copy()
        prs = statistics["prs"].copy()
    else:
        tasks = {k: 0 for k in TASK_STATES}
        for state, count in db.execute(
            select(ProjectTask.status, func.count())
            .where(
                ProjectTask.project_id == node.id,
                ProjectTask.lifecycle_status != "deleted",
            )
            .group_by(ProjectTask.status)
        ):
            tasks[state] = count
        tasks = {"total": sum(tasks.values()), **tasks}
        prs = {k: 0 for k in ("open", "merged", "closed")}
        for state, count in db.execute(
            select(ProjectPR.status, func.count())
            .where(ProjectPR.project_id == node.id)
            .group_by(ProjectPR.status)
        ):
            prs[state] = count
        incomplete = db.scalar(
            select(func.count())
            .select_from(ProjectPR)
            .where(
                ProjectPR.project_id == node.id,
                ProjectPR.status == "open",
                ProjectPR.reviewer_mapping_complete.is_(False),
            )
        )
        prs["reviewer_mapping_complete"] = not bool(incomplete)

    def count(cls, *extra):
        if statistics is not None:
            return statistics[cls.__tablename__]
        return db.scalar(
            select(func.count())
            .select_from(cls)
            .where(cls.project_id == node.id, *extra)
        )

    child_cache = db.info.get("teamwork_projection_children", {})
    if not db.info.get("teamwork_write") and node.id in child_cache:
        children = child_cache[node.id]
    else:
        children = (
            list(
                db.scalars(
                    select(Project)
                    .where(
                        Project.parent_project_id == node.id,
                        Project.published_at.is_not(None),
                        Project.status != "deleted",
                    )
                    .order_by(Project.id)
                )
            )
            if not node.node_depth
            else []
        )
    prefetch_statistics([child.id for child in children], db=db)
    child_hashes = [
        (c.id, project_projection(grant, db=db, node=c).context_version)
        for c in children
    ]
    counts = {
        "tasks": tasks,
        "prs": prs,
        "resources": count(
            ProjectResource,
            ProjectResource.status != "deleted",
            ProjectResource.current_version > 0,
        ),
        "comments": count(ProjectComment),
        "open_questions": count(
            ProjectContextItem,
            ProjectContextItem.kind == "open_question",
            ProjectContextItem.state == "open",
            ProjectContextItem.deleted_at.is_(None),
        ),
        "members": len(members),
        "subprojects": len(children),
    }
    root_shared = {
        "status": root.status,
        "category": category_ref,
        "creator": root.creator_user_id,
        "ownership": root.ownership_state,
        "lost_at": iso(root.ownership_lost_at),
        "lifecycle_time": iso(root.lifecycle_updated_at),
        "membership_time": iso(root.membership_updated_at),
        "ownership_time": iso(root.ownership_updated_at),
    }
    version_hash = digest(
        {
            "schema": "2.1-r3",
            "node": node.id,
            "revision": node.context_revision,
            "team": (grant.team.id, grant.team.team_name),
            "parent": (root.id, root.name) if node.node_depth else None,
            "root_shared": root_shared,
            "members": [
                (m.id, m.team_membership_id, u.id, u.display_name, u.email)
                for m, u, t in membership_rows
            ],
            "counts": counts,
            "children": child_hashes,
        }
    )
    creator = actor_display(
        root.creator_user_id, root.creator_name_snapshot, members, db=db
    )
    lost_at = root.ownership_lost_at
    if orphan and lost_at is None:
        old = db.scalar(
            select(TeamMember).where(
                TeamMember.id
                == next(
                    (
                        m.team_membership_id
                        for m in db.scalars(
                            select(ProjectMember)
                            .where(
                                ProjectMember.project_id == root.id,
                                ProjectMember.user_id == root.creator_user_id,
                            )
                            .order_by(ProjectMember.id.desc())
                        )
                    ),
                    0,
                )
            )
        )
        lost_at = old.removed_at if old else None
        if lost_at is None:
            lost_at = db.scalar(
                select(func.max(AuditLog.created_at)).where(
                    AuditLog.target_user_id == root.creator_user_id,
                    AuditLog.action == "user_deactivated",
                )
            )
    times = [node.last_activity_at]
    if node.node_depth:
        times.extend(
            [
                root.lifecycle_updated_at,
                root.membership_updated_at,
                root.ownership_updated_at,
            ]
        )
    data = {
        "id": node.id,
        "team_id": node.team_id,
        "team_name": grant.team.team_name,
        "scope": "team",
        "node_kind": "subproject" if node.node_depth else "project",
        "parent_project_id": node.parent_project_id,
        "parent": {
            "id": root.id,
            "name": root.name,
            "href": f"/api/teams/{node.team_id}/projects/{root.id}",
        }
        if node.node_depth
        else None,
        "membership_source_project_id": root.id,
        "category": category_ref,
        "name": node.name,
        "creator": creator,
        "created_by": actor_display(
            node.created_by_user_id, node.created_by_name, members, db=db
        ),
        "created_at": iso(node.created_at),
        "source_created_at": iso(node.source_created_at),
        "updated_at": iso(node.updated_at),
        "last_activity_at": iso(max(times)),
        "status": "archived" if "archived" in (node.status, root.status) else "active",
        "own_status": node.status,
        "archived_by_parent": bool(node.node_depth and root.status == "archived"),
        "ownership": {
            "state": "unassigned" if orphan else "assigned",
            "creator": creator,
            "lost_at": iso(lost_at) if orphan else None,
            "source_project_id": root.id,
        },
        "progress": {
            "status": node.progress_status,
            "note": text_value(
                "project", node, "progress_note", node.id, version_hash, db=db
            ),
            "author": actor_display(
                node.progress_note_author_id,
                node.progress_note_author_name,
                members,
                db=db,
            ),
            "updated_at": iso(node.progress_note_updated_at),
            "project_version": node.version,
        },
        "counts": counts,
        "version": node.version,
        "context_version": version_hash,
        "subprojects": {
            "count": len(children),
            "href": f"/api/teams/{node.team_id}/projects/{node.id}/subprojects"
            if not node.node_depth
            else None,
        },
    }
    result = SharedProjection(data, version_hash, members, root, node)
    if not db.info.get("teamwork_write"):
        cache[node.id] = result
    return result


def context_version(projection):
    return projection.context_version


def viewer_facts(actor, grant, *, db):
    reviewing = db.scalar(
        select(func.count(func.distinct(ProjectPR.id)))
        .join(ProjectPRReviewer, ProjectPRReviewer.pr_id == ProjectPR.id)
        .where(
            ProjectPR.project_id == grant.node.id,
            ProjectPR.status == "open",
            ProjectPRReviewer.user_id == actor.user_id,
            ProjectPRReviewer.is_current.is_(True),
        )
    )
    mentions = db.scalar(
        select(func.count(func.distinct(ProjectComment.id)))
        .join(CommentMention, CommentMention.comment_id == ProjectComment.id)
        .where(
            ProjectComment.project_id == grant.node.id,
            ProjectComment.status != "deleted",
            CommentMention.mentioned_user_id == actor.user_id,
            CommentMention.status == "active",
        )
    )
    complete = not db.scalar(
        select(func.count())
        .select_from(ProjectPR)
        .where(
            ProjectPR.project_id == grant.node.id,
            ProjectPR.status == "open",
            ProjectPR.reviewer_mapping_complete.is_(False),
        )
    )
    return {
        "open_prs_reviewing_me": reviewing,
        "reviewer_mapping_complete": complete,
        "mentioned_me_count": mentions,
        "is_creator": grant.creator,
    }


def summary(actor, grant, *, db, shared=False, projection=None):
    projection = projection or project_projection(grant, db=db)
    data = projection.data.copy()
    if not shared:
        writable = (
            data["status"] == "active" and data["ownership"]["state"] == "assigned"
        )
        why = (
            "OWNERSHIP_REQUIRED"
            if grant.orphaned
            else "PROJECT_ARCHIVED"
            if data["status"] == "archived"
            else None
        )
        data["capabilities"] = {
            "can_import": True,
            "import_disabled_reason": None,
            "can_convert": False,
            "convert_disabled_reason": "ALREADY_TEAM_PROJECT",
            "can_edit_info": writable,
            "can_manage_members": writable
            and grant.creator
            and not grant.node.node_depth,
            "can_archive": grant.creator,
            "can_unarchive": grant.creator and not data["archived_by_parent"],
            "can_delete": grant.creator,
            "read_only_reason": why,
        }
        data["viewer"] = viewer_facts(actor, grant, db=db)
    return data


def task_view(row, projection, *, db):
    users = projection.members
    hash_value = projection.context_version
    assignee = (
        actor_display(row.assignee_user_id, row.assignee_name_snapshot, users, db=db)
        if row.assignee_user_id
        else None
    )
    comments = db.scalar(
        select(func.count())
        .select_from(ProjectComment)
        .where(ProjectComment.task_id == row.id)
    )
    return {
        "id": row.id,
        "project_id": row.project_id,
        "title": row.title,
        "description": text_value(
            "task", row, "description", row.project_id, hash_value, db=db
        ),
        "status": row.status,
        "lifecycle_status": row.lifecycle_status,
        "created_by": actor_display(
            row.created_by_user_id, row.created_by_name_snapshot, users, db=db
        ),
        "driver": actor_display(
            row.driver_user_id, row.driver_name_snapshot, users, db=db
        ),
        "assignee": assignee,
        "assignee_membership_status": assignee["membership_status"]
        if assignee
        else None,
        "requires_reassignment": bool(
            assignee
            and assignee["membership_status"] == "former_member"
            and row.status != "done"
        ),
        "version": row.version,
        "created_at": iso(row.created_at),
        "updated_at": iso(row.updated_at),
        "comment_count": comments,
        "comments_href": f"/api/teams/{projection.node.team_id}/projects/{row.project_id}/comments?task_id={row.id}",
    }


def member_views(grant, *, db):
    rows = list(db.execute(eligible_members(grant.root.id, db=db)))
    users = {u.id: u for m, u, t in rows}
    return [
        {
            "project_member_id": m.id,
            "user_id": u.id,
            "name": u.display_name or u.user_name,
            "email": u.email,
            "project_role": "creator"
            if u.id == grant.root.creator_user_id
            else "member",
            "joined_at": iso(m.joined_at),
            "added_by": actor_display(
                m.added_by_user_id, m.added_by_name_snapshot, users, db=db
            ),
            "membership_status": "active",
            "_cursor_key": m.id,
        }
        for m, u, t in sorted(rows, key=lambda x: (x[0].joined_at, x[0].id))
    ]


def comment_view(row, projection, *, db):
    users = projection.members
    current = actor_display(row.author_user_id, row.author_name_snapshot, users, db=db)
    author = {
        "user_id": row.author_user_id,
        "name": current["name"],
        "role_at_creation": row.author_role_snapshot,
        "current_project_role": (
            "creator"
            if row.author_user_id == projection.root.creator_user_id
            else "member"
        )
        if row.author_user_id in users
        else None,
        "membership_status": current["membership_status"],
    }
    mentions = []
    if row.status != "deleted":
        for m in db.scalars(
            select(CommentMention)
            .where(
                CommentMention.comment_id == row.id, CommentMention.status == "active"
            )
            .order_by(CommentMention.id)
        ):
            active = m.mentioned_user_id in users
            mentions.append(
                {
                    "user_id": m.mentioned_user_id,
                    "name": m.mentioned_name_snapshot,
                    "membership_status": "active" if active else "former_member",
                    "render_as": "member_chip" if active else "former_member_chip",
                    "navigation": {
                        "type": "project_members",
                        "project_id": projection.root.id,
                        "user_id": m.mentioned_user_id,
                    }
                    if active
                    else None,
                }
            )
    return {
        "id": row.id,
        "project_id": row.project_id,
        "task_id": row.task_id,
        "pr_id": row.pr_id,
        "resource_id": row.resource_id,
        "parent_comment_id": row.parent_comment_id,
        "author": author,
        "content": "[deleted]" if row.status == "deleted" else row.content,
        "status": row.status,
        "version": row.version,
        "mentions": mentions,
        "created_at": iso(row.created_at),
        "updated_at": iso(row.updated_at),
        "edited_at": iso(row.edited_at),
        "is_edited": row.edited_at is not None,
        "deleted_at": iso(row.deleted_at),
        "is_deleted": row.status == "deleted",
    }


def context_item_view(row, projection, *, db):
    return {
        "id": row.id,
        "project_id": row.project_id,
        "kind": row.kind,
        "title": row.title,
        "context": text_value(
            "context_item",
            row,
            "context",
            row.project_id,
            projection.context_version,
            db=db,
        ),
        "body": text_value(
            "context_item",
            row,
            "body",
            row.project_id,
            projection.context_version,
            db=db,
        ),
        "answer": text_value(
            "context_item",
            row,
            "answer",
            row.project_id,
            projection.context_version,
            db=db,
        ),
        "status": row.state,
        "author": actor_display(
            row.author_user_id, row.author_name_snapshot, projection.members, db=db
        ),
        "decided_at": iso(row.decided_at),
        "version": row.version,
        "created_at": iso(row.created_at),
        "updated_at": iso(row.updated_at),
    }


def progress_event_view(row, projection, *, db):
    return {
        "id": row.id,
        "project_id": row.project_id,
        "source_project_id": row.project_id,
        "type": row.event_type,
        "actor": actor_display(
            row.actor_user_id, row.actor_name_snapshot, projection.members, db=db
        ),
        "old_status": row.old_status,
        "new_status": row.new_status,
        "old_note": text_value(
            "progress_event",
            row,
            "old_note",
            row.project_id,
            projection.context_version,
            db=db,
        ),
        "new_note": text_value(
            "progress_event",
            row,
            "new_note",
            row.project_id,
            projection.context_version,
            db=db,
        ),
        "project_version": row.project_version,
        "created_at": iso(row.created_at),
        "inherited": False,
    }


def activity_view(row, node, projection, *, db):
    return {
        "id": row.id,
        "project_id": node.id,
        "project_name": node.name,
        "parent_project_id": node.parent_project_id,
        "actor": actor_display(
            row.actor_user_id, row.actor_name_snapshot, projection.members, db=db
        ),
        "type": row.event_type,
        "object": {
            "type": row.object_type,
            "id": row.object_id,
            "version": row.object_version,
            "href": None,
        },
        "time": iso(row.created_at),
        "inherited": row.project_id != node.id,
    }


def prefetch_statistics(node_ids, *, db):
    """Batch shared count inputs inside the current coherent read transaction."""
    if db.info.get("teamwork_write"):
        return
    cache = db.info.setdefault("teamwork_statistics", {})
    missing = [nid for nid in node_ids if nid not in cache]
    if not missing:
        return
    for nid in missing:
        cache[nid] = {
            "tasks": {"total": 0, **dict.fromkeys(TASK_STATES, 0)},
            "prs": {
                "open": 0,
                "merged": 0,
                "closed": 0,
                "reviewer_mapping_complete": True,
            },
            "project_resources": 0,
            "project_comments": 0,
            "project_context_items": 0,
        }
    for nid, status, total in db.execute(
        select(ProjectTask.project_id, ProjectTask.status, func.count())
        .where(
            ProjectTask.project_id.in_(missing),
            ProjectTask.lifecycle_status != "deleted",
        )
        .group_by(ProjectTask.project_id, ProjectTask.status)
    ):
        cache[nid]["tasks"][status] = total
        cache[nid]["tasks"]["total"] += total
    for nid, status, total in db.execute(
        select(ProjectPR.project_id, ProjectPR.status, func.count())
        .where(ProjectPR.project_id.in_(missing))
        .group_by(ProjectPR.project_id, ProjectPR.status)
    ):
        cache[nid]["prs"][status] = total
    for nid in db.scalars(
        select(ProjectPR.project_id)
        .where(
            ProjectPR.project_id.in_(missing),
            ProjectPR.status == "open",
            ProjectPR.reviewer_mapping_complete.is_(False),
        )
        .distinct()
    ):
        cache[nid]["prs"]["reviewer_mapping_complete"] = False
    for cls, extra in (
        (
            ProjectResource,
            [ProjectResource.status != "deleted", ProjectResource.current_version > 0],
        ),
        (ProjectComment, []),
        (
            ProjectContextItem,
            [
                ProjectContextItem.kind == "open_question",
                ProjectContextItem.state == "open",
                ProjectContextItem.deleted_at.is_(None),
            ],
        ),
    ):
        for nid, total in db.execute(
            select(cls.project_id, func.count())
            .where(cls.project_id.in_(missing), *extra)
            .group_by(cls.project_id)
        ):
            cache[nid][cls.__tablename__] = total


def prefetch_projection_inputs(node_ids, *, db):
    """Batch only this SQL page's shared inputs in its authorized read transaction.

    User/Team shared locks and the RR snapshot remain held. Nothing is cached
    across sessions/requests; write sessions always use current ordered checks.
    """
    if db.info.get("teamwork_write") or not node_ids:
        return
    nodes = list(db.scalars(select(Project).where(Project.id.in_(node_ids))))
    roots = {node.parent_project_id or node.id for node in nodes}
    root_nodes = [node for node in nodes if not node.node_depth]
    children = {node.id: [] for node in root_nodes}
    all_nodes = {node.id: node for node in nodes}
    if children:
        for child in db.scalars(
            select(Project)
            .where(
                Project.parent_project_id.in_(children),
                Project.status != "deleted",
                Project.published_at.is_not(None),
            )
            .order_by(Project.id)
        ):
            children[child.parent_project_id].append(child)
            all_nodes[child.id] = child
        db.info.setdefault("teamwork_projection_children", {}).update(children)
    snapshots = db.info.setdefault("eligible_snapshot_rows", {})
    missing = roots - snapshots.keys()
    if missing:
        for rid in missing:
            snapshots[rid] = []
        for member, user, epoch in db.execute(eligible_members(tuple(missing), db=db)):
            snapshots[member.project_id].append((member, user, epoch))
    prefetch_statistics(list(all_nodes), db=db)
    previews = db.info.setdefault("teamwork_text_previews", {})
    for nid, length, size, text in db.execute(
        select(
            Project.id,
            func.char_length(Project.progress_note),
            func.octet_length(Project.progress_note),
            func.substring(Project.progress_note, 1, 2049),
        ).where(Project.id.in_(all_nodes))
    ):
        previews[("project", nid, "progress_note")] = (length, size, text)
