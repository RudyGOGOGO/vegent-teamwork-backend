import json
import re
import urllib.error
import urllib.request
from urllib.parse import urlsplit

import boto3
from botocore.config import Config
from sqlalchemy import case, func, select

from app.services.team_members import utcnow
from app.teamwork.cursors import decode_cursor, digest, encode_cursor
from app.teamwork.errors import fail
from app.teamwork.models import ProjectComment, ProjectPR, ProjectPRReviewer
from app.teamwork.operations import begin_operation, complete_operation, operation_view
from app.teamwork.paging import sql_page
from app.teamwork.permissions import Action, require_project
from app.teamwork.projection import project_projection, text_value
from app.teamwork.services.common import event, iso, touch, version


def pr_view(row, projection, *, db):
    cached = db.info.get("pr_metadata", {}).get(row.id)
    people = (
        cached[0]
        if cached
        else db.scalars(
            select(ProjectPRReviewer)
            .where(
                ProjectPRReviewer.pr_id == row.id,
                ProjectPRReviewer.is_current.is_(True),
            )
            .order_by(ProjectPRReviewer.id)
        )
    )
    reviewers = [
        {
            "user_id": r.user_id,
            "name": r.display_name,
            "membership_status": "external"
            if r.user_id is None
            else "active"
            if r.user_id in projection.members
            else "former_member",
        }
        for r in people
    ]
    comments = (
        cached[1]
        if cached
        else db.scalar(
            select(func.count())
            .select_from(ProjectComment)
            .where(ProjectComment.pr_id == row.id)
        )
    )
    return {
        "id": row.id,
        "project_id": row.project_id,
        "provider": row.provider,
        "repository_ref": row.repository_ref,
        "external_pr_id": row.external_pr_id,
        "title": text_value(
            "pr", row, "title", row.project_id, projection.context_version, db=db
        ),
        "url": row.url,
        "branch": text_value(
            "pr", row, "branch", row.project_id, projection.context_version, db=db
        ),
        "status": row.status,
        "reviewers": reviewers,
        "reviewer_mapping_complete": row.reviewer_mapping_complete,
        "synced_at": iso(row.synced_at),
        "version": row.version,
        "comment_count": comments,
        "comments_href": f"/api/teams/{projection.node.team_id}/projects/{row.project_id}/comments?pr_id={row.id}",
    }


def list_prs(actor, team_id, node_id, query, *, db, shared=False):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    q = select(ProjectPR).where(ProjectPR.project_id == node_id)
    status = query.get("status", "all")
    sort = query.get("sort", "open_first")
    if status not in ("open", "merged", "closed", "all") or sort not in (
        "open_first",
        "recent",
    ):
        fail("VALIDATION_ERROR", 422)
    if status != "all":
        q = q.where(ProjectPR.status == status)
    if query.get("reviewing_me") is not None:
        exists = (
            select(ProjectPRReviewer.id)
            .where(
                ProjectPRReviewer.pr_id == ProjectPR.id,
                ProjectPRReviewer.user_id == actor.user_id,
                ProjectPRReviewer.is_current.is_(True),
            )
            .exists()
        )
        q = q.where(exists if query["reviewing_me"] else ~exists)
    priority = case((ProjectPR.status == "open", 0), else_=1).label("sort_open")
    order = ([(priority, False)] if sort == "open_first" else []) + [
        (ProjectPR.synced_at, True),
        (ProjectPR.id, True),
    ]
    q = q.add_columns(priority)

    def prefetch(rows):
        ids = [row[0].id for row in rows]
        counts = dict(
            db.execute(
                select(ProjectComment.pr_id, func.count())
                .where(ProjectComment.pr_id.in_(ids))
                .group_by(ProjectComment.pr_id)
            ).all()
        )
        people = {id: [] for id in ids}
        for reviewer in db.scalars(
            select(ProjectPRReviewer)
            .where(
                ProjectPRReviewer.pr_id.in_(ids), ProjectPRReviewer.is_current.is_(True)
            )
            .order_by(ProjectPRReviewer.id)
        ):
            people[reviewer.pr_id].append(reviewer)
        db.info.setdefault("pr_metadata", {}).update(
            {id: (people[id], counts.get(id, 0)) for id in ids}
        )

    return sql_page(
        q,
        ProjectPR,
        lambda row: pr_view(row[0], projection, db=db),
        db=db,
        scope={
            "kind": "prs",
            "node": node_id,
            "query": {k: v for k, v in query.items() if k not in ("cursor", "limit")},
            "actor": None if shared else actor.user_id,
        },
        order=order,
        row_mode=True,
        key_values=lambda row: (
            ([row[1]] if sort == "open_first" else []) + [row[0].synced_at, row[0].id]
        ),
        prepare_rows=prefetch,
        limit=query.get("limit", 50),
        cursor=query.get("cursor"),
        projection_version=projection.context_version,
    )


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "Redirect denied", headers, fp)


def provider_config(repository_ref, provider, team_id, node_id):
    import os

    reference = os.environ.get("VEGENT_TEAMWORK_PROVIDER_CONFIG_SECRET_ID")
    if not reference:
        fail("PROVIDER_NOT_CONFIGURED", 503)
    try:
        value = json.loads(
            boto3.client(
                "secretsmanager",
                config=Config(
                    connect_timeout=1, read_timeout=2, retries={"max_attempts": 1}
                ),
            ).get_secret_value(SecretId=reference)["SecretString"]
        )
        config = value["repositories"][repository_ref]
        if config["provider"] != provider:
            fail("INVALID_REPOSITORY", 422)
        teams = config.get("team_ids")
        projects = config.get("project_ids")
        if (
            not isinstance(teams, list)
            or not teams
            or any(type(i) is not int or i <= 0 for i in teams)
        ):
            fail("INVALID_PROVIDER_CONFIG", 503)
        if projects is not None and (
            not isinstance(projects, list)
            or any(type(i) is not int or i <= 0 for i in projects)
        ):
            fail("INVALID_PROVIDER_CONFIG", 503)
        if team_id not in teams or projects is not None and node_id not in projects:
            fail("INVALID_REPOSITORY", 422)
        for k in ("api_base", "web_base"):
            parsed = urlsplit(config[k])
            if (
                parsed.scheme != "https"
                or parsed.hostname not in value["allowed_hosts"]
                or parsed.username
                or parsed.password
                or parsed.query
                or parsed.fragment
            ):
                fail("INVALID_PROVIDER_CONFIG", 503)
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", config["repository"]):
            fail("INVALID_PROVIDER_CONFIG", 503)
        return config
    except KeyError:
        fail("INVALID_REPOSITORY", 422)
    except Exception as exc:
        from app.teamwork.errors import TeamworkError

        if isinstance(exc, TeamworkError):
            raise
        fail("PROVIDER_UNAVAILABLE", 503)


def fetch_provider_page(config, provider, ids, page_number):
    repository = config["repository"]
    base = config["api_base"].rstrip("/")
    selected = ids[page_number : page_number + 1] if ids else None
    if selected and not re.fullmatch(r"[1-9][0-9]*", selected[0]):
        fail("VALIDATION_ERROR", 422)
    if provider == "github":
        suffix = (
            f"/repos/{repository}/pulls/" + selected[0]
            if selected
            else f"/repos/{repository}/pulls?state=all&per_page=100&page={page_number + 1}"
        )
    else:
        project, repo = repository.split("/")
        suffix = (
            f"/projects/{project}/repos/{repo}/pull-requests/" + selected[0]
            if selected
            else f"/projects/{project}/repos/{repo}/pull-requests?state=ALL&limit=100&start={page_number}"
        )
    request = urllib.request.Request(
        base + suffix,
        headers={
            "Accept": "application/json",
            "Authorization": "Bearer " + config["token"],
        },
    )
    try:
        with urllib.request.build_opener(NoRedirect).open(
            request, timeout=3
        ) as response:
            raw = json.load(response)
    except Exception:
        fail("PROVIDER_UNAVAILABLE", 503)
    if selected:
        items = [raw]
        next_page = page_number + 1 if page_number + 1 < len(ids) else None
    elif provider == "github":
        items = raw
        next_page = page_number + 1 if len(items) == 100 else None
    else:
        items = raw["values"]
        next_page = None if raw.get("isLastPage") else raw.get("nextPageStart")
    records = []
    mapping = config.get("reviewer_map", {})
    for item in items:
        external = str(item["number"] if provider == "github" else item["id"])
        if not re.fullmatch("[1-9][0-9]*", external):
            fail("INVALID_PROVIDER_DATA", 503)
        if provider == "github":
            state = (
                "merged"
                if item.get("merged_at") or item.get("merged")
                else "open"
                if item["state"] == "open"
                else "closed"
            )
            branch = item.get("head", {}).get("ref", "")
            reviewers = item.get("requested_reviewers", [])
            url = (
                config["web_base"].rstrip("/") + "/" + repository + "/pull/" + external
            )
        else:
            state = {"OPEN": "open", "MERGED": "merged", "DECLINED": "closed"}.get(
                item["state"]
            )
            if state is None:
                fail("INVALID_PROVIDER_DATA", 503)
            branch = item.get("fromRef", {}).get("displayId", "")
            reviewers = [r["user"] for r in item.get("reviewers", [])]
            project, repo = repository.split("/")
            url = (
                config["web_base"].rstrip("/")
                + f"/projects/{project}/repos/{repo}/pull-requests/{external}"
            )
        people = [
            {
                "external_id": str(r["id"]),
                "user_id": mapping.get(str(r["id"])),
                "name": str(
                    r.get("displayName")
                    or r.get("login")
                    or r.get("name")
                    or "External reviewer"
                ),
            }
            for r in reviewers
        ]
        records.append(
            {
                "external_id": external,
                "title": str(item["title"]),
                "url": url,
                "branch": str(branch),
                "state": state,
                "reviewers": people,
            }
        )
    return records, next_page


def sync_prs(
    actor, team_id, node_id, body, expected_version, operation, continuation=None
):
    from app.teamwork.transactions import write_session

    scope = {
        "kind": "pr_sync",
        "actor": actor.user_id,
        "team": team_id,
        "node": node_id,
        "body": digest(body.model_dump()),
    }
    position = decode_cursor(continuation, scope)["page"] if continuation else 0
    with write_session() as db:
        db.info["teamwork_write"] = True
        grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
        state = begin_operation(actor, operation.key, operation, db=db)
        if state.replayed:
            data = dict(state.row.response_ref["sync"])
            return data, operation_view(state)
        version(grant.node, expected_version)
    config = provider_config(body.repository_ref, body.provider, team_id, node_id)
    records, next_page = fetch_provider_page(
        config, body.provider, body.external_pr_ids, position
    )
    with write_session() as db:
        db.info["teamwork_write"] = True
        grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
        state = begin_operation(actor, operation.key, operation, db=db)
        if state.replayed:
            data = dict(state.row.response_ref["sync"])
            return data, operation_view(state)
        version(grant.node, expected_version)
        now = utcnow()
        for item in records:
            row = db.scalar(
                select(ProjectPR)
                .where(
                    ProjectPR.project_id == node_id,
                    ProjectPR.provider == body.provider,
                    ProjectPR.repository_ref == body.repository_ref,
                    ProjectPR.external_pr_id == item["external_id"],
                )
                .with_for_update()
            )
            if row is None:
                row = ProjectPR(
                    project_id=node_id,
                    provider=body.provider,
                    repository_ref=body.repository_ref,
                    external_pr_id=item["external_id"],
                    version=1,
                )
                db.add(row)
            else:
                row.version += 1
            row.title = item["title"]
            row.url = item["url"]
            row.branch = item["branch"]
            row.status = item["state"]
            row.synced_at = now
            from app.teamwork.permissions import eligible_members

            eligible_ids = {
                u.id for m, u, t in db.execute(eligible_members(grant.root.id, db=db))
            }
            for reviewer in item["reviewers"]:
                uid = reviewer["user_id"]
                if type(uid) is not int or uid not in eligible_ids:
                    reviewer["user_id"] = None
            row.reviewer_mapping_complete = all(
                r["user_id"] is not None for r in item["reviewers"]
            )
            db.flush()
            old = {
                r.external_reviewer_id: r
                for r in db.scalars(
                    select(ProjectPRReviewer).where(ProjectPRReviewer.pr_id == row.id)
                )
            }
            for value in old.values():
                value.is_current = False
                value.updated_at = now
            for person in item["reviewers"]:
                value = old.get(person["external_id"])
                if value is None:
                    value = ProjectPRReviewer(
                        pr_id=row.id, external_reviewer_id=person["external_id"]
                    )
                    db.add(value)
                value.user_id = person["user_id"]
                value.display_name = person["name"]
                value.is_current = True
                value.updated_at = now
        if records:
            touch(grant.node)
            event(
                actor,
                grant.node,
                "prs_synced",
                db=db,
                object_type="pr",
                detail={"count": len(records)},
            )
        db.flush()
        result = {
            "state": "completed" if next_page is None else "running",
            "continuation": encode_cursor({"scope": scope, "page": next_page})
            if next_page is not None
            else None,
            "updated_prs": len(records),
            "project_version": grant.node.version,
        }

        complete_operation(
            state,
            {"kind": "sync", "sync": result, "version": grant.node.version},
            db=db,
        )
        return result, operation_view(state)
