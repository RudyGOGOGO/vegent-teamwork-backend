from sqlalchemy import select

from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import ProjectProgressEvent
from app.teamwork.paging import sql_page
from app.teamwork.permissions import Action, require_project
from app.teamwork.projection import progress_event_view, project_projection
from app.teamwork.services.common import event, label, nonempty_patch, touch, version


def update_progress(actor, team_id, node_id, body, expected_version, operation, *, db):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    current = project_projection(grant, db=db).data["progress"]
    version(grant.node, expected_version, current)
    fields = nonempty_patch(body)
    if any(v is None for v in fields.values()):
        fail("VALIDATION_ERROR", 422)
    row = grant.node
    status = fields.get("status", row.progress_status)
    note = fields.get("note", row.progress_note)
    if status != row.progress_status or note != row.progress_note:
        now = utcnow()
        old_status = row.progress_status
        old_note = row.progress_note
        row.progress_status = status
        row.progress_note = note
        row.progress_note_author_id = actor.user_id
        row.progress_note_author_name = label(grant.user)
        row.progress_note_updated_at = now
        touch(row, now=now)
        db.add(
            ProjectProgressEvent(
                project_id=node_id,
                project_version=row.version,
                event_type="progress_changed",
                actor_user_id=actor.user_id,
                actor_name_snapshot=label(grant.user),
                old_status=old_status,
                new_status=status,
                old_note=old_note,
                new_note=note,
                created_at=now,
            )
        )
        event(actor, row, "progress_changed", db=db)
    db.flush()
    return project_projection(grant, db=db).data["progress"]


def list_progress_events(actor, team_id, node_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    q = select(ProjectProgressEvent).where(ProjectProgressEvent.project_id == node_id)
    return sql_page(
        q,
        ProjectProgressEvent,
        lambda row: progress_event_view(row, projection, db=db),
        db=db,
        scope={"kind": "progress", "node": node_id},
        order=[
            (ProjectProgressEvent.created_at, True),
            (ProjectProgressEvent.id, True),
        ],
        limit=query.limit,
        cursor=query.cursor,
        projection_version=projection.context_version,
    )
