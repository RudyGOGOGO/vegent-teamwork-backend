from sqlalchemy import select

from app.models.user import User
from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import Category
from app.teamwork.paging import sql_page
from app.teamwork.permissions import require_team
from app.teamwork.services.common import (
    audit,
    confirmation,
    iso,
    label,
    name,
    nonempty_patch,
    version,
)


def category_view(row, *, db):
    user = db.get(User, row.created_by_user_id)
    return {
        "id": row.id,
        "team_id": row.team_id,
        "name": row.name,
        "created_at": iso(row.created_at),
        "updated_at": iso(row.updated_at),
        "version": row.version,
        "created_by": {
            "user_id": user.id,
            "name": label(user),
            "membership_status": "active" if user.is_active else "former_member",
        },
    }


def list_categories(actor, team_id, query, *, db):
    require_team(actor, team_id, db=db)
    return sql_page(
        visible_categories(actor, team_id, db=db),
        Category,
        lambda row: category_view(row, db=db),
        db=db,
        scope={"kind": "categories", "team": team_id, "actor": actor.user_id},
        order=[(Category.created_at, False), (Category.id, False)],
        limit=query.limit,
        cursor=query.cursor,
    )


def visible_categories(actor, team_id, *, db):
    from app.teamwork.models import Project

    from .dashboard import visible_nodes

    roots = (
        visible_nodes(actor, team_id, db=db)
        .with_only_columns(Project.category_id)
        .where(Project.node_depth == 0)
    )
    return select(Category).where(
        Category.team_id == team_id,
        Category.deleted_at.is_(None),
        Category.id.in_(roots),
    )


def create_category(actor, team_id, body, operation, *, db):
    require_team(actor, team_id, db=db)
    value = name(body.name)
    if db.scalar(
        select(Category.id).where(
            Category.team_id == team_id,
            Category.name == value,
            Category.deleted_at.is_(None),
        )
    ):
        fail("DUPLICATE", 409)
    now = utcnow()
    row = Category(
        team_id=team_id,
        name=value,
        created_by_user_id=actor.user_id,
        version=1,
        created_at=now,
        updated_at=now,
    )
    db.add(row)
    db.flush()
    audit(actor, team_id, "category_created", db=db, resource_id=row.id)
    return category_view(row, db=db)


def _own(actor, team_id, category_id, *, db):
    require_team(actor, team_id, db=db)
    row = db.scalar(
        select(Category)
        .where(
            Category.id == category_id,
            Category.team_id == team_id,
            Category.deleted_at.is_(None),
        )
        .with_for_update()
    )
    if row is None:
        fail("NOT_FOUND", 404)
    if row.created_by_user_id != actor.user_id:
        fail("FORBIDDEN", 403)
    return row


def patch_category(
    actor, team_id, category_id, body, expected_version, operation, *, db
):
    row = _own(actor, team_id, category_id, db=db)
    version(row, expected_version)
    fields = nonempty_patch(body)
    value = name(fields["name"])
    if value != row.name:
        if db.scalar(
            select(Category.id).where(
                Category.team_id == team_id,
                Category.name == value,
                Category.deleted_at.is_(None),
                Category.id != row.id,
            )
        ):
            fail("DUPLICATE", 409)
        row.name = value
        row.version += 1
        row.updated_at = utcnow()
        audit(actor, team_id, "category_updated", db=db, resource_id=row.id)
    return category_view(row, db=db)


def retire_category(
    actor, team_id, category_id, body, expected_version, operation, *, db
):
    row = _own(actor, team_id, category_id, db=db)
    version(row, expected_version)
    confirmation(body)
    row.deleted_at = row.updated_at = utcnow()
    row.version += 1
    audit(actor, team_id, "category_retired", db=db, resource_id=row.id)
