from datetime import UTC

from sqlalchemy import select

from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import ProjectContextItem, ProjectContextItemRevision
from app.teamwork.paging import sql_page
from app.teamwork.permissions import Action, require_project
from app.teamwork.projection import context_item_view, project_projection
from app.teamwork.services.common import (
    confirmation,
    event,
    iso,
    label,
    name,
    nonempty_patch,
    scoped,
    touch,
    version,
)


def _state(row):
    valid = (
        ("proposed", "accepted", "superseded", "withdrawn")
        if row.kind == "decision"
        else ("open", "answered", "closed")
    )
    if (
        row.state not in valid
        or row.kind == "decision"
        and (
            row.answer is not None or row.state == "accepted" and row.decided_at is None
        )
        or row.kind == "open_question"
        and (
            row.decided_at is not None
            or row.state == "answered"
            and not (row.answer or "").strip()
        )
    ):
        fail("VALIDATION_ERROR", 422)


def _time(value):
    if value is not None:
        if value.tzinfo is None or value.year < 1000:
            fail("VALIDATION_ERROR", 422)
        return value.astimezone(UTC).replace(tzinfo=None)
    return None


def _revision(row, actor, *, db):
    snapshot = {
        k: getattr(row, k)
        for k in ("title", "kind", "context_text", "body", "answer", "state")
    }
    snapshot.update(decided_at=iso(row.decided_at), deleted_at=iso(row.deleted_at))
    db.add(
        ProjectContextItemRevision(
            item_id=row.id,
            version=row.version,
            actor_user_id=actor.user_id,
            snapshot=snapshot,
            created_at=utcnow(),
        )
    )


def create_item(actor, team_id, node_id, body, operation, *, db):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    now = utcnow()
    row = ProjectContextItem(
        project_id=node_id,
        kind=body.kind,
        title=name(body.title),
        context_text=body.context,
        body=body.body,
        answer=body.answer,
        state=body.status,
        author_user_id=actor.user_id,
        author_name_snapshot=label(grant.user),
        decided_at=_time(body.decided_at),
        version=1,
        created_at=now,
        updated_at=now,
    )
    _state(row)
    db.add(row)
    db.flush()
    _revision(row, actor, db=db)
    touch(grant.node)
    event(
        actor,
        grant.node,
        "context_item_created",
        db=db,
        object_type="context_item",
        object_id=row.id,
        object_version=row.version,
    )
    db.flush()
    return context_item_view(row, project_projection(grant, db=db), db=db)


def patch_item(
    actor, team_id, node_id, item_id, body, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    row = scoped(ProjectContextItem, node_id, item_id, db=db)
    if row.deleted_at is not None:
        fail("NOT_FOUND", 404)
    if not grant.creator and row.author_user_id != actor.user_id:
        fail("FORBIDDEN", 403)
    version(row, expected_version)
    fields = nonempty_patch(body)
    mapping = {"context": "context_text", "status": "state"}
    changed = False
    for k, v in fields.items():
        k = mapping.get(k, k)
        if v is None and k not in ("answer", "decided_at"):
            fail("VALIDATION_ERROR", 422)
        if k == "title":
            v = name(v)
        if k == "decided_at":
            v = _time(v)
        if getattr(row, k) != v:
            changed = True
            setattr(row, k, v)
    _state(row)
    if changed:
        row.version += 1
        row.updated_at = utcnow()
        _revision(row, actor, db=db)
        touch(grant.node)
        event(
            actor,
            grant.node,
            "context_item_updated",
            db=db,
            object_type="context_item",
            object_id=row.id,
            object_version=row.version,
        )
    db.flush()
    return context_item_view(row, project_projection(grant, db=db), db=db)


def delete_item(
    actor, team_id, node_id, item_id, body, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    row = scoped(ProjectContextItem, node_id, item_id, db=db)
    if row.deleted_at:
        fail("NOT_FOUND", 404)
    if not grant.creator and row.author_user_id != actor.user_id:
        fail("FORBIDDEN", 403)
    version(row, expected_version)
    confirmation(body)
    row.deleted_at = row.updated_at = utcnow()
    row.version += 1
    _revision(row, actor, db=db)
    touch(grant.node)
    event(
        actor,
        grant.node,
        "context_item_deleted",
        db=db,
        object_type="context_item",
        object_id=row.id,
        object_version=row.version,
    )


def list_items(actor, team_id, node_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    q = select(ProjectContextItem).where(
        ProjectContextItem.project_id == node_id,
        ProjectContextItem.deleted_at.is_(None),
    )
    if query.get("kind"):
        if query["kind"] not in ("decision", "open_question"):
            fail("VALIDATION_ERROR", 422)
        q = q.where(ProjectContextItem.kind == query["kind"])
    if query.get("status"):
        if query["status"] not in (
            "proposed",
            "accepted",
            "superseded",
            "withdrawn",
            "open",
            "answered",
            "closed",
        ):
            fail("VALIDATION_ERROR", 422)
        q = q.where(ProjectContextItem.state == query["status"])
    return sql_page(
        q,
        ProjectContextItem,
        lambda row: context_item_view(row, projection, db=db),
        db=db,
        scope={
            "kind": "items",
            "node": node_id,
            "filter": {k: v for k, v in query.items() if k not in ("limit", "cursor")},
        },
        order=[(ProjectContextItem.created_at, False), (ProjectContextItem.id, False)],
        limit=query.get("limit", 50),
        cursor=query.get("cursor"),
        projection_version=projection.context_version,
    )
