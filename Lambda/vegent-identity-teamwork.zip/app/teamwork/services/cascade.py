from dataclasses import dataclass

from sqlalchemy import select

from app.teamwork.models import Project, ProjectMember
from app.teamwork.services.common import event, touch


@dataclass(frozen=True)
class MembershipRemoval:
    actor: object
    team_id: int
    user_id: int
    team_membership_id: int
    removed_at: object


@dataclass(frozen=True)
class CascadeResult:
    memberships: int
    projects: int


def cascade_team_removal(removal, *, db):
    rows = list(
        db.scalars(
            select(ProjectMember)
            .where(
                ProjectMember.team_id == removal.team_id,
                ProjectMember.team_membership_id == removal.team_membership_id,
                ProjectMember.status == "active",
            )
            .order_by(ProjectMember.project_id, ProjectMember.id)
        )
    )
    count = 0
    for membership in rows:
        root = db.scalar(
            select(Project).where(Project.id == membership.project_id).with_for_update()
        )
        membership.status = "removed"
        membership.removed_at = removal.removed_at
        membership.removed_by_user_id = removal.actor.user_id
        membership.removal_reason = "team_removal"
        root.membership_updated_at = removal.removed_at
        if root.creator_user_id == removal.user_id:
            root.ownership_state = "unassigned"
            root.ownership_lost_at = removal.removed_at
            root.ownership_updated_at = removal.removed_at
        nodes = [root] + list(
            db.scalars(
                select(Project)
                .where(Project.parent_project_id == root.id)
                .order_by(Project.id)
                .with_for_update()
            )
        )
        for node in nodes:
            touch(node, now=removal.removed_at)
            event(
                removal.actor,
                node,
                "project_member_removed",
                db=db,
                object_type="member",
                object_id=membership.id,
                detail={
                    "target_user_id": removal.user_id,
                    "source_team_membership_id": removal.team_membership_id,
                    "inherited": bool(node.node_depth),
                },
                now=removal.removed_at,
            )
            if root.creator_user_id == removal.user_id:
                event(
                    removal.actor,
                    node,
                    "project_ownership_lost",
                    db=db,
                    detail={"creator_user_id": removal.user_id},
                    now=removal.removed_at,
                )
            count += 1
    db.flush()
    return CascadeResult(len(rows), count)
