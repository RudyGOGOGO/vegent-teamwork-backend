from sqlalchemy import select

from app.models.user import User
from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import ProjectTask
from app.teamwork.paging import sql_page
from app.teamwork.permissions import Action, require_eligible, require_project
from app.teamwork.projection import project_projection, task_view
from app.teamwork.services.common import (
    confirmation,
    event,
    label,
    name,
    nonempty_patch,
    scoped,
    touch,
    version,
)


def create_task(actor, team_id, node_id, body, operation, *, db):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    if body.assignee_user_id:
        require_eligible(grant, body.assignee_user_id, db=db)
    now = utcnow()
    target = db.get(User, body.assignee_user_id) if body.assignee_user_id else None
    row = ProjectTask(
        project_id=node_id,
        title=name(body.title),
        description=body.description,
        status="todo",
        lifecycle_status="active",
        created_by_user_id=actor.user_id,
        created_by_name_snapshot=label(grant.user),
        driver_user_id=actor.user_id,
        driver_name_snapshot=label(grant.user),
        assignee_user_id=body.assignee_user_id,
        assignee_name_snapshot=label(target) if target else None,
        version=1,
        created_at=now,
        updated_at=now,
    )
    db.add(row)
    db.flush()
    touch(grant.node)
    event(
        actor,
        grant.node,
        "task_created",
        db=db,
        object_type="task",
        object_id=row.id,
        object_version=row.version,
    )
    return task_view(row, project_projection(grant, db=db), db=db)


def _write(
    actor, team_id, node_id, task_id, expected_version, *, db, allow_archived=False
):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    row = scoped(ProjectTask, node_id, task_id, db=db, deleted_field="lifecycle_status")
    return grant, row


def patch_task(
    actor, team_id, node_id, task_id, body, expected_version, operation, *, db
):
    grant, row = _write(actor, team_id, node_id, task_id, expected_version, db=db)
    if not grant.creator and row.driver_user_id != actor.user_id:
        fail("FORBIDDEN", 403)
    version(
        row, expected_version, task_view(row, project_projection(grant, db=db), db=db)
    )
    if row.lifecycle_status == "archived":
        fail("TASK_ARCHIVED", 409)
    fields = nonempty_patch(body)
    for key in ("driver_user_id", "assignee_user_id"):
        if key in fields and fields[key] is not None:
            require_eligible(grant, fields[key], db=db)
    if "driver_user_id" in fields and fields["driver_user_id"] is None:
        fail("VALIDATION_ERROR", 422)
    if "title" in fields:
        fields["title"] = name(fields["title"])
    if "description" in fields and fields["description"] is None:
        fail("VALIDATION_ERROR", 422)
    changed = any(getattr(row, k) != v for k, v in fields.items())
    if changed:
        for key, value in fields.items():
            setattr(row, key, value)
        for key, snapshot in [
            ("driver_user_id", "driver_name_snapshot"),
            ("assignee_user_id", "assignee_name_snapshot"),
        ]:
            if key in fields:
                setattr(
                    row,
                    snapshot,
                    label(db.get(User, fields[key])) if fields[key] else None,
                )
        row.version += 1
        row.updated_at = utcnow()
        touch(grant.node)
        event(
            actor,
            grant.node,
            "task_updated",
            db=db,
            object_type="task",
            object_id=row.id,
            object_version=row.version,
        )
    db.flush()
    return task_view(row, project_projection(grant, db=db), db=db)


def change_task_status(
    actor, team_id, node_id, task_id, body, expected_version, operation, *, db
):
    grant, row = _write(actor, team_id, node_id, task_id, expected_version, db=db)
    if not grant.creator and actor.user_id not in (
        row.driver_user_id,
        row.assignee_user_id,
    ):
        fail("FORBIDDEN", 403)
    version(
        row, expected_version, task_view(row, project_projection(grant, db=db), db=db)
    )
    if row.lifecycle_status == "archived":
        fail("TASK_ARCHIVED", 409)
    if row.status != body.status:
        row.status = body.status
        row.version += 1
        row.updated_at = utcnow()
        touch(grant.node)
        event(
            actor,
            grant.node,
            "task_status_changed",
            db=db,
            object_type="task",
            object_id=row.id,
            object_version=row.version,
        )
    db.flush()
    return task_view(row, project_projection(grant, db=db), db=db)


def change_task_lifecycle(
    actor, team_id, node_id, task_id, action, body, expected_version, operation, *, db
):
    grant, row = _write(
        actor, team_id, node_id, task_id, expected_version, db=db, allow_archived=True
    )
    if not grant.creator and (
        action == "delete" or row.driver_user_id != actor.user_id
    ):
        fail("FORBIDDEN", 403)
    version(
        row, expected_version, task_view(row, project_projection(grant, db=db), db=db)
    )
    if action == "delete":
        confirmation(body)
    target = {"archive": "archived", "unarchive": "active", "delete": "deleted"}[action]
    if row.lifecycle_status != target:
        row.lifecycle_status = target
        row.version += 1
        row.updated_at = utcnow()
        touch(grant.node)
        event(
            actor,
            grant.node,
            "task_" + action,
            db=db,
            object_type="task",
            object_id=row.id,
            object_version=row.version,
        )
    if action == "delete":
        return None
    db.flush()
    return task_view(row, project_projection(grant, db=db), db=db)


def list_tasks(actor, team_id, node_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    q = select(ProjectTask).where(
        ProjectTask.project_id == node_id, ProjectTask.lifecycle_status != "deleted"
    )
    status = query.get("status")
    lifecycle = query.get("lifecycle_status", "all")
    if (
        status
        and status not in ("todo", "in_progress", "blocked", "done")
        or lifecycle not in ("active", "archived", "all")
    ):
        fail("VALIDATION_ERROR", 422)
    if status:
        q = q.where(ProjectTask.status == status)
    if lifecycle != "all":
        q = q.where(ProjectTask.lifecycle_status == lifecycle)
    if query.get("assignee_user_id") is not None:
        q = q.where(ProjectTask.assignee_user_id == query["assignee_user_id"])
    return sql_page(
        q,
        ProjectTask,
        lambda row: task_view(row, projection, db=db),
        db=db,
        scope={
            "kind": "tasks",
            "node": node_id,
            "filter": {k: v for k, v in query.items() if k not in ("limit", "cursor")},
        },
        order=[(ProjectTask.created_at, False), (ProjectTask.id, False)],
        limit=query.get("limit", 50),
        cursor=query.get("cursor"),
        projection_version=projection.context_version,
    )
