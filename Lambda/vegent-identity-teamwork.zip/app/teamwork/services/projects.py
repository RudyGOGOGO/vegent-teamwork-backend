from sqlalchemy import func, select

from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import Category, Project, ProjectMember, ProjectProgressEvent
from app.teamwork.permissions import Action, require_project, require_team
from app.teamwork.services.common import (
    confirmation,
    deletion,
    event,
    label,
    name,
    nonempty_patch,
    touch,
    version,
)


def category_id_valid(team_id, category_id, *, db):
    if category_id is not None and not db.scalar(
        select(Category.id).where(
            Category.id == category_id,
            Category.team_id == team_id,
            Category.deleted_at.is_(None),
        )
    ):
        fail("INVALID_CATEGORY", 422)


def _create_node(actor, team, body, *, db, parent=None, published=True):
    now = utcnow()
    user = team.user
    category_id_valid(team.team.id, body.get("category_id"), db=db)
    row = Project(
        team_id=team.team.id,
        parent_project_id=parent.id if parent else None,
        node_depth=1 if parent else 0,
        parent_depth_guard=0,
        category_id=None if parent else body.get("category_id"),
        name=name(body["name"]),
        background=body["background"],
        goals=body["goals"],
        created_by_user_id=user.id,
        created_by_name=label(user),
        creator_user_id=None if parent else user.id,
        creator_name_snapshot=None if parent else label(user),
        ownership_state=None if parent else "assigned",
        status="active",
        progress_status=body.get("progress_status", "not_started"),
        progress_note=body.get("progress_note", ""),
        progress_note_author_id=user.id,
        progress_note_author_name=label(user),
        progress_note_updated_at=now,
        version=1,
        context_revision=1,
        published_at=now if published else None,
        lifecycle_updated_at=now,
        membership_updated_at=now,
        ownership_updated_at=now,
        created_at=now,
        updated_at=now,
        last_activity_at=now,
        source_created_at=body.get("source_created_at"),
    )
    db.add(row)
    db.flush()
    if not parent:
        db.add(
            ProjectMember(
                project_id=row.id,
                team_id=row.team_id,
                root_depth_guard=0,
                user_id=user.id,
                team_membership_id=team.membership.id,
                status="active",
                added_by_user_id=user.id,
                added_by_name_snapshot=label(user),
                joined_at=now,
            )
        )
    if published:
        event(actor, row, "subproject_created" if parent else "project_created", db=db)
    return row


def detail(actor, team_id, node_id, *, db):
    from app.teamwork.schemas.common import PageQuery

    from .dashboard import project_detail

    db.flush()
    return project_detail(actor, team_id, node_id, PageQuery(), db=db)


def create_project(actor, team_id, body, operation, *, db):
    grant = require_team(actor, team_id, db=db)
    row = _create_node(actor, grant, body.model_dump(), db=db)
    return detail(actor, team_id, row.id, db=db)


def create_subproject(
    actor, team_id, parent_id, body, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, parent_id, Action.CREATE_SUBPROJECT, db=db)
    version(grant.node, expected_version)
    from app.teamwork.permissions import TeamGrant

    row = _create_node(
        actor,
        TeamGrant(grant.team, grant.membership, grant.user),
        body.model_dump(),
        db=db,
        parent=grant.root,
    )
    touch(grant.root)
    event(
        actor,
        grant.root,
        "subproject_added",
        db=db,
        object_type="project",
        object_id=row.id,
    )
    return detail(actor, team_id, row.id, db=db)


def update_project(actor, team_id, node_id, body, expected_version, operation, *, db):
    grant = require_project(actor, team_id, node_id, Action.EDIT_INFO, db=db)
    version(grant.node, expected_version, detail(actor, team_id, node_id, db=db))
    fields = nonempty_patch(body)
    if any(k in fields for k in ("name", "category_id")) and not grant.creator:
        fail("FORBIDDEN", 403)
    if grant.node.node_depth and "category_id" in fields:
        fail("INHERITED_CATEGORY", 422)
    if "name" in fields:
        fields["name"] = name(fields["name"])
    if "category_id" in fields:
        category_id_valid(team_id, fields["category_id"], db=db)
    if any(v is None for k, v in fields.items() if k != "category_id"):
        fail("VALIDATION_ERROR", 422)
    if any(getattr(grant.node, k) != v for k, v in fields.items()):
        for k, v in fields.items():
            setattr(grant.node, k, v)
        touch(grant.node)
        event(actor, grant.node, "project_updated", db=db)
    return detail(actor, team_id, node_id, db=db)


def change_lifecycle(
    actor, team_id, node_id, action, body, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, node_id, Action(action), db=db)
    row = grant.node
    version(row, expected_version, detail(actor, team_id, node_id, db=db))
    if action == "delete":
        confirmation(body)
        deletion(row, actor, body)
        touch(row)
        children = db.scalar(
            select(func.count())
            .select_from(Project)
            .where(
                Project.parent_project_id == row.id,
                Project.status != "deleted",
                Project.published_at.is_not(None),
            )
        )
        event(
            actor,
            row,
            "project_deleted",
            db=db,
            detail={
                "affected_subprojects": children,
                "reason_ref": {"project_id": row.id, "field": "delete_reason"}
                if body.reason
                else None,
            },
        )
        return None
    target = "archived" if action == "archive" else "active"
    if row.status == target:
        return detail(actor, team_id, node_id, db=db)
    now = utcnow()
    row.status = target
    row.lifecycle_updated_at = now
    touch(row, now=now)
    db.add(
        ProjectProgressEvent(
            project_id=row.id,
            project_version=row.version,
            event_type="archived" if action == "archive" else "unarchived",
            actor_user_id=actor.user_id,
            actor_name_snapshot=label(grant.user),
            old_status=row.progress_status,
            new_status=row.progress_status,
            old_note=row.progress_note,
            new_note=row.progress_note,
            created_at=now,
        )
    )
    event(
        actor,
        row,
        "project_" + ("archived" if action == "archive" else "unarchived"),
        db=db,
    )
    return detail(actor, team_id, node_id, db=db)
