from uuid import uuid4

from sqlalchemy import select

from app.models.user import User
from app.services.team_members import utcnow, write_audit
from app.teamwork.errors import fail
from app.teamwork.models import ProjectActivityEvent


def label(user):
    return user.display_name or user.user_name


def iso(value):
    return value.isoformat(timespec="microseconds") + "Z" if value is not None else None


def name(value):
    if not isinstance(value, str) or not value.strip():
        fail("VALIDATION_ERROR", 422)
    value = value.strip()
    if len(value) > 255:
        fail("FIELD_STORAGE_LIMIT", 422)
    return value


def nonempty_patch(body):
    fields = body.model_dump(exclude_unset=True)
    if not fields:
        fail("VALIDATION_ERROR", 422)
    return fields


def version(row, expected, current=None):
    if row.version != expected:
        fail("VERSION_CONFLICT", 409, current=current or {"version": row.version})


def audit(actor, team_id, action, *, db, node=None, resource_id=None, detail=None):
    write_audit(
        db,
        actor_user_id=actor.user_id,
        action=action,
        team_id=team_id,
        resource_type="project" if node else "teamwork",
        resource_id=node.id if node else resource_id,
        detail=detail or {},
    )


def touch(node, *, now=None):
    now = now or utcnow()
    node.version += 1
    node.context_revision += 1
    node.updated_at = node.last_activity_at = now


def event(
    actor,
    node,
    kind,
    *,
    db,
    object_type="project",
    object_id=None,
    object_version=None,
    detail=None,
    now=None,
):
    now = now or utcnow()
    row = ProjectActivityEvent(
        project_id=node.id,
        event_type=kind,
        actor_user_id=actor.user_id,
        actor_name_snapshot=label(db.get(User, actor.user_id)),
        object_type=object_type,
        object_id=object_id if object_id is not None else node.id,
        object_version=object_version if object_version is not None else node.version,
        safe_detail=detail or {},
        created_at=now,
    )
    db.add(row)
    audit(actor, node.team_id, kind, db=db, node=node, detail=detail)
    return row


def scoped(cls, node_id, entity_id, *, db, deleted_field=None):
    row = db.scalar(
        select(cls)
        .where(cls.id == entity_id, cls.project_id == node_id)
        .with_for_update(read=not db.info.get("teamwork_write", False))
    )
    if (
        row is None
        or deleted_field
        and getattr(row, deleted_field) in ("deleted", True)
    ):
        fail("NOT_FOUND", 404)
    return row


def confirmation(body):
    if getattr(body, "confirm", None) is not True:
        fail("CONFIRMATION_REQUIRED", 422)


def deletion(node, actor, body):
    now = utcnow()
    node.deleted_from_status = node.status
    node.status = "deleted"
    node.deleted_at = now
    node.deleted_by_user_id = actor.user_id
    node.deletion_batch_id = str(uuid4())
    node.delete_reason = body.reason
    node.lifecycle_updated_at = now
