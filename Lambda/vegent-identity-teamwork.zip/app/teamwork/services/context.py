import re

from sqlalchemy import and_, func, select

from app.services.team_members import utcnow
from app.teamwork.cursors import decode_cursor, encode_cursor
from app.teamwork.errors import fail
from app.teamwork.models import (
    Project,
    ProjectContextItem,
    ProjectImportReceipt,
    ProjectPR,
    ProjectProgressEvent,
    ProjectResource,
    ProjectResourceVersion,
    ProjectTask,
)
from app.teamwork.operations import valid_uuid
from app.teamwork.paging import page
from app.teamwork.permissions import Action, require_project
from app.teamwork.projection import (
    member_views,
    project_projection,
    summary,
    text_value,
)
from app.teamwork.services.common import audit, iso

SECTIONS = (
    "tasks",
    "subprojects",
    "members",
    "prs",
    "resources",
    "decisions",
    "open_questions",
    "comments",
    "progress_history",
    "activity",
)


def _hash(value):
    if value and value.startswith('"') and value.endswith('"'):
        value = value[1:-1]
    if value is None or re.fullmatch("[0-9a-f]{64}", value) is None:
        fail("INVALID_VERSION", 422)
    return value


def _section(actor, grant, section, query, expected_hash, *, db):
    nid = grant.node.id
    tid = grant.team.id
    if section == "tasks":
        from .tasks import list_tasks

        return list_tasks(
            actor, tid, nid, {"limit": query.limit, "cursor": query.cursor}, db=db
        )
    if section == "subprojects":
        if grant.node.node_depth:
            rows = []
        else:
            from dataclasses import replace

            rows = [
                summary(actor, replace(grant, node=r), db=db, shared=True)
                for r in db.scalars(
                    select(Project)
                    .where(
                        Project.parent_project_id == nid,
                        Project.published_at.is_not(None),
                        Project.status != "deleted",
                    )
                    .order_by(
                        Project.last_activity_at.desc(),
                        Project.created_at.desc(),
                        Project.id.desc(),
                    )
                )
            ]
        return page(
            rows,
            scope={"kind": "context_children", "node": nid, "hash": expected_hash},
            limit=query.limit,
            cursor=query.cursor,
            projection_version=expected_hash,
        )
    if section == "members":
        return page(
            member_views(grant, db=db),
            scope={"kind": "context_members", "node": nid, "hash": expected_hash},
            limit=query.limit,
            cursor=query.cursor,
            projection_version=expected_hash,
        )
    q = {"limit": query.limit, "cursor": query.cursor}
    if section == "comments":
        from .comments import list_comments

        return list_comments(actor, tid, nid, q, db=db)
    if section in ("decisions", "open_questions"):
        from .context_items import list_items

        return list_items(
            actor,
            tid,
            nid,
            {**q, "kind": "decision" if section == "decisions" else "open_question"},
            db=db,
        )
    if section == "resources":
        from .resources import list_resources

        return list_resources(actor, tid, nid, q, db=db)
    if section == "prs":
        from .prs import list_prs

        return list_prs(actor, tid, nid, q, db=db, shared=True)
    if section == "progress_history":
        from .progress import list_progress_events

        return list_progress_events(actor, tid, nid, query, db=db)
    from .dashboard import list_activity

    return list_activity(actor, tid, nid, {}, query, db=db, shared=True)


def get_context(actor, team_id, node_id, section, cursor, expected_hash, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    hash_value = projection.context_version
    if section is not None and section not in SECTIONS:
        fail("VALIDATION_ERROR", 422)
    if section or cursor:
        if _hash(expected_hash) != hash_value:
            fail("CONTEXT_CHANGED", 409)
    elif expected_hash is not None and _hash(expected_hash) != hash_value:
        fail("CONTEXT_CHANGED", 409)
    if cursor and section is None:
        fail("INVALID_CURSOR", 422)
    from app.teamwork.schemas.common import PageQuery

    if section:
        scope = {
            "kind": "context_section",
            "node": node_id,
            "section": section,
            "hash": hash_value,
        }
        inner = decode_cursor(cursor, scope)["inner"] if cursor else None
        result = _section(
            actor,
            grant,
            section,
            PageQuery(limit=query.limit, cursor=inner),
            hash_value,
            db=db,
        )
        if result["next_cursor"]:
            result["next_cursor"] = encode_cursor(
                {"scope": scope, "inner": result["next_cursor"]}
            )
        return {
            "schema_version": "2.1-r3",
            "project_id": node_id,
            "context_version": hash_value,
            "section": section,
            "items": result["items"],
            "next_cursor": result["next_cursor"],
            "has_more": result["has_more"],
        }
    data = summary(actor, grant, db=db, shared=True)
    data["background"] = text_value(
        "project", grant.node, "background", node_id, hash_value, db=db
    )
    data["goals"] = text_value(
        "project", grant.node, "goals", node_id, hash_value, db=db
    )
    sections = {}
    for name in SECTIONS:
        # Smaller first pages pack all ten collections into one response frame.
        result = _section(
            actor, grant, name, PageQuery(limit=min(query.limit, 3)), hash_value, db=db
        )
        next_cursor = (
            encode_cursor(
                {
                    "scope": {
                        "kind": "context_section",
                        "node": node_id,
                        "section": name,
                        "hash": hash_value,
                    },
                    "inner": result["next_cursor"],
                }
            )
            if result["next_cursor"]
            else None
        )
        sections[name] = {
            "items": result["items"],
            "next_cursor": next_cursor,
            "has_more": result["has_more"],
            "href": f"/api/teams/{team_id}/projects/{node_id}/context?section={name}",
        }
    return {
        "schema_version": "2.1-r3",
        "project": data,
        "context_version": hash_value,
        "observed_at": iso(utcnow()),
        "sections": sections,
        "import_mode": "read_only_context",
    }


def read_text_fragment(
    actor, team_id, node_id, ref, offset, limit, expected_hash, *, db
):
    grant = require_project(actor, team_id, node_id, db=db)
    hash_value = project_projection(grant, db=db).context_version
    if _hash(expected_hash) != hash_value:
        fail("CONTEXT_CHANGED", 409)
    kinds = {
        "project": (Project, {"background", "goals", "progress_note"}),
        "task": (ProjectTask, {"description"}),
        "pr": (ProjectPR, {"title", "branch"}),
        "resource": (ProjectResourceVersion, {"name"}),
        "context_item": (ProjectContextItem, {"context", "body", "answer"}),
        "progress_event": (ProjectProgressEvent, {"old_note", "new_note"}),
    }
    kind = ref.get("kind")
    field = ref.get("field")
    object_id = ref.get("object_id")
    resource_version = ref.get("resource_version")
    if (
        kind not in kinds
        or field not in kinds[kind][1]
        or offset < 0
        or limit <= 0
        or kind != "resource"
        and resource_version is not None
    ):
        fail("INVALID_TEXT_SELECTOR", 422)
    cls = kinds[kind][0]
    column = getattr(cls, "context_text" if field == "context" else field)
    condition = cls.id == object_id
    if kind == "resource":
        if resource_version is None:
            fail("INVALID_TEXT_SELECTOR", 422)
        logical = db.get(ProjectResource, object_id)
        if (
            logical is None
            or logical.project_id != node_id
            or logical.status == "deleted"
        ):
            fail("NOT_FOUND", 404)
        condition = and_(
            cls.resource_id == object_id, cls.resource_version == resource_version
        )
    elif kind == "project":
        condition = and_(condition, cls.id == node_id)
    else:
        condition = and_(condition, cls.project_id == node_id)
        if kind == "task":
            condition = and_(condition, cls.lifecycle_status != "deleted")
        if kind == "context_item":
            condition = and_(condition, cls.deleted_at.is_(None))
    size = min(limit, 131072)
    result = db.execute(
        select(
            func.char_length(column), func.substring(column, offset + 1, size)
        ).where(condition)
    ).first()
    if result is None or result[0] is None:
        fail("NOT_FOUND", 404)
    length, value = result
    if offset > length:
        fail("INVALID_OFFSET", 422)
    end = offset + len(value)
    return {
        "project_id": node_id,
        "context_version": hash_value,
        "kind": kind,
        "object_id": object_id,
        "field": field,
        "resource_version": resource_version,
        "offset": offset,
        "text": value,
        "next_offset": end if end < length else None,
        "complete": end >= length,
    }


def record_import(actor, team_id, node_id, body, operation, *, db):
    grant = require_project(actor, team_id, node_id, Action.IMPORT, db=db)
    valid_uuid(body.local_import_id)
    row = db.scalar(
        select(ProjectImportReceipt).where(
            ProjectImportReceipt.imported_by_user_id == actor.user_id,
            ProjectImportReceipt.local_import_id == body.local_import_id,
        )
    )
    if row:
        if row.project_id != node_id or row.context_version != body.context_version:
            fail("IDEMPOTENCY_CONFLICT", 409)
    else:
        if body.context_version != project_projection(grant, db=db).context_version:
            fail("CONTEXT_CHANGED", 409)
        row = ProjectImportReceipt(
            project_id=node_id,
            imported_by_user_id=actor.user_id,
            local_import_id=body.local_import_id,
            context_version=body.context_version,
            imported_at=utcnow(),
        )
        db.add(row)
        db.flush()
        audit(actor, team_id, "project_imported", db=db, node=grant.node)
    return {
        "receipt_id": row.id,
        "project_id": node_id,
        "local_import_id": row.local_import_id,
        "context_version": row.context_version,
        "imported_at": iso(row.imported_at),
    }
