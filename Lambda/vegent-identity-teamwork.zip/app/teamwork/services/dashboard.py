from sqlalchemy import and_, case, func, literal, or_, select
from sqlalchemy.orm import aliased

from app.models.team_member import TeamMember
from app.models.user import User
from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import (
    Category,
    CommentMention,
    Project,
    ProjectActivityEvent,
    ProjectComment,
    ProjectContextItem,
    ProjectMember,
    ProjectPR,
    ProjectPRReviewer,
    ProjectTask,
)
from app.teamwork.paging import sql_page
from app.teamwork.permissions import require_project, require_team
from app.teamwork.projection import (
    PROGRESS_STATES,
    TASK_STATES,
    activity_view,
    prefetch_projection_inputs,
    project_projection,
    summary,
    text_value,
)
from app.teamwork.services.common import iso


def visible_nodes(actor, team_id, *, db):
    require_team(actor, team_id, db=db)
    root = aliased(Project)
    return (
        select(Project)
        .outerjoin(root, Project.parent_project_id == root.id)
        .join(
            ProjectMember,
            ProjectMember.project_id == func.coalesce(root.id, Project.id),
        )
        .join(
            TeamMember,
            and_(
                TeamMember.id == ProjectMember.team_membership_id,
                TeamMember.team_id == ProjectMember.team_id,
                TeamMember.user_id == ProjectMember.user_id,
            ),
        )
        .where(
            Project.team_id == team_id,
            Project.status != "deleted",
            Project.published_at.is_not(None),
            or_(
                Project.parent_project_id.is_(None),
                and_(root.status != "deleted", root.published_at.is_not(None)),
            ),
            ProjectMember.user_id == actor.user_id,
            ProjectMember.status == "active",
            TeamMember.status == "active",
            TeamMember.team_id == team_id,
        )
    )


def _filter(actor, team_id, filters, *, db):
    f = filters.model_dump() if hasattr(filters, "model_dump") else dict(filters)
    defaults = {
        "category_id": None,
        "status": "active",
        "progress_status": None,
        "blocked": None,
        "needs_pr_review": None,
        "mentioned_me": None,
        "created_by_me": None,
        "q": None,
        "view": "category",
    }
    f = {**defaults, **f}
    f["q"] = (f["q"] or "").strip() or None
    if (
        f["status"] not in ("active", "archived", "all")
        or f["view"] not in ("category", "time")
        or f["progress_status"] is not None
        and f["progress_status"] not in PROGRESS_STATES
    ):
        fail("INVALID_FILTER", 422)
    if f["category_id"] not in (None, "none"):
        try:
            cid = int(f["category_id"])
        except (TypeError, ValueError):
            fail("INVALID_FILTER", 422)
        from .categories import visible_categories

        if cid <= 0 or not db.scalar(
            visible_categories(actor, team_id, db=db)
            .with_only_columns(Category.id)
            .where(Category.id == cid)
        ):
            fail("INVALID_FILTER", 422)
        f["category_id"] = str(cid)
    return f


def filtered_nodes(actor, team_id, filters, *, db):
    """Filter visible node identities in SQL; never hydrate the unpaged roster."""
    f = _filter(actor, team_id, filters, db=db)
    parent = aliased(Project)
    root_id = func.coalesce(Project.parent_project_id, Project.id)
    owner_id = func.coalesce(parent.creator_user_id, Project.creator_user_id)
    category_id = func.coalesce(parent.category_id, Project.category_id)
    effective_status = case(
        (or_(Project.status == "archived", parent.status == "archived"), "archived"),
        else_="active",
    )
    q = visible_nodes(actor, team_id, db=db).with_only_columns(Project.id).subquery()
    query = (
        select(
            Project.id.label("id"),
            root_id.label("root_id"),
            Project.node_depth.label("depth"),
            owner_id.label("owner_id"),
            Category.id.label("category_id"),
            effective_status.label("status"),
            Project.progress_status.label("progress_status"),
        )
        .join(q, q.c.id == Project.id)
        .outerjoin(parent, parent.id == Project.parent_project_id)
        .outerjoin(
            Category, and_(Category.id == category_id, Category.deleted_at.is_(None))
        )
    )
    if f["status"] != "all":
        query = query.where(effective_status == f["status"])
    if f["progress_status"] is not None:
        query = query.where(Project.progress_status == f["progress_status"])
    if f["category_id"] == "none":
        query = query.where(Category.id.is_(None))
    elif f["category_id"] is not None:
        query = query.where(Category.id == int(f["category_id"]))
    blocked = (
        select(ProjectTask.id)
        .where(
            ProjectTask.project_id == Project.id,
            ProjectTask.lifecycle_status != "deleted",
            ProjectTask.status == "blocked",
        )
        .correlate(Project)
        .exists()
    )
    reviewing = (
        select(ProjectPR.id)
        .join(ProjectPRReviewer, ProjectPRReviewer.pr_id == ProjectPR.id)
        .where(
            ProjectPR.project_id == Project.id,
            ProjectPR.status == "open",
            ProjectPRReviewer.user_id == actor.user_id,
            ProjectPRReviewer.is_current.is_(True),
        )
        .correlate(Project)
        .exists()
    )
    mentioned = (
        select(ProjectComment.id)
        .join(CommentMention, CommentMention.comment_id == ProjectComment.id)
        .where(
            ProjectComment.project_id == Project.id,
            ProjectComment.status != "deleted",
            CommentMention.status == "active",
            CommentMention.mentioned_user_id == actor.user_id,
        )
        .correlate(Project)
        .exists()
    )
    for name, expression in (
        ("blocked", blocked),
        ("needs_pr_review", reviewing),
        ("mentioned_me", mentioned),
        ("created_by_me", owner_id == actor.user_id),
    ):
        if f[name] is not None:
            query = query.where(expression if f[name] else ~expression)
    if f["q"]:
        needle = (
            "%" + f["q"].replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%"
        )
        member = (
            select(ProjectMember.id)
            .join(
                TeamMember,
                and_(
                    TeamMember.id == ProjectMember.team_membership_id,
                    TeamMember.user_id == ProjectMember.user_id,
                    TeamMember.team_id == ProjectMember.team_id,
                ),
            )
            .join(User, User.id == ProjectMember.user_id)
            .where(
                ProjectMember.project_id == root_id,
                ProjectMember.status == "active",
                TeamMember.status == "active",
                User.is_active.is_(True),
                or_(
                    User.display_name.like(needle, escape="!"),
                    User.email.like(needle, escape="!"),
                    User.user_name.like(needle, escape="!"),
                ),
            )
            .correlate(Project, parent)
            .exists()
        )
        task = (
            select(ProjectTask.id)
            .where(
                ProjectTask.project_id == Project.id,
                ProjectTask.lifecycle_status != "deleted",
                ProjectTask.title.like(needle, escape="!"),
            )
            .correlate(Project)
            .exists()
        )
        query = query.where(or_(Project.name.like(needle, escape="!"), member, task))
    return f, query


def _project_page(actor, team_id, f, matching, query, *, db):
    matches = matching.subquery()
    grouped = (
        select(
            matches.c.root_id.label("root_id"),
            func.max(case((matches.c.depth == 0, 1), else_=0)).label("self_matches"),
            func.sum(case((matches.c.depth == 1, 1), else_=0)).label("child_matches"),
        )
        .group_by(matches.c.root_id)
        .subquery()
    )
    keys = (
        [(Project.created_at, True), (Project.id, True)]
        if f["view"] == "time"
        else [
            (case((Category.id.is_(None), 1), else_=0).label("sort_none"), False),
            (
                func.coalesce(Category.created_at, Project.created_at).label(
                    "sort_category_time"
                ),
                False,
            ),
            (func.coalesce(Category.id, 0).label("sort_category_id"), False),
            (Project.last_activity_at, True),
            (Project.created_at, True),
            (Project.id, True),
        ]
    )
    statement = (
        select(
            Project,
            grouped.c.self_matches,
            grouped.c.child_matches,
            *[c for c, d in keys],
        )
        .join(grouped, grouped.c.root_id == Project.id)
        .outerjoin(
            Category,
            and_(Category.id == Project.category_id, Category.deleted_at.is_(None)),
        )
    )
    # No Category is one shared group, regardless of each Project creation time.
    if f["view"] != "time":
        from datetime import datetime

        keys[1] = (
            func.coalesce(Category.created_at, datetime(1000, 1, 1)).label(
                "sort_category_time"
            ),
            False,
        )
        statement = (
            select(
                Project,
                grouped.c.self_matches,
                grouped.c.child_matches,
                *[c for c, d in keys],
            )
            .join(grouped, grouped.c.root_id == Project.id)
            .outerjoin(
                Category,
                and_(Category.id == Project.category_id, Category.deleted_at.is_(None)),
            )
        )

    def project(row):
        node = row[0]
        grant = require_project(actor, team_id, node.id, db=db)
        data = summary(actor, grant, db=db)
        return {
            "category": data["category"],
            "project": data,
            "self_matches": bool(row[1]),
            "matching_subproject_count": int(row[2]),
            "subprojects_href": f"/api/teams/{team_id}/projects/{node.id}/subprojects",
        }

    return sql_page(
        statement,
        Project,
        project,
        db=db,
        scope={
            "kind": "projects",
            "actor": actor.user_id,
            "team": team_id,
            "filters": f,
        },
        order=keys,
        row_mode=True,
        key_values=lambda row: list(row[3:]),
        prepare_rows=lambda rows: prefetch_projection_inputs(
            [row[0].id for row in rows], db=db
        ),
        limit=query.limit,
        cursor=query.cursor,
    )


def list_projects(actor, team_id, filters, query, *, db):
    require_team(actor, team_id, db=db)
    f, matches = filtered_nodes(actor, team_id, filters, db=db)
    return {
        "team_id": team_id,
        "filters": f,
        "observed_at": iso(utcnow()),
        "projects": _project_page(actor, team_id, f, matches, query, db=db),
    }


def project_detail(actor, team_id, node_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    data = summary(actor, grant, db=db, projection=projection)
    data["background"] = text_value(
        "project", grant.node, "background", node_id, projection.context_version, db=db
    )
    data["goals"] = text_value(
        "project", grant.node, "goals", node_id, projection.context_version, db=db
    )
    data["sections"] = {
        section: f"/api/teams/{team_id}/projects/{node_id}/{path}"
        for section, path in [
            ("tasks", "tasks"),
            ("prs", "prs"),
            ("resources", "resources"),
            ("comments", "comments"),
            ("members", "members"),
            ("progress_history", "progress-events"),
            ("decisions", "context-items?kind=decision"),
            ("open_questions", "context-items?kind=open_question"),
            ("context", "context"),
        ]
    }
    data["sections"]["members"] = (
        f"/api/teams/{team_id}/projects/{grant.root.id}/members"
    )
    data["subproject_page"] = (
        list_subprojects(actor, team_id, node_id, {"status": "all"}, query, db=db)
        if not grant.node.node_depth
        else None
    )
    return data


def list_subprojects(actor, team_id, node_id, filters, query, *, db):
    parent = require_project(actor, team_id, node_id, db=db)
    if parent.node.node_depth:
        fail("NOT_PARENT_PROJECT", 422)
    f, matches = filtered_nodes(actor, team_id, filters, db=db)

    def last_activity():
        return func.greatest(
            Project.last_activity_at,
            parent.root.lifecycle_updated_at,
            parent.root.membership_updated_at,
            parent.root.ownership_updated_at,
        )

    key = last_activity().label("effective_activity")
    stmt = select(Project, key).where(
        Project.parent_project_id == node_id,
        Project.id.in_(matches.with_only_columns(Project.id)),
    )
    return sql_page(
        stmt,
        Project,
        lambda row: summary(
            actor, require_project(actor, team_id, row[0].id, db=db), db=db
        ),
        db=db,
        scope={
            "kind": "subprojects",
            "root": node_id,
            "actor": actor.user_id,
            "filters": f,
        },
        order=[(key, True), (Project.created_at, True), (Project.id, True)],
        row_mode=True,
        key_values=lambda row: [row[1], row[0].created_at, row[0].id],
        prepare_rows=lambda rows: prefetch_projection_inputs(
            [row[0].id for row in rows], db=db
        ),
        limit=query.limit,
        cursor=query.cursor,
    )


INHERITED_EVENTS = (
    "project_archived",
    "project_unarchived",
    "project_member_added",
    "project_member_removed",
    "project_owner_changed",
    "project_ownership_lost",
)


def list_activity(actor, team_id, node_id, filters, query, *, db, shared=False):
    if node_id is not None:
        grant = require_project(actor, team_id, node_id, db=db)
        matched = select(
            literal(node_id).label("id"),
            literal(grant.root.id).label("root_id"),
            literal(grant.node.node_depth).label("depth"),
        ).subquery()
        f = {}
    else:
        f, nodes = filtered_nodes(actor, team_id, filters, db=db)
        matched = nodes.subquery()
    direct = ProjectActivityEvent.project_id.in_(select(matched.c.id))
    inherited_display = (
        select(func.max(matched.c.id))
        .where(
            matched.c.root_id == ProjectActivityEvent.project_id, matched.c.depth == 1
        )
        .correlate(ProjectActivityEvent)
        .scalar_subquery()
    )
    display_id = case(
        (direct, ProjectActivityEvent.project_id), else_=inherited_display
    ).label("display_id")
    statement = select(ProjectActivityEvent, display_id).where(
        or_(
            direct,
            and_(
                ProjectActivityEvent.event_type.in_(INHERITED_EVENTS),
                inherited_display.is_not(None),
            ),
        )
    )

    def project(row):
        grant = require_project(actor, team_id, row[1], db=db)
        return activity_view(
            row[0], grant.node, project_projection(grant, db=db), db=db
        )

    return sql_page(
        statement,
        ProjectActivityEvent,
        project,
        db=db,
        scope={
            "kind": "activity",
            "team": team_id,
            "node": node_id,
            "filters": f,
            "actor": None if shared else actor.user_id,
        },
        order=[
            (ProjectActivityEvent.created_at, True),
            (ProjectActivityEvent.id, True),
        ],
        row_mode=True,
        key_values=lambda row: [row[0].created_at, row[0].id],
        prepare_rows=lambda rows: prefetch_projection_inputs(
            list({row[1] for row in rows}), db=db
        ),
        limit=query.limit,
        cursor=query.cursor,
    )


def team_dashboard(actor, team_id, filters, query, *, db):
    require_team(actor, team_id, db=db)
    f, statement = filtered_nodes(actor, team_id, filters, db=db)
    nodes = statement.subquery()
    ids = select(nodes.c.id)
    total, roots, own = db.execute(
        select(
            func.count(),
            func.coalesce(func.sum(case((nodes.c.depth == 0, 1), else_=0)), 0),
            func.coalesce(
                func.sum(case((nodes.c.owner_id == actor.user_id, 1), else_=0)), 0
            ),
        ).select_from(nodes)
    ).one()
    aggregates = {
        "total_visible_projects": total,
        "root_projects": int(roots),
        "subprojects": total - int(roots),
        "created_by_me": int(own),
        "by_category": [],
        "by_progress_status": dict.fromkeys(PROGRESS_STATES, 0),
        "by_lifecycle": {"active": 0, "archived": 0},
        "tasks": {"total": 0, **dict.fromkeys(TASK_STATES, 0)},
        "prs": {
            "open": 0,
            "merged": 0,
            "closed": 0,
            "open_reviewing_me": 0,
            "reviewer_mapping_complete": True,
        },
        "comments": {"total": 0, "mentioning_me": 0},
        "open_questions": 0,
    }
    for field, destination in (
        (nodes.c.progress_status, "by_progress_status"),
        (nodes.c.status, "by_lifecycle"),
    ):
        for state, count in db.execute(
            select(field, func.count()).select_from(nodes).group_by(field)
        ):
            aggregates[destination][state] = count
    for cid, count, root_count in db.execute(
        select(
            nodes.c.category_id,
            func.count(),
            func.sum(case((nodes.c.depth == 0, 1), else_=0)),
        )
        .select_from(nodes)
        .group_by(nodes.c.category_id)
    ):
        category = db.get(Category, cid) if cid else None
        ref = (
            {
                "id": category.id,
                "name": category.name,
                "created_at": iso(category.created_at),
                "version": category.version,
            }
            if category
            else None
        )
        aggregates["by_category"].append(
            {
                "category": ref,
                "total": count,
                "roots": int(root_count),
                "subprojects": count - int(root_count),
            }
        )
    aggregates["by_category"].sort(
        key=lambda x: (
            x["category"] is None,
            (x["category"] or {}).get("created_at", ""),
            (x["category"] or {}).get("id", 0),
        )
    )
    for state, count in db.execute(
        select(ProjectTask.status, func.count())
        .where(
            ProjectTask.project_id.in_(ids), ProjectTask.lifecycle_status != "deleted"
        )
        .group_by(ProjectTask.status)
    ):
        aggregates["tasks"][state] = count
        aggregates["tasks"]["total"] += count
    for state, count in db.execute(
        select(ProjectPR.status, func.count())
        .where(ProjectPR.project_id.in_(ids))
        .group_by(ProjectPR.status)
    ):
        aggregates["prs"][state] = count
    aggregates["prs"]["reviewer_mapping_complete"] = not bool(
        db.scalar(
            select(ProjectPR.id)
            .where(
                ProjectPR.project_id.in_(ids),
                ProjectPR.status == "open",
                ProjectPR.reviewer_mapping_complete.is_(False),
            )
            .limit(1)
        )
    )
    aggregates["prs"]["open_reviewing_me"] = db.scalar(
        select(func.count(func.distinct(ProjectPR.id)))
        .join(ProjectPRReviewer, ProjectPRReviewer.pr_id == ProjectPR.id)
        .where(
            ProjectPR.project_id.in_(ids),
            ProjectPR.status == "open",
            ProjectPRReviewer.user_id == actor.user_id,
            ProjectPRReviewer.is_current.is_(True),
        )
    )
    aggregates["comments"]["total"] = db.scalar(
        select(func.count())
        .select_from(ProjectComment)
        .where(ProjectComment.project_id.in_(ids))
    )
    aggregates["comments"]["mentioning_me"] = db.scalar(
        select(func.count(func.distinct(ProjectComment.id)))
        .join(CommentMention, CommentMention.comment_id == ProjectComment.id)
        .where(
            ProjectComment.project_id.in_(ids),
            ProjectComment.status != "deleted",
            CommentMention.mentioned_user_id == actor.user_id,
            CommentMention.status == "active",
        )
    )
    aggregates["open_questions"] = db.scalar(
        select(func.count())
        .select_from(ProjectContextItem)
        .where(
            ProjectContextItem.project_id.in_(ids),
            ProjectContextItem.kind == "open_question",
            ProjectContextItem.state == "open",
            ProjectContextItem.deleted_at.is_(None),
        )
    )
    from app.teamwork.schemas.common import PageQuery

    return {
        "team_id": team_id,
        "scope": "team",
        "filters": f,
        "observed_at": iso(utcnow()),
        "aggregates": aggregates,
        "projects": _project_page(actor, team_id, f, statement, query, db=db),
        "recent_activity": list_activity(
            actor, team_id, None, filters, PageQuery(limit=query.limit), db=db
        ),
    }
