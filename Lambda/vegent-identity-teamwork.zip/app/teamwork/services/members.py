from sqlalchemy import select

from app.models.team_member import TeamMember
from app.models.user import User
from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import ProjectMember
from app.teamwork.paging import page
from app.teamwork.permissions import Action, require_eligible, require_project
from app.teamwork.projection import member_views
from app.teamwork.services.common import event, label, touch, version


def list_members(actor, team_id, root_id, query, *, db):
    grant = require_project(actor, team_id, root_id, db=db)
    if grant.node.node_depth:
        fail(
            "INHERITED_MEMBERSHIP",
            409,
            current={
                "members_href": f"/api/teams/{team_id}/projects/{grant.root.id}/members"
            },
        )
    rows = member_views(grant, db=db)
    search = getattr(query, "search", None)
    user_id = getattr(query, "user_id", None)
    if search:
        rows = [
            r
            for r in rows
            if search.casefold() in (r["name"] + " " + r["email"]).casefold()
        ]
    if user_id:
        rows = [r for r in rows if r["user_id"] == user_id]
    return page(
        rows,
        scope={
            "kind": "members",
            "node": root_id,
            "search": search,
            "user_id": user_id,
        },
        limit=getattr(query, "limit", 50),
        cursor=getattr(query, "cursor", None),
    )


def add_member(actor, team_id, root_id, user_id, expected_version, operation, *, db):
    grant = require_project(actor, team_id, root_id, Action.MANAGE_MEMBERS, db=db)
    version(grant.root, expected_version)
    user = db.get(User, user_id)
    tm = db.scalar(
        select(TeamMember).where(
            TeamMember.team_id == team_id,
            TeamMember.user_id == user_id,
            TeamMember.status == "active",
        )
    )
    if not user or not user.is_active or not tm:
        fail("INELIGIBLE_MEMBER", 422)
    if db.scalar(
        select(ProjectMember.id).where(
            ProjectMember.project_id == root_id,
            ProjectMember.user_id == user_id,
            ProjectMember.status == "active",
        )
    ):
        fail("DUPLICATE", 409)
    now = utcnow()
    row = ProjectMember(
        project_id=root_id,
        team_id=team_id,
        root_depth_guard=0,
        user_id=user_id,
        team_membership_id=tm.id,
        status="active",
        added_by_user_id=actor.user_id,
        added_by_name_snapshot=label(grant.user),
        joined_at=now,
    )
    db.add(row)
    touch(grant.root, now=now)
    grant.root.membership_updated_at = now
    db.flush()
    event(
        actor,
        grant.root,
        "project_member_added",
        db=db,
        object_type="member",
        object_id=row.id,
        detail={"target_user_id": user_id},
    )
    return next(
        {k: v for k, v in r.items() if k != "_cursor_key"}
        for r in member_views(grant, db=db)
        if r["user_id"] == user_id
    )


def remove_member(
    actor, team_id, root_id, member_id, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, root_id, Action.MANAGE_MEMBERS, db=db)
    version(grant.root, expected_version)
    row = db.scalar(
        select(ProjectMember)
        .where(ProjectMember.id == member_id, ProjectMember.project_id == root_id)
        .with_for_update()
    )
    if not row:
        fail("NOT_FOUND", 404)
    if row.user_id == grant.root.creator_user_id:
        fail("FORBIDDEN", 403)
    if row.status != "active":
        fail("STATE_CONFLICT", 409)
    now = utcnow()
    row.status = "removed"
    row.removed_at = now
    row.removed_by_user_id = actor.user_id
    row.removal_reason = "project_removal"
    touch(grant.root, now=now)
    grant.root.membership_updated_at = now
    event(
        actor,
        grant.root,
        "project_member_removed",
        db=db,
        object_type="member",
        object_id=row.id,
        detail={"target_user_id": row.user_id},
    )


def transfer_owner(
    actor, team_id, root_id, target_user_id, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, root_id, Action.TRANSFER_OWNERSHIP, db=db)
    version(grant.root, expected_version)
    require_eligible(grant, target_user_id, db=db)
    if grant.creator and grant.root.creator_user_id == target_user_id:
        from .projects import detail

        return detail(actor, team_id, root_id, db=db)
    old = grant.root.creator_user_id
    target = db.get(User, target_user_id)
    now = utcnow()
    grant.root.creator_user_id = target.id
    grant.root.creator_name_snapshot = label(target)
    grant.root.ownership_state = "assigned"
    grant.root.ownership_lost_at = None
    grant.root.ownership_updated_at = now
    touch(grant.root, now=now)
    event(
        actor,
        grant.root,
        "project_owner_changed",
        db=db,
        detail={"old_creator_user_id": old, "new_creator_user_id": target.id},
    )
    from .projects import detail

    return detail(actor, team_id, root_id, db=db)
