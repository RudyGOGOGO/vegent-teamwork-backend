from datetime import UTC, datetime, timedelta

from pydantic import Field, ValidationError
from sqlalchemy import and_, case, func, or_, select

from app.models.team_member import TeamMember
from app.models.user import User
from app.services.team_members import utcnow
from app.teamwork.config import expiry_seconds
from app.teamwork.cursors import decode_cursor, digest, encode_cursor
from app.teamwork.errors import fail
from app.teamwork.models import (
    Project,
    ProjectConversionItem,
    ProjectConversionSession,
    ProjectMember,
    ProjectTask,
    ResourceUpload,
)
from app.teamwork.operations import valid_uuid
from app.teamwork.permissions import (
    Action,
    eligible_members,
    require_project,
    require_team,
)
from app.teamwork.schemas.common import DTO, TaskState
from app.teamwork.schemas.conversion import ConversionNode
from app.teamwork.schemas.membership import MemberAdd
from app.teamwork.schemas.task import TaskCreate
from app.teamwork.services.common import audit, event, iso, label, name, touch, version


class TaskDraft(TaskCreate):
    status: TaskState = "todo"


class ResourceDescriptor(DTO):
    name: str
    media_type: str
    size_bytes: int = Field(strict=True, ge=0)
    sha256: str | None = Field(default=None, pattern="^[0-9a-f]{64}$")


def own_session(actor, team_id, session_id, *, db, write=False, allow_committed=False):
    team = require_team(actor, team_id, db=db)
    session = db.scalar(
        select(ProjectConversionSession)
        .where(
            ProjectConversionSession.id == session_id,
            ProjectConversionSession.team_id == team_id,
            ProjectConversionSession.created_by_user_id == actor.user_id,
        )
        .with_for_update(read=not write)
    )
    if session is None:
        fail("NOT_FOUND", 404)
    if session.expires_at is None and session.status not in (
        "committed",
        "cancelled",
        "expired",
    ):
        fail("STAGING_POLICY_REQUIRED", 503)
    if session.mode == "subproject":
        require_project(
            actor,
            team_id,
            session.existing_parent_id,
            Action.WRITE_WORK
            if write and session.status != "committed"
            else Action.READ,
            db=db,
        )
    if session.status == "committed":
        require_project(actor, team_id, session.committed_project_id, db=db)
        if write and not allow_committed:
            fail("CONVERSION_STATE_CONFLICT", 409)
    elif session.expires_at and session.expires_at <= utcnow():
        fail("CONVERSION_EXPIRED", 409)
    return session, team


def session_view(row, *, db):
    counts = {
        k: v
        for k, v in db.execute(
            select(ProjectConversionItem.kind, func.count())
            .where(ProjectConversionItem.conversion_id == row.id)
            .group_by(ProjectConversionItem.kind)
        )
    }
    verified = db.scalar(
        select(func.count(func.distinct(ResourceUpload.conversion_item_id))).where(
            ResourceUpload.conversion_id == row.id,
            ResourceUpload.status.in_(["verified", "published"]),
        )
    )
    prepared = db.scalar(
        select(func.count())
        .select_from(ProjectConversionItem)
        .where(
            ProjectConversionItem.conversion_id == row.id,
            ProjectConversionItem.prepared_object_id.is_not(None),
        )
    )
    pending = db.scalar(
        select(ProjectConversionItem.id)
        .where(
            ProjectConversionItem.conversion_id == row.id,
            ProjectConversionItem.prepared_object_id.is_(None),
        )
        .limit(1)
    )
    return {
        "id": row.id,
        "client_conversion_id": row.client_conversion_id,
        "team_id": row.team_id,
        "mode": row.mode,
        "existing_parent_id": row.existing_parent_id,
        "status": row.status,
        "version": row.version,
        "plan_digest": row.plan_digest,
        "counts": {
            "nodes": counts.get("node", 0),
            "tasks": counts.get("task", 0),
            "members": counts.get("member", 0),
            "resources": counts.get("resource", 0),
            "verified_resources": verified,
            "prepared_items": prepared,
        },
        "next_prepare_cursor": encode_cursor(
            {
                "scope": {
                    "kind": "prepare",
                    "session": row.id,
                    "digest": row.plan_digest,
                },
                "pending": True,
            }
        )
        if pending and row.plan_digest
        else None,
        "committed_project_id": row.committed_project_id
        if row.status == "committed"
        else None,
        "created_at": iso(row.created_at),
        "updated_at": iso(row.updated_at),
        "expires_at": iso(row.expires_at),
    }


def get_conversion(actor, team_id, session_id, *, db):
    row, team = own_session(actor, team_id, session_id, db=db)
    return session_view(row, db=db)


def start_conversion(actor, team_id, body, operation, *, db):
    require_team(actor, team_id, db=db)
    valid_uuid(body.client_conversion_id)
    if (
        body.mode == "root"
        and body.existing_parent_id is not None
        or body.mode == "subproject"
        and body.existing_parent_id is None
    ):
        fail("INVALID_HIERARCHY", 422)
    if body.mode == "subproject":
        parent = require_project(
            actor, team_id, body.existing_parent_id, Action.CREATE_SUBPROJECT, db=db
        )
        if parent.node.node_depth:
            fail("INVALID_HIERARCHY", 422)
    row = db.scalar(
        select(ProjectConversionSession)
        .where(
            ProjectConversionSession.created_by_user_id == actor.user_id,
            ProjectConversionSession.client_conversion_id == body.client_conversion_id,
        )
        .with_for_update()
    )
    if row:
        if (
            row.team_id != team_id
            or row.mode != body.mode
            or row.existing_parent_id != body.existing_parent_id
        ):
            fail("IDEMPOTENCY_CONFLICT", 409)
        own_session(actor, team_id, row.id, db=db)
        return session_view(row, db=db)
    now = utcnow()
    seconds = expiry_seconds("conversion")
    row = ProjectConversionSession(
        team_id=team_id,
        created_by_user_id=actor.user_id,
        client_conversion_id=body.client_conversion_id,
        mode=body.mode,
        existing_parent_id=body.existing_parent_id,
        status="planning",
        version=1,
        created_at=now,
        updated_at=now,
        expires_at=now + timedelta(seconds=seconds) if seconds else None,
    )
    db.add(row)
    db.flush()
    audit(actor, team_id, "conversion_started", db=db, resource_id=row.id)
    return session_view(row, db=db)


def _payload(session, item):
    try:
        if item.kind == "node":
            model = ConversionNode.model_validate(item.payload)
            if model.parent_node_key:
                valid_uuid(model.parent_node_key)
            if model.parent_node_key or session.mode == "subproject":
                if "category_id" in item.payload:
                    fail("INHERITED_CATEGORY", 422)
            elif "category_id" not in item.payload:
                fail("VALIDATION_ERROR", 422)
            if session.mode == "subproject" and model.parent_node_key:
                fail("INVALID_HIERARCHY", 422)
        elif item.kind == "task":
            model = TaskDraft.model_validate(item.payload)
        elif item.kind == "member":
            model = MemberAdd.model_validate(item.payload)
        else:
            model = ResourceDescriptor.model_validate(item.payload)
    except ValidationError:
        fail("VALIDATION_ERROR", 422)
    return model.model_dump(mode="json", exclude_none=True)


def append_item(actor, team_id, session_id, body, expected_version, operation, *, db):
    session, team = own_session(actor, team_id, session_id, db=db, write=True)
    version(session, expected_version)
    if session.status != "planning":
        fail("CONVERSION_STATE_CONFLICT", 409)
    valid_uuid(body.client_item_id)
    valid_uuid(body.node_key)
    payload = _payload(session, body)
    signature = digest({"kind": body.kind, "node": body.node_key, "payload": payload})
    existing = db.scalar(
        select(ProjectConversionItem).where(
            ProjectConversionItem.conversion_id == session.id,
            ProjectConversionItem.client_item_id == body.client_item_id,
        )
    )
    if existing:
        if existing.request_hash != signature:
            fail("IDEMPOTENCY_CONFLICT", 409)
        row = existing
    else:
        if body.kind == "node" and db.scalar(
            select(ProjectConversionItem.id).where(
                ProjectConversionItem.conversion_id == session.id,
                ProjectConversionItem.kind == "node",
                ProjectConversionItem.node_key == body.node_key,
            )
        ):
            fail("DUPLICATE", 409)
        row = ProjectConversionItem(
            conversion_id=session.id,
            client_item_id=body.client_item_id,
            node_key=body.node_key,
            kind=body.kind,
            payload=payload,
            request_hash=signature,
            created_at=utcnow(),
        )
        db.add(row)
        session.version += 1
        session.updated_at = utcnow()
        db.flush()
    return {
        "id": row.id,
        "client_item_id": row.client_item_id,
        "node_key": row.node_key,
        "kind": row.kind,
        "session_version": session.version,
    }


def _items(session, *, db):
    return list(
        db.scalars(
            select(ProjectConversionItem)
            .where(ProjectConversionItem.conversion_id == session.id)
            .order_by(ProjectConversionItem.id)
        )
    )


def _validate_graph(session, team, items, *, db, pin=False):
    nodes = {i.node_key: i for i in items if i.kind == "node"}
    roots = [i for i in nodes.values() if not i.payload.get("parent_node_key")]
    if len(roots) != 1 or session.mode == "subproject" and len(nodes) != 1:
        fail("INVALID_HIERARCHY", 422)
    root = roots[0]
    for item in nodes.values():
        parent = item.payload.get("parent_node_key")
        if parent and (
            session.mode != "root" or parent != root.node_key or parent == item.node_key
        ):
            fail("INVALID_HIERARCHY", 422)
    selected = {team.user.id}
    seen = set()
    inherited = None
    if session.mode == "subproject":
        grant = require_project(
            type(
                "ActorRef",
                (),
                {
                    "user_id": team.user.id,
                    "user_name": team.user.user_name,
                    "token_version": team.user.token_version,
                },
            )(),
            session.team_id,
            session.existing_parent_id,
            Action.WRITE_WORK,
            db=db,
        )
        inherited = {
            u.id for m, u, t in db.execute(eligible_members(grant.root.id, db=db))
        }
    for item in items:
        if item.node_key not in nodes:
            fail("INVALID_PLAN_REFERENCE", 422)
        if item.kind == "member":
            uid = item.payload["user_id"]
            if session.mode != "root" or item.node_key != root.node_key or uid in seen:
                fail("INVALID_PLAN_MEMBER", 422)
            seen.add(uid)
            selected.add(uid)
            epoch = db.scalar(
                select(TeamMember)
                .join(User, User.id == TeamMember.user_id)
                .where(
                    TeamMember.team_id == session.team_id,
                    TeamMember.user_id == uid,
                    TeamMember.status == "active",
                    User.is_active.is_(True),
                )
            )
            if epoch is None:
                fail("PLAN_MEMBERS_CHANGED", 409)
            if pin:
                item.validated_team_membership_id = epoch.id
            elif item.validated_team_membership_id != epoch.id:
                fail("PLAN_MEMBERS_CHANGED", 409)
    if pin:
        session.sealed_actor_team_membership_id = team.membership.id
    elif session.sealed_actor_team_membership_id != team.membership.id:
        fail("PLAN_MEMBERS_CHANGED", 409)
    from .projects import category_id_valid

    category_id_valid(session.team_id, root.payload.get("category_id"), db=db)
    for item in items:
        if (
            item.kind == "task"
            and item.payload.get("assignee_user_id") is not None
            and item.payload["assignee_user_id"]
            not in (inherited if inherited is not None else selected)
        ):
            fail("INVALID_PLAN_ASSIGNEE", 422)
    return root, nodes


def seal_plan(actor, team_id, session_id, expected_version, operation, *, db):
    session, team = own_session(actor, team_id, session_id, db=db, write=True)
    version(session, expected_version)
    if session.status != "planning":
        fail("CONVERSION_STATE_CONFLICT", 409)
    items = _items(session, db=db)
    root, nodes = _validate_graph(session, team, items, db=db, pin=True)
    session.plan_digest = digest(
        {
            "actor_epoch": session.sealed_actor_team_membership_id,
            "items": [
                (
                    i.client_item_id,
                    i.node_key,
                    i.kind,
                    i.payload,
                    i.validated_team_membership_id,
                )
                for i in items
            ],
        }
    )
    session.status = "sealed"
    session.version += 1
    session.updated_at = utcnow()
    audit(actor, team_id, "conversion_sealed", db=db, resource_id=session.id)
    return session_view(session, db=db)


def preparation_items(session_id, *, db):
    item = ProjectConversionItem
    rank = case(
        (
            and_(
                item.kind == "node",
                item.payload["parent_node_key"].as_string().is_(None),
            ),
            0,
        ),
        (item.kind == "node", 1),
        (item.kind == "member", 2),
        (item.kind == "task", 3),
        else_=4,
    )
    return (
        select(item)
        .where(item.conversion_id == session_id, item.prepared_object_id.is_(None))
        .order_by(rank, item.id)
        .limit(50)
    )


def _validate_preparation(session, team, batch, *, db):
    if session.sealed_actor_team_membership_id != team.membership.id:
        fail("PLAN_MEMBERS_CHANGED", 409)
    item = ProjectConversionItem
    invalid = (
        select(item.id)
        .outerjoin(
            TeamMember,
            and_(
                TeamMember.id == item.validated_team_membership_id,
                TeamMember.team_id == session.team_id,
                TeamMember.user_id == item.payload["user_id"].as_integer(),
            ),
        )
        .outerjoin(User, User.id == TeamMember.user_id)
        .where(
            item.conversion_id == session.id,
            item.kind == "member",
            or_(
                TeamMember.id.is_(None),
                TeamMember.status != "active",
                User.is_active.is_(False),
            ),
        )
        .limit(1)
    )
    if db.scalar(invalid) is not None:
        fail("PLAN_MEMBERS_CHANGED", 409)
    root = db.scalar(
        select(item).where(
            item.conversion_id == session.id,
            item.kind == "node",
            item.payload["parent_node_key"].as_string().is_(None),
        )
    )
    if root is None:
        fail("INVALID_HIERARCHY", 422)
    keys = {value.node_key for value in batch} | {root.node_key}
    nodes = {
        value.node_key: value
        for value in db.scalars(
            select(item).where(
                item.conversion_id == session.id,
                item.kind == "node",
                item.node_key.in_(keys),
            )
        )
    }
    from .projects import category_id_valid

    category_id_valid(session.team_id, root.payload.get("category_id"), db=db)
    inherited = None
    if session.mode == "subproject":
        grant = require_project(
            type(
                "ActorRef",
                (),
                {
                    "user_id": team.user.id,
                    "user_name": team.user.user_name,
                    "token_version": team.user.token_version,
                },
            )(),
            session.team_id,
            session.existing_parent_id,
            Action.WRITE_WORK,
            db=db,
        )
        inherited = eligible_members(grant.root.id, db=db)
    for value in batch:
        uid = value.payload.get("assignee_user_id") if value.kind == "task" else None
        if uid is not None:
            eligible = (
                db.execute(inherited.where(User.id == uid).limit(1)).first() is not None
                if inherited is not None
                else uid == team.user.id
                or db.scalar(
                    select(item.id)
                    .where(
                        item.conversion_id == session.id,
                        item.kind == "member",
                        item.payload["user_id"].as_integer() == uid,
                    )
                    .limit(1)
                )
                is not None
            )
            if not eligible:
                fail("INVALID_PLAN_ASSIGNEE", 422)
    return root, nodes


def prepare_batch(
    actor, team_id, session_id, cursor, expected_version, operation, *, db
):
    session, team = own_session(actor, team_id, session_id, db=db, write=True)
    version(session, expected_version)
    if session.status not in ("sealed", "preparing", "ready"):
        fail("CONVERSION_STATE_CONFLICT", 409)
    if cursor:
        decode_cursor(
            cursor,
            {"kind": "prepare", "session": session.id, "digest": session.plan_digest},
        )
    ordered = list(db.scalars(preparation_items(session.id, db=db)))
    root_item, nodes = _validate_preparation(session, team, ordered, db=db)
    from .projects import _create_node
    from .storage import materialize_resource

    count = 0
    for item in ordered:
        if item.prepared_object_id is not None:
            continue
        payload = dict(item.payload)
        if item.kind == "node":
            parent = (
                db.get(Project, session.existing_parent_id)
                if session.mode == "subproject"
                else db.get(Project, root_item.prepared_object_id)
                if item.node_key != root_item.node_key
                else None
            )
            if payload.get("source_created_at"):
                payload["source_created_at"] = (
                    datetime.fromisoformat(
                        payload["source_created_at"].replace("Z", "+00:00")
                    )
                    .astimezone(UTC)
                    .replace(tzinfo=None)
                )
            row = _create_node(
                actor, team, payload, db=db, parent=parent, published=False
            )
            if parent and session.mode == "root":
                row.published_at = utcnow()
            item.prepared_object_id = row.id
        else:
            node = db.get(Project, nodes[item.node_key].prepared_object_id)
            if item.kind == "member":
                uid = payload["user_id"]
                row = db.scalar(
                    select(ProjectMember).where(
                        ProjectMember.project_id == node.id,
                        ProjectMember.user_id == uid,
                        ProjectMember.status == "active",
                    )
                )
                if row is None:
                    row = ProjectMember(
                        project_id=node.id,
                        team_id=team_id,
                        root_depth_guard=0,
                        user_id=uid,
                        team_membership_id=item.validated_team_membership_id,
                        status="active",
                        added_by_user_id=actor.user_id,
                        added_by_name_snapshot=label(team.user),
                        joined_at=utcnow(),
                    )
                    db.add(row)
                    db.flush()
                item.prepared_object_id = row.id
            elif item.kind == "task":
                assignee = (
                    db.get(User, payload["assignee_user_id"])
                    if payload.get("assignee_user_id")
                    else None
                )
                now = utcnow()
                row = ProjectTask(
                    project_id=node.id,
                    title=name(payload["title"]),
                    description=payload["description"],
                    status=payload["status"],
                    lifecycle_status="active",
                    created_by_user_id=actor.user_id,
                    created_by_name_snapshot=label(team.user),
                    driver_user_id=actor.user_id,
                    driver_name_snapshot=label(team.user),
                    assignee_user_id=assignee.id if assignee else None,
                    assignee_name_snapshot=label(assignee) if assignee else None,
                    version=1,
                    created_at=now,
                    updated_at=now,
                )
                db.add(row)
                db.flush()
                item.prepared_object_id = row.id
            else:
                upload = db.scalar(
                    select(ResourceUpload)
                    .where(
                        ResourceUpload.conversion_item_id == item.id,
                        ResourceUpload.status == "verified",
                    )
                    .order_by(ResourceUpload.id)
                    .with_for_update()
                )
                if upload is None:
                    fail("CONVERSION_NOT_READY", 409)
                row = materialize_resource(upload, node, team.user, db=db)
                item.prepared_object_id = row.id
        count += 1
        if count >= 50:
            break
    db.flush()
    pending = db.scalar(
        select(ProjectConversionItem.id)
        .where(
            ProjectConversionItem.conversion_id == session.id,
            ProjectConversionItem.prepared_object_id.is_(None),
        )
        .limit(1)
    )
    session.status = "ready" if pending is None else "preparing"
    session.version += 1
    session.updated_at = utcnow()
    audit(
        actor,
        team_id,
        "conversion_prepared",
        db=db,
        resource_id=session.id,
        detail={"prepared_items": count},
    )
    result = session_view(session, db=db)
    return {
        "session": result,
        "prepared": count,
        "next_cursor": result["next_prepare_cursor"],
    }


def commit_conversion(actor, team_id, session_id, expected_version, operation, *, db):
    session, team = own_session(
        actor, team_id, session_id, db=db, write=True, allow_committed=True
    )
    from .projects import detail

    if session.status == "committed":
        return detail(actor, team_id, session.committed_project_id, db=db)
    version(session, expected_version)
    if session.status != "ready":
        fail("CONVERSION_NOT_READY", 409)
    items = _items(session, db=db)
    root, nodes = _validate_graph(session, team, items, db=db)
    if any(i.prepared_object_id is None for i in items):
        fail("CONVERSION_NOT_READY", 409)
    for item in items:
        if item.kind == "resource" and not db.scalar(
            select(ResourceUpload.id).where(
                ResourceUpload.conversion_item_id == item.id,
                ResourceUpload.status == "verified",
                ResourceUpload.resource_id == item.prepared_object_id,
            )
        ):
            fail("CONVERSION_NOT_READY", 409)
    node = db.get(Project, root.prepared_object_id)
    node.published_at = utcnow()
    session.committed_project_id = node.id
    session.status = "committed"
    session.version += 1
    session.updated_at = utcnow()
    touch(node)
    event(
        actor,
        node,
        "project_converted",
        db=db,
        detail={
            "selected_nodes": len(nodes),
            "selected_resources": sum(i.kind == "resource" for i in items),
        },
    )
    if session.mode == "subproject":
        parent = db.get(Project, session.existing_parent_id)
        touch(parent)
        event(actor, parent, "subproject_added", db=db, object_id=node.id)
    db.flush()
    return detail(actor, team_id, node.id, db=db)


def cancel_conversion(
    actor, team_id, session_id, reason, expected_version, operation, *, db
):
    session, team = own_session(actor, team_id, session_id, db=db, write=True)
    version(session, expected_version)
    if session.status != "cancelled":
        session.status = "cancelled"
        session.version += 1
        session.updated_at = utcnow()
        audit(
            actor,
            team_id,
            "conversion_cancelled",
            db=db,
            resource_id=session.id,
            detail={"reason_supplied": bool(reason)},
        )
    return session_view(session, db=db)
