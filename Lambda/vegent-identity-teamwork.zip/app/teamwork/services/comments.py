from sqlalchemy import select

from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.mentions import parse_mentions, validate_content, validate_mentions
from app.teamwork.models import (
    CommentMention,
    ProjectComment,
    ProjectCommentRevision,
    ProjectPR,
    ProjectResource,
    ProjectTask,
)
from app.teamwork.paging import sql_page
from app.teamwork.permissions import Action, require_project
from app.teamwork.projection import comment_view, project_projection
from app.teamwork.services.common import event, label, scoped, touch, version


def _anchor(grant, body, *, db):
    values = {key: getattr(body, key) for key in ("task_id", "pr_id", "resource_id")}
    if sum(v is not None for v in values.values()) > 1:
        fail("INVALID_ANCHOR", 422)
    if body.parent_comment_id:
        parent = scoped(ProjectComment, grant.node.id, body.parent_comment_id, db=db)
        if parent.parent_comment_id is not None:
            fail("INVALID_REPLY", 422)
        if parent.status == "deleted":
            fail("COMMENT_DELETED", 409)
        for key in values:
            if values[key] is not None and values[key] != getattr(parent, key):
                fail("INVALID_ANCHOR", 422)
            values[key] = getattr(parent, key)
    for key, cls, deleted in [
        ("task_id", ProjectTask, "lifecycle_status"),
        ("pr_id", ProjectPR, None),
        ("resource_id", ProjectResource, "status"),
    ]:
        if values[key]:
            target = db.get(cls, values[key])
            if (
                target is None
                or target.project_id != grant.node.id
                or deleted
                and getattr(target, deleted) == "deleted"
            ):
                fail("INVALID_ANCHOR", 422)
    return values


def _mentions(row, labels, *, db):
    now = utcnow()
    existing = {
        m.mentioned_user_id: m
        for m in db.scalars(
            select(CommentMention).where(CommentMention.comment_id == row.id)
        )
    }
    for uid, m in existing.items():
        if uid not in labels:
            m.status = "removed"
            m.changed_version = row.version
            m.updated_at = now
    for uid, name in labels.items():
        if uid in existing:
            existing[uid].mentioned_name_snapshot = name
            existing[uid].status = "active"
            existing[uid].changed_version = row.version
            existing[uid].updated_at = now
        else:
            db.add(
                CommentMention(
                    comment_id=row.id,
                    mentioned_user_id=uid,
                    mentioned_name_snapshot=name,
                    status="active",
                    changed_version=row.version,
                    created_at=now,
                    updated_at=now,
                )
            )
    db.add(
        ProjectCommentRevision(
            comment_id=row.id,
            version=row.version,
            actor_user_id=db.info["actor_id"],
            status=row.status,
            content=row.content,
            mentions_snapshot=[
                {"user_id": uid, "name": name} for uid, name in labels.items()
            ],
            created_at=now,
        )
    )


def create_comment(actor, team_id, node_id, body, operation, *, db):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    anchors = _anchor(grant, body, db=db)
    value = validate_content(body.content)
    value, labels = validate_mentions(
        parse_mentions(value), grant, db=db, content=value
    )
    now = utcnow()
    row = ProjectComment(
        project_id=node_id,
        **anchors,
        parent_comment_id=body.parent_comment_id,
        author_user_id=actor.user_id,
        author_project_member_id=grant.project_member.id,
        author_name_snapshot=label(grant.user),
        author_role_snapshot="creator" if grant.creator else "member",
        content=value,
        status="active",
        version=1,
        created_at=now,
        updated_at=now,
    )
    db.add(row)
    db.flush()
    db.info["actor_id"] = actor.user_id
    _mentions(row, labels, db=db)
    touch(grant.node)
    event(
        actor,
        grant.node,
        "comment_created",
        db=db,
        object_type="comment",
        object_id=row.id,
        object_version=row.version,
    )
    db.flush()
    return comment_view(row, project_projection(grant, db=db), db=db)


def get_comment(actor, team_id, node_id, comment_id, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    row = scoped(ProjectComment, node_id, comment_id, db=db)
    return comment_view(row, project_projection(grant, db=db), db=db)


def list_comments(actor, team_id, node_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    q = select(ProjectComment).where(ProjectComment.project_id == node_id)
    for key in (
        "task_id",
        "pr_id",
        "resource_id",
        "author_user_id",
        "parent_comment_id",
    ):
        if query.get(key) is not None:
            q = q.where(getattr(ProjectComment, key) == query[key])
    if query.get("mentioned_user_id") is not None:
        q = q.join(
            CommentMention, CommentMention.comment_id == ProjectComment.id
        ).where(
            CommentMention.mentioned_user_id == query["mentioned_user_id"],
            CommentMention.status == "active",
            ProjectComment.status != "deleted",
        )
    descending = query.get("order", "newest") == "newest"
    if query.get("order", "newest") not in ("newest", "oldest"):
        fail("VALIDATION_ERROR", 422)
    return sql_page(
        q,
        ProjectComment,
        lambda row: comment_view(row, projection, db=db),
        db=db,
        scope={
            "kind": "comments",
            "node": node_id,
            "filter": {k: v for k, v in query.items() if k not in ("limit", "cursor")},
        },
        order=[
            (ProjectComment.created_at, descending),
            (ProjectComment.id, descending),
        ],
        limit=query.get("limit", 50),
        cursor=query.get("cursor"),
        projection_version=projection.context_version,
    )


def edit_comment(
    actor, team_id, node_id, comment_id, body, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    row = scoped(ProjectComment, node_id, comment_id, db=db)
    if row.author_user_id != actor.user_id:
        fail("FORBIDDEN", 403)
    version(
        row,
        expected_version,
        comment_view(row, project_projection(grant, db=db), db=db),
    )
    if row.status == "deleted":
        fail("COMMENT_DELETED", 409)
    value = validate_content(body.content)
    value, labels = validate_mentions(
        parse_mentions(value), grant, row, db=db, content=value
    )
    if value != row.content:
        row.content = value
        row.status = "edited"
        row.version += 1
        row.updated_at = row.edited_at = utcnow()
        db.info["actor_id"] = actor.user_id
        _mentions(row, labels, db=db)
        touch(grant.node)
        event(
            actor,
            grant.node,
            "comment_edited",
            db=db,
            object_type="comment",
            object_id=row.id,
            object_version=row.version,
        )
    db.flush()
    return comment_view(row, project_projection(grant, db=db), db=db)


def delete_comment(
    actor, team_id, node_id, comment_id, expected_version, operation, *, db
):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    row = scoped(ProjectComment, node_id, comment_id, db=db)
    if not grant.creator and row.author_user_id != actor.user_id:
        fail("FORBIDDEN", 403)
    version(
        row,
        expected_version,
        comment_view(row, project_projection(grant, db=db), db=db),
    )
    if row.status == "deleted":
        fail("COMMENT_DELETED", 409)
    row.status = "deleted"
    row.version += 1
    row.updated_at = row.deleted_at = utcnow()
    row.deleted_by_user_id = actor.user_id
    db.info["actor_id"] = actor.user_id
    _mentions(row, {}, db=db)
    touch(grant.node)
    event(
        actor,
        grant.node,
        "comment_deleted",
        db=db,
        object_type="comment",
        object_id=row.id,
        object_version=row.version,
    )
