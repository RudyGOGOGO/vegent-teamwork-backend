from sqlalchemy import func, select

from app.services.team_members import utcnow
from app.teamwork.errors import fail
from app.teamwork.models import ProjectComment, ProjectResource, ProjectResourceVersion
from app.teamwork.paging import sql_page
from app.teamwork.permissions import Action, require_project
from app.teamwork.projection import actor_display, project_projection, text_value
from app.teamwork.services.common import confirmation, event, iso, scoped, touch


def resource_view(row, projection, *, db, pinned_version=None):
    item = db.scalar(
        select(ProjectResourceVersion).where(
            ProjectResourceVersion.resource_id == row.id,
            ProjectResourceVersion.resource_version
            == (pinned_version or row.current_version),
        )
    )
    if item is None:
        fail("NOT_FOUND", 404)
    first = db.scalar(
        select(ProjectResourceVersion).where(
            ProjectResourceVersion.resource_id == row.id,
            ProjectResourceVersion.resource_version == 1,
        )
    )
    checksum = (
        {
            "algorithm": item.checksum_algorithm,
            "type": item.checksum_type,
            "value": item.checksum_value,
        }
        if item.checksum_algorithm
        else None
    )
    comments = db.scalar(
        select(func.count())
        .select_from(ProjectComment)
        .where(ProjectComment.resource_id == row.id)
    )
    return {
        "id": row.id,
        "project_id": row.project_id,
        "name": text_value(
            "resource",
            item,
            "name",
            row.project_id,
            projection.context_version,
            db=db,
            resource_version=item.resource_version,
        ),
        "media_type": item.media_type,
        "size_bytes": item.size_bytes,
        "version": item.resource_version,
        "entity_version": row.entity_version,
        "status": row.status,
        "created_by": actor_display(
            row.created_by_user_id,
            first.uploader_name_snapshot if first else None,
            projection.members,
            db=db,
        ),
        "uploader": actor_display(
            item.uploaded_by_user_id,
            item.uploader_name_snapshot,
            projection.members,
            db=db,
        ),
        "updated_at": iso(item.created_at),
        "checksum": checksum,
        "download_ref": {
            "resource_id": row.id,
            "version": item.resource_version,
            "href": f"/api/teams/{projection.node.team_id}/projects/{row.project_id}/resources/{row.id}/download-authorizations",
        },
        "comment_count": comments,
        "comments_href": f"/api/teams/{projection.node.team_id}/projects/{row.project_id}/comments?resource_id={row.id}",
    }


def require_resource_writer(grant, row):
    if not grant.creator and row.created_by_user_id != grant.user.id:
        fail("FORBIDDEN", 403)


def list_resources(actor, team_id, node_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    projection = project_projection(grant, db=db)
    status = query.get("status", "all")
    if status not in ("active", "archived", "all"):
        fail("VALIDATION_ERROR", 422)
    q = select(ProjectResource).where(
        ProjectResource.project_id == node_id,
        ProjectResource.status != "deleted",
        ProjectResource.current_version > 0,
    )
    if status != "all":
        q = q.where(ProjectResource.status == status)
    return sql_page(
        q,
        ProjectResource,
        lambda row: resource_view(row, projection, db=db),
        db=db,
        scope={"kind": "resources", "node": node_id, "status": status},
        order=[(ProjectResource.updated_at, True), (ProjectResource.id, True)],
        limit=query.get("limit", 50),
        cursor=query.get("cursor"),
        projection_version=projection.context_version,
    )


def list_versions(actor, team_id, node_id, resource_id, query, *, db):
    grant = require_project(actor, team_id, node_id, db=db)
    row = scoped(ProjectResource, node_id, resource_id, db=db, deleted_field="status")
    projection = project_projection(grant, db=db)
    q = select(ProjectResourceVersion).where(
        ProjectResourceVersion.resource_id == row.id
    )
    return sql_page(
        q,
        ProjectResourceVersion,
        lambda item: resource_view(
            row, projection, db=db, pinned_version=item.resource_version
        ),
        db=db,
        scope={"kind": "resource_versions", "node": node_id, "resource": resource_id},
        order=[(ProjectResourceVersion.resource_version, True)],
        limit=query.limit,
        cursor=query.cursor,
        projection_version=projection.context_version,
    )


def change_resource_lifecycle(
    actor,
    team_id,
    node_id,
    resource_id,
    action,
    body,
    expected_version,
    operation,
    *,
    db,
):
    grant = require_project(actor, team_id, node_id, Action.WRITE_WORK, db=db)
    row = scoped(ProjectResource, node_id, resource_id, db=db, deleted_field="status")
    require_resource_writer(grant, row)
    if row.entity_version != expected_version:
        fail("VERSION_CONFLICT", 409, current={"entity_version": row.entity_version})
    if action == "delete":
        confirmation(body)
    target = {"archive": "archived", "unarchive": "active", "delete": "deleted"}[action]
    if row.status != target:
        row.status = target
        row.entity_version += 1
        row.updated_at = utcnow()
        touch(grant.node)
        event(
            actor,
            grant.node,
            "resource_" + action,
            db=db,
            object_type="resource",
            object_id=row.id,
            object_version=row.entity_version,
        )
    if action == "delete":
        return None
    db.flush()
    return resource_view(row, project_projection(grant, db=db), db=db)
