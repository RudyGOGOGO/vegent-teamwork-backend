import base64
from dataclasses import dataclass
from datetime import timedelta
from uuid import uuid4

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from sqlalchemy import select

from app.services.team_members import utcnow
from app.teamwork.config import expiry_seconds, storage_config
from app.teamwork.cursors import digest
from app.teamwork.errors import fail
from app.teamwork.models import (
    ProjectConversionSession,
    ProjectResource,
    ProjectResourceVersion,
    ResourceUpload,
    ResourceUploadPart,
)
from app.teamwork.operations import (
    begin_operation,
    complete_operation,
    operation_view,
    valid_uuid,
)
from app.teamwork.paging import page
from app.teamwork.permissions import Action, require_project
from app.teamwork.services.common import audit, event, iso, label, touch
from app.teamwork.services.resources import require_resource_writer
from app.teamwork.transactions import write_session

SINGLE_MAX = 5 * 1024**3
MULTIPART_THRESHOLD = 100 * 1024**2
PART_MIN = 5 * 1024**2
PART_MAX = 5 * 1024**3
OBJECT_MAX = 10000 * PART_MAX


@dataclass(frozen=True)
class UploadTarget:
    team_id: int
    node_id: int | None = None
    session_id: int | None = None
    item_id: int | None = None
    expected_session_version: int | None = None


def s3_client(config):
    return boto3.client(
        "s3",
        region_name=config.region,
        config=Config(
            signature_version="s3v4",
            connect_timeout=1,
            read_timeout=3,
            retries={"max_attempts": 1},
            s3={"addressing_style": "virtual"},
        ),
    )


def _authority(actor, row, *, db, write=False):
    if row.actor_user_id != actor.user_id:
        fail("NOT_FOUND", 404)
    if row.project_id:
        grant = require_project(
            actor,
            row.team_id,
            row.project_id,
            Action.WRITE_WORK if write else Action.READ,
            db=db,
        )
        if row.resource_id:
            resource = db.get(ProjectResource, row.resource_id)
            if (
                resource is None
                or resource.project_id != row.project_id
                or resource.status == "deleted"
            ):
                fail("NOT_FOUND", 404)
            if write:
                require_resource_writer(grant, resource)
        return grant
    from .conversion import own_session

    session, team = own_session(
        actor, row.team_id, row.conversion_id, db=db, write=write
    )
    if session.status == "committed":
        require_project(actor, row.team_id, session.committed_project_id, db=db)
    return team


def _load(actor, team_id, upload_id, *, db, write=False):
    row = db.get(ResourceUpload, upload_id)
    if row is None or row.team_id != team_id:
        fail("NOT_FOUND", 404)
    grant = _authority(actor, row, db=db, write=write)
    row = db.scalar(
        select(ResourceUpload)
        .where(ResourceUpload.id == upload_id)
        .with_for_update(read=not write)
        .execution_options(populate_existing=True)
    )
    if row.expires_at is None and row.status not in (
        "published",
        "verified",
        "cancelled",
        "expired",
    ):
        fail("STAGING_POLICY_REQUIRED", 503)
    if (
        row.expires_at
        and row.expires_at <= utcnow()
        and row.status not in ("published", "verified")
    ):
        fail("UPLOAD_EXPIRED", 409)
    return row, grant


def _state(row, *, db):
    published = row.status == "published"
    if row.conversion_id:
        session = db.get(ProjectConversionSession, row.conversion_id)
        published = bool(session and session.status == "committed" and row.resource_id)
    version = None
    if published and row.resource_id:
        version = db.scalar(
            select(ProjectResourceVersion.resource_version).where(
                ProjectResourceVersion.resource_id == row.resource_id,
                ProjectResourceVersion.s3_object_key == row.object_key,
            )
        )
    return {
        "upload_id": row.id,
        "client_upload_id": row.client_upload_id,
        "state": "published" if published else row.status,
        "version": row.version,
        "declared_size": row.declared_size,
        "verified_size": row.declared_size
        if row.status in ("verified", "published")
        else None,
        "verified_parts": row.verified_part_count,
        "manifest_hash": row.part_manifest_hash,
        "checksum": row.verified_checksum,
        "resource_id": row.resource_id if published else None,
        "resource_version": version,
    }


def get_upload(actor, team_id, upload_id, *, db):
    row, grant = _load(actor, team_id, upload_id, db=db)
    return _state(row, db=db)


def _op(actor, operation, *, db):
    return begin_operation(actor, operation.key, operation, db=db)


def _version(row, expected, state):
    if not state.replayed and row.version != expected:
        fail("VERSION_CONFLICT", 409, current={"version": row.version})


def _signed(client, method, params, cfg, *, headers=None, http_method=None):
    try:
        url = client.generate_presigned_url(
            method, Params=params, ExpiresIn=cfg.ttl, HttpMethod=http_method
        )
    except Exception:
        fail("STORAGE_UNAVAILABLE", 503)
    return {
        "url": url,
        "method": http_method or ("GET" if method == "get_object" else "PUT"),
        "headers": headers or {},
        "expires_at": iso(utcnow() + timedelta(seconds=cfg.ttl)),
    }


def authorize_upload(actor, target, body, operation):
    cfg = storage_config()
    valid_uuid(body.client_upload_id)
    if (
        not body.name.strip()
        or any(c in body.name for c in ("/", "\\", "\x00"))
        or body.media_type not in cfg.media_types
    ):
        fail("VALIDATION_ERROR", 422)
    if body.size_bytes > OBJECT_MAX:
        fail("STORAGE_LIMIT_EXCEEDED", 422)
    # This transport threshold is not a product file-size limit.
    mode = (
        "multipart"
        if body.size_bytes > SINGLE_MAX
        or (body.size_bytes >= MULTIPART_THRESHOLD and not body.sha256)
        else "single_put"
    )
    if mode == "multipart" and body.sha256:
        fail("CHECKSUM_MODE_UNSUPPORTED", 422)
    with write_session() as db:
        db.info["teamwork_write"] = True
        if target.node_id:
            grant = require_project(
                actor, target.team_id, target.node_id, Action.WRITE_WORK, db=db
            )
            if body.resource_id:
                resource = db.get(ProjectResource, body.resource_id)
                if (
                    resource is None
                    or resource.project_id != target.node_id
                    or resource.status == "deleted"
                ):
                    fail("NOT_FOUND", 404)
                require_resource_writer(grant, resource)
        else:
            from app.teamwork.models import ProjectConversionItem

            from .conversion import own_session

            session, grant = own_session(
                actor, target.team_id, target.session_id, db=db, write=True
            )
            if session.version != target.expected_session_version:
                fail("VERSION_CONFLICT", 409, current={"version": session.version})
            item = db.get(ProjectConversionItem, target.item_id)
            if (
                item is None
                or item.conversion_id != session.id
                or item.kind != "resource"
                or body.resource_id
            ):
                fail("NOT_FOUND", 404)
            descriptor = item.payload
            if any(
                descriptor.get(k) != getattr(body, k)
                for k in ("name", "media_type", "size_bytes", "sha256")
            ):
                fail("PLAN_RESOURCE_CHANGED", 409)
        state = _op(actor, operation, db=db)
        row = db.scalar(
            select(ResourceUpload)
            .where(
                ResourceUpload.actor_user_id == actor.user_id,
                ResourceUpload.client_upload_id == body.client_upload_id,
            )
            .with_for_update()
        )
        if row:
            if row.expires_at is None and row.status not in (
                "published",
                "verified",
                "cancelled",
                "expired",
            ):
                fail("STAGING_POLICY_REQUIRED", 503)
            fields = {
                "team_id": target.team_id,
                "project_id": target.node_id,
                "conversion_id": target.session_id,
                "conversion_item_id": target.item_id,
                "resource_id": body.resource_id,
                "name": body.name,
                "media_type": body.media_type,
                "declared_size": body.size_bytes,
                "declared_sha256": body.sha256,
            }
            if any(getattr(row, k) != v for k, v in fields.items()):
                fail("IDEMPOTENCY_CONFLICT", 409)
            _authority(actor, row, db=db, write=True)
            if row.status not in ("pending", "uploading"):
                fail("UPLOAD_CONFLICT", 409)
        else:
            now = utcnow()
            seconds = expiry_seconds("upload")
            row = ResourceUpload(
                team_id=target.team_id,
                project_id=target.node_id,
                conversion_id=target.session_id,
                conversion_item_id=target.item_id,
                resource_id=body.resource_id,
                actor_user_id=actor.user_id,
                client_upload_id=body.client_upload_id,
                name=body.name,
                media_type=body.media_type,
                declared_size=body.size_bytes,
                declared_sha256=body.sha256,
                upload_kind=mode,
                status="pending",
                object_key=f"{cfg.prefix}/uploads/{uuid4()}",
                version=1,
                verification_cursor=0,
                verified_part_count=0,
                verified_size_bytes=0,
                created_at=now,
                updated_at=now,
                expires_at=now + timedelta(seconds=seconds) if seconds else None,
            )
            db.add(row)
            db.flush()
            audit(actor, target.team_id, "upload_authorized", db=db, resource_id=row.id)
        uid = row.id
        key = row.object_key
        multipart_id = row.multipart_id
        complete_operation(
            state,
            {"kind": "upload", "id": uid, "version": row.version, "status": 201},
            db=db,
        )
        original_op = operation_view(state)
    client = s3_client(cfg)
    if mode == "multipart" and multipart_id is None:
        try:
            created = client.create_multipart_upload(
                Bucket=cfg.bucket,
                Key=key,
                ContentType=body.media_type,
                ChecksumAlgorithm="SHA256",
            )["UploadId"]
        except Exception:
            fail("STORAGE_UNAVAILABLE", 503)
        with write_session() as db:
            db.info["teamwork_write"] = True
            row, grant = _load(actor, target.team_id, uid, db=db, write=True)
            if row.multipart_id is None:
                row.multipart_id = created
            multipart_id = row.multipart_id
    with write_session() as db:
        db.info["teamwork_write"] = True
        row, grant = _load(actor, target.team_id, uid, db=db, write=True)
        row.status = "uploading"
        row.updated_at = utcnow()
        row.last_url_expires_at = utcnow() + timedelta(seconds=cfg.ttl)
        request = None
        if mode == "single_put":
            params = {
                "Bucket": cfg.bucket,
                "Key": row.object_key,
                "ContentType": row.media_type,
                "IfNoneMatch": "*",
            }
            headers = {"Content-Type": row.media_type, "If-None-Match": "*"}
            if row.declared_sha256:
                checksum = base64.b64encode(bytes.fromhex(row.declared_sha256)).decode()
                params["ChecksumSHA256"] = checksum
                headers["x-amz-checksum-sha256"] = checksum
            request = _signed(client, "put_object", params, cfg, headers=headers)
        data = {
            "upload_id": uid,
            "version": row.version,
            "state": row.status,
            "mode": mode,
            "single_put": request,
            "multipart": {
                "part_authorization_href": f"/api/teams/{row.team_id}/uploads/{uid}/part-authorizations",
                "complete_href": f"/api/teams/{row.team_id}/uploads/{uid}/complete",
            }
            if mode == "multipart"
            else None,
            "expires_at": iso(row.expires_at),
        }
        return data, original_op


def authorize_parts(
    actor, team_id, upload_id, body, expected_version, operation, cursor=None
):
    cfg = storage_config()
    client = s3_client(cfg)
    if len({part.part_number for part in body.parts}) != len(body.parts):
        fail("VALIDATION_ERROR", 422)
    with write_session() as db:
        db.info["teamwork_write"] = True
        row, grant = _load(actor, team_id, upload_id, db=db, write=True)
        state = _op(actor, operation, db=db)
        _version(row, expected_version, state)
        if (
            row.upload_kind != "multipart"
            or row.status not in ("pending", "uploading")
            or row.part_manifest_sealed_at is not None
        ):
            fail("UPLOAD_CONFLICT", 409)
        existing_parts = {
            part.part_number: part
            for part in db.scalars(
                select(ResourceUploadPart).where(ResourceUploadPart.upload_id == row.id)
            )
        }
        for part in body.parts:
            if part.part_number > 10000 or part.size_bytes > PART_MAX:
                fail("STORAGE_LIMIT_EXCEEDED", 422)
            old = existing_parts.get(part.part_number)
            expected = (
                base64.b64encode(bytes.fromhex(part.checksum_sha256)).decode()
                if part.checksum_sha256
                else None
            )
            if old and (
                old.expected_size != part.size_bytes
                or old.expected_checksum != expected
            ):
                fail("UPLOAD_CONFLICT", 409)
            if not old:
                db.add(
                    ResourceUploadPart(
                        upload_id=row.id,
                        part_number=part.part_number,
                        expected_size=part.size_bytes,
                        checksum_algorithm="SHA256" if expected else None,
                        expected_checksum=expected,
                        created_at=utcnow(),
                    )
                )
        if not state.replayed:
            row.version += 1
        row.last_url_expires_at = utcnow() + timedelta(seconds=cfg.ttl)
        db.flush()
        key = row.object_key
        mid = row.multipart_id
        v = row.version
        descriptors = [
            (
                p.part_number,
                base64.b64encode(bytes.fromhex(p.checksum_sha256)).decode()
                if p.checksum_sha256
                else None,
            )
            for p in body.parts
        ]
        complete_operation(state, {"kind": "upload", "id": row.id, "version": v}, db=db)
        op = operation_view(state)
    # Signing is local SDK work; returned capability pages remain transport-bounded.
    items = []
    for number, checksum in descriptors:
        params = {
            "Bucket": cfg.bucket,
            "Key": key,
            "UploadId": mid,
            "PartNumber": number,
        }
        headers = {}
        if checksum:
            params["ChecksumSHA256"] = checksum
            headers["x-amz-checksum-sha256"] = checksum
        items.append(
            {
                "part_number": number,
                "request": _signed(client, "upload_part", params, cfg, headers=headers),
                "_cursor_key": number,
            }
        )
    result = page(
        items,
        scope={
            "kind": "upload_parts",
            "upload": upload_id,
            "parts": digest(descriptors),
        },
        limit=len(items),
        cursor=cursor,
    )
    with write_session() as db:
        row, grant = _load(actor, team_id, upload_id, db=db, write=True)
    return {
        "upload_id": upload_id,
        "items": result["items"],
        "next_cursor": result["next_cursor"],
        "has_more": result["has_more"],
    }, op


def _checksum(data, *, single=False):
    kind = data.get("ChecksumType") or ("FULL_OBJECT" if single else None)
    if kind not in ("FULL_OBJECT", "COMPOSITE"):
        return None
    for algorithm in ("SHA256", "SHA1", "CRC64NVME", "CRC32C", "CRC32"):
        value = data.get("Checksum" + algorithm)
        if value:
            return {"algorithm": algorithm, "type": kind, "value": value}
    return None


def materialize_resource(upload, node, user, *, db):
    now = utcnow()
    resource = (
        db.get(ProjectResource, upload.resource_id) if upload.resource_id else None
    )
    if resource is None:
        resource = ProjectResource(
            project_id=node.id,
            name=upload.name,
            status="active",
            created_by_user_id=user.id,
            current_version=0,
            entity_version=1,
            created_at=now,
            updated_at=now,
        )
        db.add(resource)
        db.flush()
        upload.resource_id = resource.id
    existing = db.scalar(
        select(ProjectResourceVersion).where(
            ProjectResourceVersion.resource_id == resource.id,
            ProjectResourceVersion.s3_object_key == upload.object_key,
        )
    )
    if existing:
        return resource
    resource.current_version += 1
    resource.entity_version += 1
    resource.updated_at = now
    resource.name = upload.name
    checksum = upload.verified_checksum or {}
    db.add(
        ProjectResourceVersion(
            resource_id=resource.id,
            resource_version=resource.current_version,
            name=upload.name,
            media_type=upload.media_type,
            size_bytes=upload.declared_size,
            checksum_algorithm=checksum.get("algorithm"),
            checksum_type=checksum.get("type"),
            checksum_value=checksum.get("value"),
            uploaded_by_user_id=user.id,
            uploader_name_snapshot=label(user),
            s3_object_key=upload.object_key,
            s3_version_id=upload.verified_object_version,
            created_at=now,
        )
    )
    return resource


def complete_upload(actor, team_id, upload_id, body, expected_version, operation):
    if body.phase != "authorize" and body.manifest_cursor is not None:
        fail("INVALID_PHASE", 422)
    cfg = storage_config()
    client = s3_client(cfg)
    with write_session() as db:
        db.info["teamwork_write"] = True
        row, grant = _load(actor, team_id, upload_id, db=db, write=True)
        state = _op(actor, operation, db=db)
        _version(row, expected_version, state)
        if row.status in ("published", "verified"):
            complete_operation(
                state, {"kind": "upload", "id": row.id, "version": row.version}, db=db
            )
            return {
                "upload": _state(row, db=db),
                "action": "done",
                "manifest": None,
                "manifest_hash": row.part_manifest_hash,
                "request": None,
            }, operation_view(state)
        if row.status in ("failed", "cancelled", "expired"):
            fail("UPLOAD_CONFLICT", 409)
        if row.upload_kind == "single_put" and body.phase != "confirm":
            fail("INVALID_PHASE", 422)
        if body.phase == "verify":
            if row.status not in ("uploading", "verifying"):
                fail("UPLOAD_CONFLICT", 409)
            row.status = "verifying"
            row.part_manifest_sealed_at = row.part_manifest_sealed_at or utcnow()
        key = row.object_key
        mid = row.multipart_id
        position = row.verification_cursor
        single = row.upload_kind == "single_put"
    observed = None
    head = None
    if body.phase == "verify":
        try:
            observed = client.list_parts(
                Bucket=cfg.bucket,
                Key=key,
                UploadId=mid,
                PartNumberMarker=position,
                MaxParts=1000,
            )
        except Exception:
            fail("STORAGE_UNAVAILABLE", 503)
    elif body.phase == "confirm":
        try:
            head = client.head_object(
                Bucket=cfg.bucket, Key=key, ChecksumMode="ENABLED"
            )
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") in (
                "404",
                "NoSuchKey",
                "NotFound",
            ):
                fail("UPLOAD_NOT_READY", 409)
            fail("STORAGE_UNAVAILABLE", 503)
        except Exception:
            fail("STORAGE_UNAVAILABLE", 503)
    with write_session() as db:
        db.info["teamwork_write"] = True
        row, grant = _load(actor, team_id, upload_id, db=db, write=True)
        state = _op(actor, operation, db=db)
        _version(row, expected_version, state)
        request = None
        manifest = None
        action = "done"
        if state.replayed and body.phase != "authorize":
            action = (
                "continue_verification"
                if row.status == "verifying"
                else "complete_s3"
                if row.status == "awaiting_completion"
                else "done"
            )
            return {
                "upload": _state(row, db=db),
                "action": action,
                "manifest": None,
                "manifest_hash": row.part_manifest_hash,
                "request": None,
            }, operation_view(state)
        if body.phase == "verify":
            if row.verification_cursor != position:
                fail("UPLOAD_CONFLICT", 409)
            observed_parts = observed.get("Parts", [])
            numbers = [part["PartNumber"] for part in observed_parts]
            if numbers != sorted(set(numbers)) or any(
                number <= position for number in numbers
            ):
                fail("STORAGE_UNAVAILABLE", 503)
            if observed.get("IsTruncated") and (
                not numbers or observed.get("NextPartNumberMarker", 0) < numbers[-1]
            ):
                fail("STORAGE_UNAVAILABLE", 503)
            expected_parts = {
                value.part_number: value
                for value in db.scalars(
                    select(ResourceUploadPart).where(
                        ResourceUploadPart.upload_id == row.id,
                        ResourceUploadPart.part_number.in_(
                            [value["PartNumber"] for value in observed_parts]
                        ),
                    )
                )
            }
            for part in observed_parts:
                expected = expected_parts.get(part["PartNumber"])
                if (
                    expected is None
                    or expected.expected_size != part["Size"]
                    or expected.expected_checksum
                    and expected.expected_checksum != part.get("ChecksumSHA256")
                ):
                    fail("UPLOAD_CONFLICT", 409)
                if expected.verified_at is None:
                    row.verified_part_count += 1
                    row.verified_size_bytes += part["Size"]
                elif expected.observed_etag != part["ETag"]:
                    fail("UPLOAD_CONFLICT", 409)
                expected.observed_etag = part["ETag"]
                expected.observed_size = part["Size"]
                expected.observed_checksum = _checksum(
                    {**part, "ChecksumType": "FULL_OBJECT"}
                )
                expected.verified_at = utcnow()
            row.verification_cursor = observed.get("NextPartNumberMarker") or max(
                [position] + [p["PartNumber"] for p in observed.get("Parts", [])]
            )
            if observed.get("IsTruncated"):
                action = "continue_verification"
            else:
                parts = list(
                    db.scalars(
                        select(ResourceUploadPart)
                        .where(ResourceUploadPart.upload_id == row.id)
                        .order_by(ResourceUploadPart.part_number)
                    )
                )
                if (
                    not parts
                    or [p.part_number for p in parts] != list(range(1, len(parts) + 1))
                    or row.verified_part_count != len(parts)
                    or row.verified_size_bytes != row.declared_size
                    or any(p.expected_size < PART_MIN for p in parts[:-1])
                ):
                    fail("UPLOAD_CONFLICT", 409)
                values = [
                    {
                        "part_number": p.part_number,
                        "etag": p.observed_etag,
                        "checksum": p.observed_checksum,
                    }
                    for p in parts
                ]
                row.part_manifest_hash = digest(
                    [(p["part_number"], p["etag"], p["checksum"]) for p in values]
                )
                row.status = "awaiting_completion"
                action = "complete_s3"
        elif body.phase == "authorize":
            if row.status != "awaiting_completion" or not row.part_manifest_hash:
                fail("UPLOAD_NOT_READY", 409)
            values = [
                {
                    "part_number": p.part_number,
                    "etag": p.observed_etag,
                    "checksum": p.observed_checksum,
                    "_cursor_key": p.part_number,
                }
                for p in db.scalars(
                    select(ResourceUploadPart)
                    .where(ResourceUploadPart.upload_id == row.id)
                    .order_by(ResourceUploadPart.part_number)
                )
            ]
            manifest = page(
                values,
                scope={
                    "kind": "completion_manifest",
                    "upload": row.id,
                    "digest": row.part_manifest_hash,
                },
                limit=len(values),
                cursor=body.manifest_cursor,
            )
            request = _signed(
                client,
                "complete_multipart_upload",
                {
                    "Bucket": cfg.bucket,
                    "Key": row.object_key,
                    "UploadId": row.multipart_id,
                    "IfNoneMatch": "*",
                },
                cfg,
                headers={"If-None-Match": "*", "Content-Type": "application/xml"},
                http_method="POST",
            )
            row.completion_authorized_at = utcnow()
            row.last_url_expires_at = utcnow() + timedelta(seconds=cfg.ttl)
            action = "complete_s3"
        else:
            if not single and row.status != "awaiting_completion":
                fail("UPLOAD_NOT_READY", 409)
            if (
                head["ContentLength"] != row.declared_size
                or head.get("ContentType") != row.media_type
            ):
                fail("UPLOAD_CONFLICT", 409)
            checksum = _checksum(head, single=single)
            if not single:
                import hashlib

                observed = list(
                    db.scalars(
                        select(ResourceUploadPart)
                        .where(ResourceUploadPart.upload_id == row.id)
                        .order_by(ResourceUploadPart.part_number)
                    )
                )
                try:
                    raw = [
                        base64.b64decode(part.observed_checksum["value"], validate=True)
                        for part in observed
                    ]
                    if any(
                        part.observed_checksum["algorithm"] != "SHA256"
                        or len(value) != 32
                        for part, value in zip(observed, raw, strict=True)
                    ):
                        raise ValueError()
                    expected = (
                        base64.b64encode(
                            hashlib.sha256(b"".join(raw)).digest()
                        ).decode()
                        + "-"
                        + str(len(raw))
                    )
                except (ValueError, TypeError, KeyError):
                    fail("CHECKSUM_UNAVAILABLE", 503)
                if (
                    checksum is None
                    or checksum["algorithm"] != "SHA256"
                    or checksum["type"] != "COMPOSITE"
                    or checksum["value"] != expected
                ):
                    fail("UPLOAD_CONFLICT", 409)
            if row.declared_sha256 and (
                not checksum
                or checksum["algorithm"] != "SHA256"
                or checksum["type"] != "FULL_OBJECT"
                or checksum["value"]
                != base64.b64encode(bytes.fromhex(row.declared_sha256)).decode()
            ):
                fail("UPLOAD_CONFLICT", 409)
            row.verified_checksum = checksum
            row.verified_object_version = head.get("VersionId")
            row.status = "verified"
            if row.project_id:
                resource = materialize_resource(row, grant.node, grant.user, db=db)
                row.status = "published"
                touch(grant.node)
                event(
                    actor,
                    grant.node,
                    "resource_published",
                    db=db,
                    object_type="resource",
                    object_id=resource.id,
                    object_version=resource.entity_version,
                )
        if not state.replayed:
            row.version += 1
        row.updated_at = utcnow()
        db.flush()
        audit(actor, team_id, "upload_" + body.phase, db=db, resource_id=row.id)
        complete_operation(
            state, {"kind": "upload", "id": row.id, "version": row.version}, db=db
        )
        return {
            "upload": _state(row, db=db),
            "action": action,
            "manifest": manifest,
            "manifest_hash": row.part_manifest_hash,
            "request": request,
        }, operation_view(state)


def cancel_upload(actor, team_id, upload_id, reason, expected_version, operation):
    cfg = storage_config()
    client = s3_client(cfg)
    with write_session() as db:
        db.info["teamwork_write"] = True
        row, grant = _load(actor, team_id, upload_id, db=db, write=True)
        state = _op(actor, operation, db=db)
        _version(row, expected_version, state)
        if row.status == "published":
            fail("UPLOAD_CONFLICT", 409)
        if not state.replayed:
            row.status = "cancelled"
            row.version += 1
            row.updated_at = utcnow()
            audit(
                actor,
                team_id,
                "upload_cancelled",
                db=db,
                resource_id=row.id,
                detail={"reason_supplied": bool(reason)},
            )
        complete_operation(
            state, {"kind": "upload", "id": row.id, "version": row.version}, db=db
        )
        result = _state(row, db=db)
        op = operation_view(state)
        mid = row.multipart_id
        key = row.object_key
    if mid:
        try:
            client.abort_multipart_upload(Bucket=cfg.bucket, Key=key, UploadId=mid)
        except Exception:
            pass
    return result, op


def authorize_download(actor, team_id, node_id, resource_id, version, operation):
    cfg = storage_config()
    client = s3_client(cfg)
    with write_session() as db:
        require_project(actor, team_id, node_id, db=db)
        row = db.get(ProjectResource, resource_id)
        if row is None or row.project_id != node_id or row.status == "deleted":
            fail("NOT_FOUND", 404)
        item = db.scalar(
            select(ProjectResourceVersion).where(
                ProjectResourceVersion.resource_id == resource_id,
                ProjectResourceVersion.resource_version == version,
            )
        )
        if item is None:
            fail("NOT_FOUND", 404)
        state = _op(actor, operation, db=db)
        key = item.s3_object_key
        object_version = item.s3_version_id
        if not state.replayed:
            audit(
                actor,
                team_id,
                "download_authorized",
                db=db,
                resource_id=resource_id,
                detail={"resource_version": version},
            )
        complete_operation(
            state, {"kind": "resource", "id": resource_id, "version": version}, db=db
        )
        op = operation_view(state)
    params = {"Bucket": cfg.bucket, "Key": key}
    if object_version:
        params["VersionId"] = object_version
    request = _signed(client, "get_object", params, cfg, http_method="GET")
    with write_session() as db:
        require_project(actor, team_id, node_id, db=db)
        current = db.get(ProjectResource, resource_id)
        if (
            current is None
            or current.project_id != node_id
            or current.status == "deleted"
        ):
            fail("NOT_FOUND", 404)
    return {"resource_id": resource_id, "version": version, "request": request}, op
