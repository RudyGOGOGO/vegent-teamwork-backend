from datetime import datetime, timezone
from typing import Literal

from pydantic import field_validator

from .common import DTO, ID, ProgressStatus


class ConversionCreate(DTO):
    client_conversion_id: str
    mode: Literal["root", "subproject"]
    existing_parent_id: ID | None = None


class ConversionNode(DTO):
    name: str
    background: str
    goals: str
    category_id: ID | None = None
    parent_node_key: str | None = None
    progress_status: ProgressStatus = "not_started"
    progress_note: str = ""
    source_created_at: datetime | None = None

    @field_validator("source_created_at")
    @classmethod
    def source_time(cls, value):
        if value is not None:
            if value.tzinfo is None or value.year < 1000:
                raise ValueError(
                    "UTC source time within DATETIME storage bounds is required"
                )
            value = value.astimezone(timezone.utc)
        return value


class ConversionItem(DTO):
    client_item_id: str
    node_key: str
    kind: Literal["node", "task", "member", "resource"]
    payload: dict
