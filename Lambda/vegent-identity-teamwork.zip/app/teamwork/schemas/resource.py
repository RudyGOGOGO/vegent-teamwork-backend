"""Public resource metadata contracts; storage transport inputs are in upload."""

from .responses import Resource

__all__ = ["Resource"]
