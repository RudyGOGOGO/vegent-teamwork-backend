"""Reference-only activity contract with no discussion or credential payloads."""

from .responses import Activity, ActivityObject

__all__ = ["Activity", "ActivityObject"]
