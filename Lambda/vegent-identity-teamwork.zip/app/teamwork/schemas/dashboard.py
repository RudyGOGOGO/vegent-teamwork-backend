"""Shared Dashboard contracts used by the typed HTTP response registry."""

from .responses import ProjectDetail, ProjectList, TeamAggregates, TeamDashboard

__all__ = ["ProjectDetail", "ProjectList", "TeamAggregates", "TeamDashboard"]
