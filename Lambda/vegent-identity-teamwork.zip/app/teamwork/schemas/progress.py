from .common import DTO, ProgressStatus


class ProgressPatch(DTO):
    status: ProgressStatus | None = None
    note: str | None = None
