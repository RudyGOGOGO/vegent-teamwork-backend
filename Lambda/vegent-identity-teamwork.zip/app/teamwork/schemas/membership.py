from pydantic import Field

from .common import DTO, ID


class MemberAdd(DTO):
    user_id: ID = Field(
        description="Identity users.id from Team discovery, never a membership-row ID. Integer namespaces may overlap."
    )


class OwnerTransfer(DTO):
    new_creator_user_id: ID = Field(
        description="Identity users.id of an already eligible root member; not project_members.id."
    )


class MemberQuery(DTO):
    search: str | None = None
    user_id: ID | None = None
