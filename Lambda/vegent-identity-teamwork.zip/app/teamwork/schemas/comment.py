from .common import DTO, ID


class CommentCreate(DTO):
    content: str
    task_id: ID | None = None
    pr_id: ID | None = None
    resource_id: ID | None = None
    parent_comment_id: ID | None = None


class CommentEdit(DTO):
    content: str
