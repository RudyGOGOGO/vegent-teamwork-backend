from pydantic import Field

from .common import DTO


class ImportCreate(DTO):
    local_import_id: str
    context_version: str = Field(pattern=r"^[0-9a-f]{64}$")
