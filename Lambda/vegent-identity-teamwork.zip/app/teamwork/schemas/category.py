from .common import DTO


class CategoryCreate(DTO):
    name: str


class CategoryPatch(DTO):
    name: str | None = None
