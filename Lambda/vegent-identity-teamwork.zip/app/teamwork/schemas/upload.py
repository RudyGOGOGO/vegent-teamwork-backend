from typing import Literal

from pydantic import Field

from .common import DTO, ID, Positive


class UploadCreate(DTO):
    client_upload_id: str
    name: str
    media_type: str
    size_bytes: int = Field(strict=True, ge=0)
    sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    resource_id: ID | None = None


class Part(DTO):
    part_number: Positive
    size_bytes: int = Field(strict=True, ge=0)
    checksum_sha256: str = Field(
        pattern=r"^[0-9a-f]{64}$",
        description="Lowercase hex SHA256 of this part; required for SHA256 composite multipart uploads.",
    )


class PartAuthorization(DTO):
    parts: list[Part] = Field(min_length=1)


class UploadComplete(DTO):
    phase: Literal["verify", "authorize", "confirm"]
    manifest_cursor: str | None = None


class DownloadCreate(DTO):
    version: Positive
