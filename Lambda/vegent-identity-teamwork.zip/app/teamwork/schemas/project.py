from .common import DTO, ID


class ProjectCreate(DTO):
    name: str
    category_id: ID | None
    background: str
    goals: str


class ChildCreate(DTO):
    name: str
    background: str
    goals: str


class ProjectPatch(DTO):
    name: str | None = None
    category_id: ID | None = None
    background: str | None = None
    goals: str | None = None


class ProjectFilters(DTO):
    category_id: str | None = None
    status: str = "active"
    progress_status: str | None = None
    blocked: bool | None = None
    needs_pr_review: bool | None = None
    mentioned_me: bool | None = None
    created_by_me: bool | None = None
    q: str | None = None
    view: str = "category"
