from datetime import datetime
from typing import Literal

from .common import DTO


class ContextItemCreate(DTO):
    kind: Literal["decision", "open_question"]
    title: str
    context: str
    body: str
    status: str
    answer: str | None = None
    decided_at: datetime | None = None


class ContextItemPatch(DTO):
    title: str | None = None
    context: str | None = None
    body: str | None = None
    status: str | None = None
    answer: str | None = None
    decided_at: datetime | None = None
