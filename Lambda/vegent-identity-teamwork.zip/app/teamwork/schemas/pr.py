import re
from typing import Literal

from pydantic import Field, field_validator

from .common import DTO


class PRSync(DTO):
    provider: Literal["github", "stash"]
    repository_ref: str = Field(min_length=1, max_length=255)
    external_pr_ids: list[str] | None = Field(default=None, min_length=1)

    @field_validator("external_pr_ids")
    @classmethod
    def valid_external_ids(cls, value):
        if value is not None and any(
            not 1 <= len(v) <= 255 or not re.fullmatch(r"[1-9][0-9]*", v) for v in value
        ):
            raise ValueError("Invalid external PR identifier")
        return value
