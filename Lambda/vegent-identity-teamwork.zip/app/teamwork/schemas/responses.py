from typing import Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict

T = TypeVar("T")


class View(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Page(View, Generic[T]):
    items: list[T]
    next_cursor: str | None
    has_more: bool
    projection_version: str | None = None


class ActorDisplay(View):
    user_id: int
    name: str
    membership_status: Literal["active", "former_member"]


class TextRef(View):
    kind: str
    object_id: int
    field: str
    resource_version: int | None
    context_version: str
    utf8_bytes: int
    href: str


class TextValue(View):
    inline: str | None
    ref: TextRef | None


class CategoryRef(View):
    id: int
    name: str
    created_at: str
    version: int


class Category(CategoryRef):
    team_id: int
    created_by: ActorDisplay
    updated_at: str


class TaskCounts(View):
    total: int
    todo: int
    in_progress: int
    blocked: int
    done: int


class PRCounts(View):
    open: int
    merged: int
    closed: int
    reviewer_mapping_complete: bool


class Counts(View):
    tasks: TaskCounts
    prs: PRCounts
    resources: int
    comments: int
    open_questions: int
    members: int
    subprojects: int


class Progress(View):
    status: Literal[
        "not_started", "in_progress", "blocked", "in_review", "completed", "on_hold"
    ]
    note: TextValue
    author: ActorDisplay
    updated_at: str
    project_version: int


class Ownership(View):
    state: Literal["assigned", "unassigned"]
    creator: ActorDisplay
    lost_at: str | None
    source_project_id: int


class ParentRef(View):
    id: int
    name: str
    href: str


class SubprojectLink(View):
    count: int
    href: str | None


class SharedProjectSummary(View):
    id: int
    team_id: int
    team_name: str
    scope: Literal["team"]
    node_kind: Literal["project", "subproject"]
    parent_project_id: int | None
    parent: ParentRef | None
    membership_source_project_id: int
    category: CategoryRef | None
    name: str
    creator: ActorDisplay
    created_by: ActorDisplay
    created_at: str
    source_created_at: str | None
    updated_at: str
    last_activity_at: str
    status: Literal["active", "archived"]
    own_status: Literal["active", "archived"]
    archived_by_parent: bool
    ownership: Ownership
    progress: Progress
    counts: Counts
    version: int
    context_version: str
    subprojects: SubprojectLink


class Capabilities(View):
    can_import: bool
    import_disabled_reason: str | None
    can_convert: bool
    convert_disabled_reason: str | None
    can_edit_info: bool
    can_manage_members: bool
    can_archive: bool
    can_unarchive: bool
    can_delete: bool
    read_only_reason: str | None


class ViewerFacts(View):
    open_prs_reviewing_me: int
    reviewer_mapping_complete: bool
    mentioned_me_count: int
    is_creator: bool


class ProjectSummary(SharedProjectSummary):
    capabilities: Capabilities
    viewer: ViewerFacts


class ProjectDetail(ProjectSummary):
    background: TextValue
    goals: TextValue
    subproject_page: Page[ProjectSummary] | None
    sections: dict[str, str]


class Member(View):
    project_member_id: int
    user_id: int
    name: str
    email: str
    project_role: Literal["creator", "member"]
    joined_at: str
    added_by: ActorDisplay
    membership_status: Literal["active"]


class Task(View):
    id: int
    project_id: int
    title: str
    description: TextValue
    status: Literal["todo", "in_progress", "blocked", "done"]
    lifecycle_status: Literal["active", "archived"]
    created_by: ActorDisplay
    driver: ActorDisplay
    assignee: ActorDisplay | None
    assignee_membership_status: Literal["active", "former_member"] | None
    requires_reassignment: bool
    version: int
    created_at: str
    updated_at: str
    comment_count: int
    comments_href: str


class Navigation(View):
    type: Literal["project_members"]
    project_id: int
    user_id: int


class Mention(View):
    user_id: int
    name: str
    membership_status: Literal["active", "former_member"]
    render_as: Literal["member_chip", "former_member_chip"]
    navigation: Navigation | None


class CommentAuthor(View):
    user_id: int
    name: str
    role_at_creation: Literal["creator", "member"]
    current_project_role: Literal["creator", "member"] | None
    membership_status: Literal["active", "former_member"]


class Comment(View):
    id: int
    project_id: int
    task_id: int | None
    pr_id: int | None
    resource_id: int | None
    parent_comment_id: int | None
    author: CommentAuthor
    content: str
    status: Literal["active", "edited", "deleted"]
    version: int
    mentions: list[Mention]
    created_at: str
    updated_at: str
    edited_at: str | None
    is_edited: bool
    deleted_at: str | None
    is_deleted: bool


class ContextItem(View):
    id: int
    project_id: int
    kind: Literal["decision", "open_question"]
    title: str
    context: TextValue
    body: TextValue
    answer: TextValue | None
    status: str
    author: ActorDisplay
    decided_at: str | None
    version: int
    created_at: str
    updated_at: str


class ProgressEvent(View):
    id: int
    project_id: int
    source_project_id: int
    type: Literal["progress_changed", "archived", "unarchived"]
    actor: ActorDisplay
    old_status: str
    new_status: str
    old_note: TextValue
    new_note: TextValue
    project_version: int
    created_at: str
    inherited: bool


class ActivityObject(View):
    type: str
    id: int | None
    version: int | None
    href: str | None


class Activity(View):
    id: int
    project_id: int
    project_name: str
    parent_project_id: int | None
    actor: ActorDisplay
    type: str
    object: ActivityObject
    time: str
    inherited: bool


class Reviewer(View):
    user_id: int | None
    name: str
    membership_status: Literal["active", "former_member", "external"]


class PR(View):
    id: int
    project_id: int
    provider: Literal["github", "stash"]
    repository_ref: str
    external_pr_id: str
    title: TextValue
    url: str
    branch: TextValue
    status: Literal["open", "merged", "closed"]
    reviewers: list[Reviewer]
    reviewer_mapping_complete: bool
    synced_at: str
    version: int
    comment_count: int
    comments_href: str


class Checksum(View):
    algorithm: str
    type: Literal["FULL_OBJECT", "COMPOSITE"]
    value: str


class DownloadRef(View):
    resource_id: int
    version: int
    href: str


class Resource(View):
    id: int
    project_id: int
    name: TextValue
    media_type: str
    size_bytes: int
    version: int
    entity_version: int
    status: Literal["active", "archived"]
    created_by: ActorDisplay
    uploader: ActorDisplay
    updated_at: str
    checksum: Checksum | None
    download_ref: DownloadRef
    comment_count: int
    comments_href: str


class Collection(View, Generic[T]):
    items: list[T]
    next_cursor: str | None
    has_more: bool
    href: str


class ContextProject(SharedProjectSummary):
    background: TextValue
    goals: TextValue


class ContextSections(View):
    tasks: Collection[Task]
    subprojects: Collection[SharedProjectSummary]
    members: Collection[Member]
    prs: Collection[PR]
    resources: Collection[Resource]
    decisions: Collection[ContextItem]
    open_questions: Collection[ContextItem]
    comments: Collection[Comment]
    progress_history: Collection[ProgressEvent]
    activity: Collection[Activity]


class ContextManifest(View):
    schema_version: Literal["2.1-r3"]
    project: ContextProject
    context_version: str
    observed_at: str
    sections: ContextSections
    import_mode: Literal["read_only_context"]


class ContextPage(View):
    schema_version: Literal["2.1-r3"]
    project_id: int
    context_version: str
    section: str
    items: list[
        Task
        | SharedProjectSummary
        | Member
        | PR
        | Resource
        | ContextItem
        | Comment
        | ProgressEvent
        | Activity
    ]
    next_cursor: str | None
    has_more: bool


class TextChunk(View):
    project_id: int
    context_version: str
    kind: str
    object_id: int
    field: str
    resource_version: int | None
    offset: int
    text: str
    next_offset: int | None
    complete: bool


class Receipt(View):
    receipt_id: int
    project_id: int
    local_import_id: str
    context_version: str
    imported_at: str


class FilterEcho(View):
    category_id: str | None
    status: str
    progress_status: str | None
    blocked: bool | None
    needs_pr_review: bool | None
    mentioned_me: bool | None
    created_by_me: bool | None
    q: str | None
    view: str


class GroupEntry(View):
    category: CategoryRef | None
    project: ProjectSummary
    self_matches: bool
    matching_subproject_count: int
    subprojects_href: str


class ProjectList(View):
    team_id: int
    filters: FilterEcho
    observed_at: str
    projects: Page[GroupEntry]


class CategoryAggregate(View):
    category: CategoryRef | None
    total: int
    roots: int
    subprojects: int


class PRTotals(PRCounts):
    open_reviewing_me: int


class CommentTotals(View):
    total: int
    mentioning_me: int


class TeamAggregates(View):
    total_visible_projects: int
    root_projects: int
    subprojects: int
    created_by_me: int
    by_category: list[CategoryAggregate]
    by_progress_status: dict[str, int]
    by_lifecycle: dict[str, int]
    tasks: TaskCounts
    prs: PRTotals
    comments: CommentTotals
    open_questions: int


class TeamDashboard(View):
    team_id: int
    scope: Literal["team"]
    filters: FilterEcho
    observed_at: str
    aggregates: TeamAggregates
    projects: Page[GroupEntry]
    recent_activity: Page[Activity]


class SignedRequest(View):
    url: str
    method: Literal["GET", "PUT", "POST"]
    headers: dict[str, str]
    expires_at: str


class MultipartLinks(View):
    part_authorization_href: str
    complete_href: str


class UploadAuthorization(View):
    upload_id: int
    version: int
    state: str
    mode: Literal["single_put", "multipart"]
    single_put: SignedRequest | None
    multipart: MultipartLinks | None
    expires_at: str | None


class UploadState(View):
    upload_id: int
    client_upload_id: str
    state: str
    version: int
    declared_size: int
    verified_size: int | None
    verified_parts: int
    manifest_hash: str | None
    checksum: Checksum | None
    resource_id: int | None
    resource_version: int | None


class CompletionPart(View):
    part_number: int
    etag: str
    checksum: Checksum | None


class UploadCompletion(View):
    upload: UploadState
    action: Literal["continue_verification", "complete_s3", "done"]
    manifest: Page[CompletionPart] | None
    manifest_hash: str | None
    request: SignedRequest | None


class AuthorizedPart(View):
    part_number: int
    request: SignedRequest


class PartAuthorizationPage(View):
    upload_id: int
    items: list[AuthorizedPart]
    next_cursor: str | None
    has_more: bool


class DownloadAuthorization(View):
    resource_id: int
    version: int
    request: SignedRequest


class ConversionCounts(View):
    nodes: int
    tasks: int
    members: int
    resources: int
    verified_resources: int
    prepared_items: int


class ConversionSession(View):
    id: int
    client_conversion_id: str
    team_id: int
    mode: Literal["root", "subproject"]
    existing_parent_id: int | None
    status: str
    version: int
    plan_digest: str | None
    counts: ConversionCounts
    next_prepare_cursor: str | None
    committed_project_id: int | None
    created_at: str
    updated_at: str
    expires_at: str | None


class ConversionItemResult(View):
    id: int
    client_item_id: str
    node_key: str
    kind: str
    session_version: int


class PreparationResult(View):
    session: ConversionSession
    prepared: int
    next_cursor: str | None


class SyncResult(View):
    state: Literal["running", "completed"]
    continuation: str | None
    updated_prs: int
    project_version: int


class Operation(View):
    idempotency_replayed: bool
    committed_version: int | None


class Warning(View):
    type: Literal["possible_secret", "validator_unavailable"]
    message: str


class Mutation(View, Generic[T]):
    data: T
    operation: Operation
    warnings: list[Warning]
