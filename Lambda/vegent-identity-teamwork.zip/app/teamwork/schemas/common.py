import unicodedata
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

ID = Annotated[int, Field(strict=True, gt=0, le=2**53 - 1)]
PathID = Annotated[int, Field(gt=0, le=2**53 - 1)]
Positive = Annotated[int, Field(strict=True, gt=0)]
ProgressStatus = Literal[
    "not_started", "in_progress", "blocked", "in_review", "completed", "on_hold"
]
TaskState = Literal["todo", "in_progress", "blocked", "done"]


class DTO(BaseModel):
    model_config = ConfigDict(extra="forbid")

    @model_validator(mode="before")
    @classmethod
    def normalize(cls, values):
        if isinstance(values, dict):
            result = {}
            for key, value in values.items():
                if isinstance(value, str):
                    if any(0xD800 <= ord(c) <= 0xDFFF for c in value):
                        raise ValueError("Invalid Unicode scalar")
                    value = unicodedata.normalize(
                        "NFC", value.replace("\r\n", "\n").replace("\r", "\n")
                    )
                result[key] = value
            return result
        return values


class PageQuery(DTO):
    limit: Positive = 50
    cursor: str | None = None


class LifecycleBody(DTO):
    confirm: Literal[True] | None = None
    reason: str | None = None


class CancelBody(DTO):
    reason: str | None = None


class Empty(DTO):
    pass
