from .common import DTO, ID, TaskState


class TaskCreate(DTO):
    title: str
    description: str
    assignee_user_id: ID | None = None


class TaskPatch(DTO):
    title: str | None = None
    description: str | None = None
    driver_user_id: ID | None = None
    assignee_user_id: ID | None = None


class TaskStatus(DTO):
    status: TaskState
