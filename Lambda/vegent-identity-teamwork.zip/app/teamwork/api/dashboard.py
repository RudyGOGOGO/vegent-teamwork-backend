from typing import Annotated

from fastapi import APIRouter, Depends, Request

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.responses import Activity, Page, ProjectList, TeamDashboard

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/projects",
    response_model=ProjectList,
    status_code=200,
    operation_id="E18",
    openapi_extra={
        "parameters": [
            {
                "name": "blocked",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "category_id",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "created_by_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "mentioned_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "needs_pr_review",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "progress_status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "q",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "view",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e18(
    team_id: ID, request: Request, actor: Annotated[Actor, Depends(get_current_user)]
):
    return execution.read("E18", actor, request, ProjectList, team_id=team_id)


@router.get(
    "/api/teams/{team_id}/dashboard",
    response_model=TeamDashboard,
    status_code=200,
    operation_id="E19",
    openapi_extra={
        "parameters": [
            {
                "name": "activity_cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "blocked",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "category_id",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "created_by_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "mentioned_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "needs_pr_review",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "progress_status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "q",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "view",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e19(
    team_id: ID, request: Request, actor: Annotated[Actor, Depends(get_current_user)]
):
    return execution.read("E19", actor, request, TeamDashboard, team_id=team_id)


@router.get(
    "/api/teams/{team_id}/dashboard/activity",
    response_model=Page[Activity],
    status_code=200,
    operation_id="E57",
    openapi_extra={
        "parameters": [
            {
                "name": "blocked",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "category_id",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "created_by_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "mentioned_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "needs_pr_review",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "progress_status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "q",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "view",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e57(
    team_id: ID, request: Request, actor: Annotated[Actor, Depends(get_current_user)]
):
    return execution.read("E57", actor, request, Page[Activity], team_id=team_id)


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/activity",
    response_model=Page[Activity],
    status_code=200,
    operation_id="E63",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e63(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E63", actor, request, Page[Activity], team_id=team_id, project_id=project_id
    )
