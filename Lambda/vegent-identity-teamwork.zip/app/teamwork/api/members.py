from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.membership import MemberAdd, OwnerTransfer
from app.teamwork.schemas.responses import Member, Mutation, Page, ProjectDetail

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/members",
    response_model=Page[Member],
    status_code=200,
    operation_id="E02",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "search",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "user_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e02(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E02", actor, request, Page[Member], team_id=team_id, project_id=project_id
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/members",
    response_model=Mutation[Member],
    status_code=201,
    operation_id="E03",
)
def e03(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: MemberAdd,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E03",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Member],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.delete(
    "/api/teams/{team_id}/projects/{project_id}/members/{project_member_id}",
    response_model=None,
    status_code=204,
    operation_id="E04",
)
def e04(
    team_id: ID,
    project_id: ID,
    project_member_id: ID,
    request: Request,
    response: Response,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E04",
        actor,
        request,
        response,
        None,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        project_id=project_id,
        project_member_id=project_member_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/ownership-transfer",
    response_model=Mutation[ProjectDetail],
    status_code=200,
    operation_id="E05",
)
def e05(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: OwnerTransfer,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E05",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ProjectDetail],
        200,
        team_id=team_id,
        project_id=project_id,
    )
