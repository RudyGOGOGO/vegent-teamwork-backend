from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import Empty, LifecycleBody
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.project import ChildCreate, ProjectCreate, ProjectPatch
from app.teamwork.schemas.responses import (
    Mutation,
    Page,
    ProjectDetail,
    ProjectSummary,
)

router = APIRouter(tags=["Vegent Team Work"])


@router.post(
    "/api/teams/{team_id}/projects",
    response_model=Mutation[ProjectDetail],
    status_code=201,
    operation_id="E20",
)
def e20(
    team_id: ID,
    request: Request,
    response: Response,
    body: ProjectCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E20",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[ProjectDetail],
        201,
        team_id=team_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}",
    response_model=ProjectDetail,
    status_code=200,
    operation_id="E25",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e25(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E25", actor, request, ProjectDetail, team_id=team_id, project_id=project_id
    )


@router.put(
    "/api/teams/{team_id}/projects/{project_id}",
    response_model=Mutation[ProjectDetail],
    status_code=200,
    operation_id="E26",
)
def e26(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: ProjectPatch,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E26",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ProjectDetail],
        200,
        team_id=team_id,
        project_id=project_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/subprojects",
    response_model=Mutation[ProjectDetail],
    status_code=201,
    operation_id="E27",
)
def e27(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: ChildCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E27",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ProjectDetail],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/subprojects",
    response_model=Page[ProjectSummary],
    status_code=200,
    operation_id="E28",
    openapi_extra={
        "parameters": [
            {
                "name": "blocked",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "category_id",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "created_by_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "mentioned_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "needs_pr_review",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "progress_status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "q",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "view",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e28(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E28",
        actor,
        request,
        Page[ProjectSummary],
        team_id=team_id,
        project_id=project_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/archive",
    response_model=Mutation[ProjectDetail],
    status_code=200,
    operation_id="E29",
)
def e29(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E29",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ProjectDetail],
        200,
        team_id=team_id,
        project_id=project_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/unarchive",
    response_model=Mutation[ProjectDetail],
    status_code=200,
    operation_id="E30",
)
def e30(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E30",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ProjectDetail],
        200,
        team_id=team_id,
        project_id=project_id,
    )


@router.delete(
    "/api/teams/{team_id}/projects/{project_id}",
    response_model=None,
    status_code=204,
    operation_id="E31",
)
def e31(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: LifecycleBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E31",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        project_id=project_id,
    )
