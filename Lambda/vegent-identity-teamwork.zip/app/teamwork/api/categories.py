from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.category import CategoryCreate, CategoryPatch
from app.teamwork.schemas.common import LifecycleBody
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.responses import Category, Mutation, Page

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/categories",
    response_model=Page[Category],
    status_code=200,
    operation_id="E21",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e21(
    team_id: ID, request: Request, actor: Annotated[Actor, Depends(get_current_user)]
):
    return execution.read("E21", actor, request, Page[Category], team_id=team_id)


@router.post(
    "/api/teams/{team_id}/categories",
    response_model=Mutation[Category],
    status_code=201,
    operation_id="E22",
)
def e22(
    team_id: ID,
    request: Request,
    response: Response,
    body: CategoryCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E22",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[Category],
        201,
        team_id=team_id,
    )


@router.put(
    "/api/teams/{team_id}/categories/{category_id}",
    response_model=Mutation[Category],
    status_code=200,
    operation_id="E23",
)
def e23(
    team_id: ID,
    category_id: ID,
    request: Request,
    response: Response,
    body: CategoryPatch,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E23",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Category],
        200,
        team_id=team_id,
        category_id=category_id,
    )


@router.delete(
    "/api/teams/{team_id}/categories/{category_id}",
    response_model=None,
    status_code=204,
    operation_id="E24",
)
def e24(
    team_id: ID,
    category_id: ID,
    request: Request,
    response: Response,
    body: LifecycleBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E24",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        category_id=category_id,
    )
