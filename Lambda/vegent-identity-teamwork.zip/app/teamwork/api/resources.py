from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import CancelBody, Empty, LifecycleBody
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.responses import (
    DownloadAuthorization,
    Mutation,
    Page,
    PartAuthorizationPage,
    Resource,
    UploadAuthorization,
    UploadCompletion,
    UploadState,
)
from app.teamwork.schemas.upload import (
    DownloadCreate,
    PartAuthorization,
    UploadComplete,
    UploadCreate,
)

router = APIRouter(tags=["Vegent Team Work"])


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/resources/{resource_id}/download-authorizations",
    response_model=Mutation[DownloadAuthorization],
    status_code=200,
    operation_id="E17",
)
def e17(
    team_id: ID,
    project_id: ID,
    resource_id: ID,
    request: Request,
    response: Response,
    body: DownloadCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E17",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[DownloadAuthorization],
        200,
        team_id=team_id,
        project_id=project_id,
        resource_id=resource_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/resources",
    response_model=Page[Resource],
    status_code=200,
    operation_id="E43",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e43(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E43", actor, request, Page[Resource], team_id=team_id, project_id=project_id
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/resource-upload-authorizations",
    response_model=Mutation[UploadAuthorization],
    status_code=201,
    operation_id="E44",
)
def e44(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: UploadCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E44",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[UploadAuthorization],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.get(
    "/api/teams/{team_id}/uploads/{upload_id}",
    response_model=UploadState,
    status_code=200,
    operation_id="E45",
)
def e45(
    team_id: ID,
    upload_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E45", actor, request, UploadState, team_id=team_id, upload_id=upload_id
    )


@router.post(
    "/api/teams/{team_id}/uploads/{upload_id}/part-authorizations",
    response_model=Mutation[PartAuthorizationPage],
    status_code=200,
    operation_id="E46",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e46(
    team_id: ID,
    upload_id: ID,
    request: Request,
    response: Response,
    body: PartAuthorization,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E46",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[PartAuthorizationPage],
        200,
        team_id=team_id,
        upload_id=upload_id,
    )


@router.post(
    "/api/teams/{team_id}/uploads/{upload_id}/complete",
    response_model=Mutation[UploadCompletion],
    status_code=200,
    operation_id="E47",
)
def e47(
    team_id: ID,
    upload_id: ID,
    request: Request,
    response: Response,
    body: UploadComplete,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E47",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[UploadCompletion],
        200,
        team_id=team_id,
        upload_id=upload_id,
    )


@router.post(
    "/api/teams/{team_id}/uploads/{upload_id}/cancel",
    response_model=Mutation[UploadState],
    status_code=200,
    operation_id="E48",
)
def e48(
    team_id: ID,
    upload_id: ID,
    request: Request,
    response: Response,
    body: CancelBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E48",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[UploadState],
        200,
        team_id=team_id,
        upload_id=upload_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/resources/{resource_id}/archive",
    response_model=Mutation[Resource],
    status_code=200,
    operation_id="E49",
)
def e49(
    team_id: ID,
    project_id: ID,
    resource_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E49",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Resource],
        200,
        team_id=team_id,
        project_id=project_id,
        resource_id=resource_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/resources/{resource_id}/unarchive",
    response_model=Mutation[Resource],
    status_code=200,
    operation_id="E50",
)
def e50(
    team_id: ID,
    project_id: ID,
    resource_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E50",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Resource],
        200,
        team_id=team_id,
        project_id=project_id,
        resource_id=resource_id,
    )


@router.delete(
    "/api/teams/{team_id}/projects/{project_id}/resources/{resource_id}",
    response_model=None,
    status_code=204,
    operation_id="E51",
)
def e51(
    team_id: ID,
    project_id: ID,
    resource_id: ID,
    request: Request,
    response: Response,
    body: LifecycleBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E51",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        project_id=project_id,
        resource_id=resource_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/resources/{resource_id}/versions",
    response_model=Page[Resource],
    status_code=200,
    operation_id="E52",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e52(
    team_id: ID,
    project_id: ID,
    resource_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E52",
        actor,
        request,
        Page[Resource],
        team_id=team_id,
        project_id=project_id,
        resource_id=resource_id,
    )
