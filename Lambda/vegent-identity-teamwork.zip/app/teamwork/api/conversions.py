from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import CancelBody, Empty
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.conversion import ConversionCreate, ConversionItem
from app.teamwork.schemas.responses import (
    ConversionItemResult,
    ConversionSession,
    Mutation,
    PreparationResult,
    ProjectDetail,
    UploadAuthorization,
)
from app.teamwork.schemas.upload import UploadCreate

router = APIRouter(tags=["Vegent Team Work"])


@router.post(
    "/api/teams/{team_id}/conversions",
    response_model=Mutation[ConversionSession],
    status_code=201,
    operation_id="E13",
)
def e13(
    team_id: ID,
    request: Request,
    response: Response,
    body: ConversionCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E13",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[ConversionSession],
        201,
        team_id=team_id,
    )


@router.get(
    "/api/teams/{team_id}/conversions/{conversion_id}",
    response_model=ConversionSession,
    status_code=200,
    operation_id="E14",
)
def e14(
    team_id: ID,
    conversion_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E14",
        actor,
        request,
        ConversionSession,
        team_id=team_id,
        conversion_id=conversion_id,
    )


@router.post(
    "/api/teams/{team_id}/conversions/{conversion_id}/items/{item_id}/upload-authorizations",
    response_model=Mutation[UploadAuthorization],
    status_code=201,
    operation_id="E15",
)
def e15(
    team_id: ID,
    conversion_id: ID,
    item_id: ID,
    request: Request,
    response: Response,
    body: UploadCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E15",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[UploadAuthorization],
        201,
        team_id=team_id,
        conversion_id=conversion_id,
        item_id=item_id,
    )


@router.post(
    "/api/teams/{team_id}/conversions/{conversion_id}/commit",
    response_model=Mutation[ProjectDetail],
    status_code=201,
    operation_id="E16",
)
def e16(
    team_id: ID,
    conversion_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E16",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ProjectDetail],
        201,
        team_id=team_id,
        conversion_id=conversion_id,
    )


@router.post(
    "/api/teams/{team_id}/conversions/{conversion_id}/items",
    response_model=Mutation[ConversionItemResult],
    status_code=201,
    operation_id="E59",
)
def e59(
    team_id: ID,
    conversion_id: ID,
    request: Request,
    response: Response,
    body: ConversionItem,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E59",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ConversionItemResult],
        201,
        team_id=team_id,
        conversion_id=conversion_id,
    )


@router.post(
    "/api/teams/{team_id}/conversions/{conversion_id}/seal",
    response_model=Mutation[ConversionSession],
    status_code=200,
    operation_id="E60",
)
def e60(
    team_id: ID,
    conversion_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E60",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ConversionSession],
        200,
        team_id=team_id,
        conversion_id=conversion_id,
    )


@router.post(
    "/api/teams/{team_id}/conversions/{conversion_id}/prepare",
    response_model=Mutation[PreparationResult],
    status_code=200,
    operation_id="E61",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e61(
    team_id: ID,
    conversion_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E61",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[PreparationResult],
        200,
        team_id=team_id,
        conversion_id=conversion_id,
    )


@router.post(
    "/api/teams/{team_id}/conversions/{conversion_id}/cancel",
    response_model=Mutation[ConversionSession],
    status_code=200,
    operation_id="E62",
)
def e62(
    team_id: ID,
    conversion_id: ID,
    request: Request,
    response: Response,
    body: CancelBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E62",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ConversionSession],
        200,
        team_id=team_id,
        conversion_id=conversion_id,
    )
