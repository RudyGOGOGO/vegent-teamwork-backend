from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.context import ImportCreate
from app.teamwork.schemas.responses import (
    ContextManifest,
    ContextPage,
    Mutation,
    Receipt,
    TextChunk,
)

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/context",
    response_model=ContextManifest | ContextPage,
    status_code=200,
    operation_id="E11",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "section",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "If-Match",
                "in": "header",
                "required": False,
                "schema": {"type": "string"},
                "description": "Quoted shared Context hash; required for continuation.",
            },
            {
                "name": "If-None-Match",
                "in": "header",
                "required": False,
                "schema": {"type": "string"},
                "description": "Quoted Context hash on the initial manifest only.",
            },
        ]
    },
)
def e11(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E11",
        actor,
        request,
        ContextManifest | ContextPage,
        team_id=team_id,
        project_id=project_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/imports",
    response_model=Mutation[Receipt],
    status_code=201,
    operation_id="E12",
)
def e12(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: ImportCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E12",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[Receipt],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/context/text",
    response_model=TextChunk,
    status_code=200,
    operation_id="E58",
    openapi_extra={
        "parameters": [
            {
                "name": "field",
                "in": "query",
                "required": True,
                "schema": {"type": "string"},
            },
            {
                "name": "kind",
                "in": "query",
                "required": True,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "object_id",
                "in": "query",
                "required": True,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "offset",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 0},
            },
            {
                "name": "resource_version",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "If-Match",
                "in": "header",
                "required": True,
                "schema": {"type": "string"},
                "description": "Quoted shared Context hash; required for continuation.",
            },
        ]
    },
)
def e58(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E58", actor, request, TextChunk, team_id=team_id, project_id=project_id
    )
