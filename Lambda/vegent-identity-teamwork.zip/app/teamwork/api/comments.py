from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.comment import CommentCreate, CommentEdit
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.responses import Comment, Mutation, Page

router = APIRouter(tags=["Vegent Team Work"])


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/comments",
    response_model=Mutation[Comment],
    status_code=201,
    operation_id="E06",
)
def e06(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: CommentCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E06",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[Comment],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/comments",
    response_model=Page[Comment],
    status_code=200,
    operation_id="E07",
    openapi_extra={
        "parameters": [
            {
                "name": "author_user_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "mentioned_user_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "order",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "parent_comment_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "pr_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "resource_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "task_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e07(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E07", actor, request, Page[Comment], team_id=team_id, project_id=project_id
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/comments/{comment_id}",
    response_model=Comment,
    status_code=200,
    operation_id="E08",
)
def e08(
    team_id: ID,
    project_id: ID,
    comment_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E08",
        actor,
        request,
        Comment,
        team_id=team_id,
        project_id=project_id,
        comment_id=comment_id,
    )


@router.put(
    "/api/teams/{team_id}/projects/{project_id}/comments/{comment_id}",
    response_model=Mutation[Comment],
    status_code=200,
    operation_id="E09",
)
def e09(
    team_id: ID,
    project_id: ID,
    comment_id: ID,
    request: Request,
    response: Response,
    body: CommentEdit,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E09",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Comment],
        200,
        team_id=team_id,
        project_id=project_id,
        comment_id=comment_id,
    )


@router.delete(
    "/api/teams/{team_id}/projects/{project_id}/comments/{comment_id}",
    response_model=None,
    status_code=204,
    operation_id="E10",
)
def e10(
    team_id: ID,
    project_id: ID,
    comment_id: ID,
    request: Request,
    response: Response,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E10",
        actor,
        request,
        response,
        None,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        project_id=project_id,
        comment_id=comment_id,
    )
