import os
from types import SimpleNamespace

from fastapi import Response
from pydantic import TypeAdapter, ValidationError
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError, OperationalError

from app.models.user import User
from app.teamwork import warnings
from app.teamwork.errors import fail
from app.teamwork.http import mutation_response
from app.teamwork.models import (
    Category,
    ProjectContextItem,
    ProjectConversionItem,
    ProjectImportReceipt,
    ProjectTask,
)
from app.teamwork.operations import (
    OperationInput,
    begin_operation,
    complete_operation,
    expected_version,
    operation_view,
)
from app.teamwork.permissions import Action, require_project, require_team
from app.teamwork.projection import (
    context_item_view,
    member_views,
    project_projection,
    task_view,
)
from app.teamwork.schemas.common import PageQuery
from app.teamwork.schemas.project import ProjectFilters
from app.teamwork.services import (
    categories,
    comments,
    context,
    context_items,
    conversion,
    dashboard,
    members,
    progress,
    projects,
    prs,
    resources,
    storage,
    tasks,
)
from app.teamwork.services.common import iso
from app.teamwork.transactions import read_projection_session, write_session

FILTERS = {
    "category_id",
    "status",
    "progress_status",
    "blocked",
    "needs_pr_review",
    "mentioned_me",
    "created_by_me",
    "q",
    "view",
}
EXTRA = {
    "E02": {"search", "user_id"},
    "E07": {
        "task_id",
        "pr_id",
        "resource_id",
        "author_user_id",
        "mentioned_user_id",
        "parent_comment_id",
        "order",
    },
    "E11": {"section"},
    "E18": FILTERS,
    "E19": FILTERS | {"activity_cursor"},
    "E25": set(),
    "E28": FILTERS,
    "E32": {"status", "lifecycle_status", "assignee_user_id"},
    "E41": {"status", "reviewing_me", "sort"},
    "E42": {"continuation"},
    "E43": {"status"},
    "E46": set(),
    "E53": {"kind", "status"},
    "E57": FILTERS,
    "E58": {"kind", "object_id", "field", "resource_version", "offset"},
    "E61": set(),
}
BOOLS = {"blocked", "needs_pr_review", "mentioned_me", "created_by_me", "reviewing_me"}
IDS = {
    "user_id",
    "task_id",
    "pr_id",
    "resource_id",
    "author_user_id",
    "mentioned_user_id",
    "parent_comment_id",
    "assignee_user_id",
    "object_id",
    "resource_version",
}


def query_values(e, request):
    paged = {
        "E02",
        "E07",
        "E11",
        "E18",
        "E19",
        "E21",
        "E25",
        "E28",
        "E32",
        "E40",
        "E41",
        "E43",
        "E46",
        "E52",
        "E53",
        "E57",
        "E61",
        "E63",
    }
    allowed = (
        {"limit", "cursor"} if e in paged else {"limit"} if e == "E58" else set()
    ) | EXTRA.get(e, set())
    result = {}
    for key, value in request.query_params.multi_items():
        if key not in allowed or key in result:
            fail("VALIDATION_ERROR", 422)
        if key in BOOLS:
            if value not in ("true", "false"):
                fail("VALIDATION_ERROR", 422)
            value = value == "true"
        elif key in IDS or key in ("offset", "limit"):
            try:
                value = int(value)
            except ValueError:
                fail("VALIDATION_ERROR", 422)
            if (
                value < (0 if key == "offset" else 1)
                or key in IDS
                and value > 2**53 - 1
            ):
                fail("VALIDATION_ERROR", 422)
        result[key] = value
    return result


def enabled():
    if os.environ.get("VEGENT_TEAMWORK_ENABLED", "false").lower() != "true":
        fail("TEAMWORK_NOT_ENABLED", 503)


def validated(result_type, value):
    try:
        return TypeAdapter(result_type).validate_python(value).model_dump(mode="json")
    except (ValidationError, AttributeError):
        fail("INTERNAL_ERROR", 500)


def read(e, actor, request, result_type, **ids):
    enabled()
    q = query_values(e, request)
    tid = ids["team_id"]
    nid = ids.get("project_id")
    pq = PageQuery(limit=q.get("limit", 50), cursor=q.get("cursor"))
    with read_projection_session() as db:
        if e == "E02":
            result = members.list_members(
                actor,
                tid,
                nid,
                SimpleNamespace(
                    **{
                        "search": None,
                        "user_id": None,
                        **q,
                        "limit": pq.limit,
                        "cursor": pq.cursor,
                    }
                ),
                db=db,
            )
        elif e == "E07":
            result = comments.list_comments(actor, tid, nid, q, db=db)
        elif e == "E08":
            result = comments.get_comment(actor, tid, nid, ids["comment_id"], db=db)
        elif e == "E11":
            result = context.get_context(
                actor,
                tid,
                nid,
                q.get("section"),
                q.get("cursor"),
                request.headers.get("if-match"),
                pq,
                db=db,
            )
            etag = request.headers.get("if-none-match")
            if etag is not None:
                if q.get("section") or q.get("cursor"):
                    fail("INVALID_VERSION", 422)
                if context._hash(etag) == result["context_version"]:
                    return Response(
                        status_code=304, headers={"Cache-Control": "no-store"}
                    )
        elif e == "E14":
            result = conversion.get_conversion(actor, tid, ids["conversion_id"], db=db)
        elif e in ("E18", "E19", "E57"):
            filters = ProjectFilters(**{k: v for k, v in q.items() if k in FILTERS})
            result = (
                dashboard.list_projects(actor, tid, filters, pq, db=db)
                if e == "E18"
                else dashboard.team_dashboard(actor, tid, filters, pq, db=db)
                if e == "E19"
                else dashboard.list_activity(actor, tid, None, filters, pq, db=db)
            )
            if e == "E19" and q.get("activity_cursor"):
                result["recent_activity"] = dashboard.list_activity(
                    actor,
                    tid,
                    None,
                    filters,
                    PageQuery(limit=pq.limit, cursor=q["activity_cursor"]),
                    db=db,
                )
        elif e == "E21":
            result = categories.list_categories(actor, tid, pq, db=db)
        elif e == "E25":
            result = dashboard.project_detail(actor, tid, nid, pq, db=db)
        elif e == "E28":
            result = dashboard.list_subprojects(
                actor, tid, nid, {k: v for k, v in q.items() if k in FILTERS}, pq, db=db
            )
        elif e == "E32":
            result = tasks.list_tasks(actor, tid, nid, q, db=db)
        elif e == "E40":
            result = progress.list_progress_events(actor, tid, nid, pq, db=db)
        elif e == "E41":
            result = prs.list_prs(actor, tid, nid, q, db=db)
        elif e == "E43":
            result = resources.list_resources(actor, tid, nid, q, db=db)
        elif e == "E45":
            result = storage.get_upload(actor, tid, ids["upload_id"], db=db)
        elif e == "E52":
            result = resources.list_versions(
                actor, tid, nid, ids["resource_id"], pq, db=db
            )
        elif e == "E53":
            result = context_items.list_items(actor, tid, nid, q, db=db)
        elif e == "E58":
            if not {"kind", "object_id", "field"} <= q.keys():
                fail("VALIDATION_ERROR", 422)
            result = context.read_text_fragment(
                actor,
                tid,
                nid,
                {
                    k: v
                    for k, v in q.items()
                    if k in ("kind", "object_id", "field", "resource_version")
                },
                q.get("offset", 0),
                pq.limit,
                request.headers.get("if-match"),
                db=db,
            )
        elif e == "E63":
            result = dashboard.list_activity(actor, tid, nid, {}, pq, db=db)
        else:
            raise RuntimeError("Unbound read endpoint")
        return validated(result_type, result)


def _action(e):
    if e in ("E03", "E04"):
        return Action.MANAGE_MEMBERS
    if e == "E05":
        return Action.TRANSFER_OWNERSHIP
    if e == "E12":
        return Action.IMPORT
    if e == "E26":
        return Action.EDIT_INFO
    if e == "E27":
        return Action.CREATE_SUBPROJECT
    if e in ("E29", "E30", "E31"):
        return {"E29": Action.ARCHIVE, "E30": Action.UNARCHIVE, "E31": Action.DELETE}[e]
    return Action.WRITE_WORK


def _authorize(e, actor, ids, *, db):
    tid = ids["team_id"]
    nid = ids.get("project_id")
    if nid is not None:
        return require_project(actor, tid, nid, _action(e), db=db)
    if ids.get("conversion_id") is not None:
        return conversion.own_session(
            actor,
            tid,
            ids["conversion_id"],
            db=db,
            write=e != "E14",
            allow_committed=e == "E16",
        )
    grant = require_team(actor, tid, db=db)
    if e in ("E23", "E24"):
        row = db.get(Category, ids["category_id"])
        if row is None or row.team_id != tid:
            fail("NOT_FOUND", 404)
        if row.created_by_user_id != actor.user_id:
            fail("FORBIDDEN", 403)
    return grant


def _reference(e, data, ids, status):
    kind = "none"
    entity_id = None
    v = None
    if data is not None:
        if e in ("E20", "E26", "E27", "E29", "E30", "E05", "E16"):
            kind = "project"
            entity_id = data["id"]
            v = data["version"]
        elif e in ("E22", "E23"):
            kind = "category"
            entity_id = data["id"]
            v = data["version"]
        elif e == "E03":
            kind = "member"
            entity_id = data["project_member_id"]
        elif e in ("E06", "E09"):
            kind = "comment"
            entity_id = data["id"]
            v = data["version"]
        elif e in ("E33", "E34", "E35", "E36", "E37"):
            kind = "task"
            entity_id = data["id"]
            v = data["version"]
        elif e == "E39":
            kind = "progress"
            entity_id = ids["project_id"]
            v = data["project_version"]
        elif e in ("E49", "E50"):
            kind = "resource"
            entity_id = data["id"]
            v = data["entity_version"]
        elif e in ("E54", "E55"):
            kind = "item"
            entity_id = data["id"]
            v = data["version"]
        elif e in ("E13", "E60", "E62"):
            kind = "session"
            entity_id = data["id"]
            v = data["version"]
        elif e == "E59":
            kind = "conversion_item"
            entity_id = data["id"]
            v = data["session_version"]
        elif e == "E61":
            kind = "preparation"
            entity_id = data["session"]["id"]
            v = data["session"]["version"]
        elif e == "E12":
            kind = "receipt"
            entity_id = data["receipt_id"]
    return {
        "kind": kind,
        "id": entity_id,
        "project_id": ids.get("project_id"),
        "version": v,
        "status": status,
        **({"prepared": data["prepared"]} if kind == "preparation" else {}),
    }


def _replay(actor, ref, ids, *, db):
    kind = ref["kind"]
    eid = ref["id"]
    tid = ids["team_id"]
    nid = ref.get("project_id") or ids.get("project_id")
    if kind == "none":
        return None
    if kind == "project":
        return dashboard.project_detail(actor, tid, eid, PageQuery(), db=db)
    if kind == "category":
        row = db.get(Category, eid)
        if row is None or row.deleted_at:
            fail("NOT_FOUND", 404)
        return categories.category_view(row, db=db)
    if kind in ("session", "preparation"):
        data = conversion.get_conversion(actor, tid, eid, db=db)
        return (
            data
            if kind == "session"
            else {
                "session": data,
                "prepared": ref["prepared"],
                "next_cursor": data["next_prepare_cursor"],
            }
        )
    if kind == "conversion_item":
        row = db.get(ProjectConversionItem, eid)
        session = conversion.get_conversion(actor, tid, ids["conversion_id"], db=db)
        return {
            "id": row.id,
            "client_item_id": row.client_item_id,
            "node_key": row.node_key,
            "kind": row.kind,
            "session_version": session["version"],
        }
    grant = require_project(actor, tid, nid, db=db)
    projection = project_projection(grant, db=db)
    if kind == "member":
        result = next(
            (r for r in member_views(grant, db=db) if r["project_member_id"] == eid),
            None,
        )
        if result is None:
            fail("NOT_FOUND", 404)
        return {k: v for k, v in result.items() if k != "_cursor_key"}
    if kind == "comment":
        return comments.get_comment(actor, tid, nid, eid, db=db)
    if kind == "task":
        row = db.get(ProjectTask, eid)
        if row is None or row.lifecycle_status == "deleted":
            fail("NOT_FOUND", 404)
        return task_view(row, projection, db=db)
    if kind == "progress":
        return projection.data["progress"]
    if kind == "resource":
        from app.teamwork.models import ProjectResource

        row = db.get(ProjectResource, eid)
        if row is None or row.status == "deleted":
            fail("NOT_FOUND", 404)
        return resources.resource_view(row, projection, db=db)
    if kind == "item":
        row = db.get(ProjectContextItem, eid)
        if row is None or row.deleted_at:
            fail("NOT_FOUND", 404)
        return context_item_view(row, projection, db=db)
    if kind == "receipt":
        row = db.get(ProjectImportReceipt, eid)
        return {
            "receipt_id": row.id,
            "project_id": row.project_id,
            "local_import_id": row.local_import_id,
            "context_version": row.context_version,
            "imported_at": iso(row.imported_at),
        }
    raise RuntimeError("Unbound replay reference")


def _call(e, actor, ids, body, v, op, q, *, db):
    t = ids["team_id"]
    n = ids.get("project_id")
    if e == "E03":
        return members.add_member(actor, t, n, body.user_id, v, op, db=db)
    if e == "E04":
        return members.remove_member(
            actor, t, n, ids["project_member_id"], v, op, db=db
        )
    if e == "E05":
        return members.transfer_owner(
            actor, t, n, body.new_creator_user_id, v, op, db=db
        )
    if e == "E06":
        return comments.create_comment(actor, t, n, body, op, db=db)
    if e == "E09":
        return comments.edit_comment(actor, t, n, ids["comment_id"], body, v, op, db=db)
    if e == "E10":
        return comments.delete_comment(actor, t, n, ids["comment_id"], v, op, db=db)
    if e == "E12":
        return context.record_import(actor, t, n, body, op, db=db)
    if e == "E13":
        return conversion.start_conversion(actor, t, body, op, db=db)
    if e == "E16":
        return conversion.commit_conversion(
            actor, t, ids["conversion_id"], v, op, db=db
        )
    if e == "E20":
        return projects.create_project(actor, t, body, op, db=db)
    if e == "E22":
        return categories.create_category(actor, t, body, op, db=db)
    if e == "E23":
        return categories.patch_category(
            actor, t, ids["category_id"], body, v, op, db=db
        )
    if e == "E24":
        return categories.retire_category(
            actor, t, ids["category_id"], body, v, op, db=db
        )
    if e == "E26":
        return projects.update_project(actor, t, n, body, v, op, db=db)
    if e == "E27":
        return projects.create_subproject(actor, t, n, body, v, op, db=db)
    if e in ("E29", "E30", "E31"):
        return projects.change_lifecycle(
            actor,
            t,
            n,
            {"E29": "archive", "E30": "unarchive", "E31": "delete"}[e],
            body,
            v,
            op,
            db=db,
        )
    if e == "E33":
        return tasks.create_task(actor, t, n, body, op, db=db)
    if e == "E34":
        return tasks.patch_task(actor, t, n, ids["task_id"], body, v, op, db=db)
    if e == "E35":
        return tasks.change_task_status(actor, t, n, ids["task_id"], body, v, op, db=db)
    if e in ("E36", "E37", "E38"):
        return tasks.change_task_lifecycle(
            actor,
            t,
            n,
            ids["task_id"],
            {"E36": "archive", "E37": "unarchive", "E38": "delete"}[e],
            body,
            v,
            op,
            db=db,
        )
    if e == "E39":
        return progress.update_progress(actor, t, n, body, v, op, db=db)
    if e in ("E49", "E50", "E51"):
        return resources.change_resource_lifecycle(
            actor,
            t,
            n,
            ids["resource_id"],
            {"E49": "archive", "E50": "unarchive", "E51": "delete"}[e],
            body,
            v,
            op,
            db=db,
        )
    if e == "E54":
        return context_items.create_item(actor, t, n, body, op, db=db)
    if e == "E55":
        return context_items.patch_item(actor, t, n, ids["item_id"], body, v, op, db=db)
    if e == "E56":
        return context_items.delete_item(
            actor, t, n, ids["item_id"], body, v, op, db=db
        )
    if e == "E59":
        return conversion.append_item(
            actor, t, ids["conversion_id"], body, v, op, db=db
        )
    if e == "E60":
        return conversion.seal_plan(actor, t, ids["conversion_id"], v, op, db=db)
    if e == "E61":
        return conversion.prepare_batch(
            actor, t, ids["conversion_id"], q.get("cursor"), v, op, db=db
        )
    if e == "E62":
        return conversion.cancel_conversion(
            actor, t, ids["conversion_id"], body.reason, v, op, db=db
        )
    raise RuntimeError("Unbound write endpoint")


def _preflight(e, actor, ids, body):
    targets = {actor.user_id}
    with read_projection_session() as db:
        # Authorize before parsing body mentions or discovering target User locks.
        if ids.get("project_id") is not None:
            grant = require_project(actor, ids["team_id"], ids["project_id"], db=db)
            targets.add(grant.root.creator_user_id)
        elif ids.get("conversion_id") is not None:
            session, team = conversion.own_session(
                actor, ids["team_id"], ids["conversion_id"], db=db
            )
            if session.existing_parent_id:
                targets.add(
                    require_project(
                        actor, ids["team_id"], session.existing_parent_id, db=db
                    ).root.creator_user_id
                )
            if e in ("E60", "E61", "E16"):
                statement = (
                    conversion.preparation_items(session.id, db=db)
                    if e == "E61"
                    else select(ProjectConversionItem).where(
                        ProjectConversionItem.conversion_id == session.id
                    )
                )
                for item in db.scalars(statement):
                    for field in ("user_id", "assignee_user_id"):
                        if type(item.payload.get(field)) is int:
                            targets.add(item.payload[field])
        else:
            require_team(actor, ids["team_id"], db=db)
        values = body.model_dump() if body else {}
        for name in (
            "user_id",
            "driver_user_id",
            "assignee_user_id",
            "new_creator_user_id",
        ):
            if type(values.get(name)) is int:
                targets.add(values[name])
        if e == "E59":
            payload = conversion._payload(session, body)
            for name in ("user_id", "assignee_user_id"):
                if type(payload.get(name)) is int:
                    targets.add(payload[name])
        if body and hasattr(body, "content"):
            from app.teamwork.mentions import parse_mentions

            targets.update(t.user_id for t in parse_mentions(body.content))
    return {value for value in targets if value is not None}


def write(e, actor, request, response, body, key, if_match, result_type, status, **ids):
    enabled()
    q = query_values(e, request)
    v = expected_version(if_match) if if_match else None
    if (
        e in ("E29", "E30", "E36", "E37", "E49", "E50", "E60", "E61", "E16")
        and body.model_fields_set
    ):
        fail("VALIDATION_ERROR", 422)
    op = OperationInput(
        key,
        request.method + " " + request.url.path,
        {
            "body": body.model_dump(mode="json", exclude_unset=True) if body else {},
            "query": q,
        },
        if_match,
    )
    if e in ("E15", "E17", "E42", "E44", "E46", "E47", "E48"):
        if e in ("E15", "E44"):
            target = storage.UploadTarget(
                ids["team_id"],
                node_id=ids.get("project_id"),
                session_id=ids.get("conversion_id"),
                item_id=ids.get("item_id"),
                expected_session_version=v,
            )
            data, operation = storage.authorize_upload(actor, target, body, op)
        elif e == "E17":
            data, operation = storage.authorize_download(
                actor,
                ids["team_id"],
                ids["project_id"],
                ids["resource_id"],
                body.version,
                op,
            )
        elif e == "E46":
            data, operation = storage.authorize_parts(
                actor,
                ids["team_id"],
                ids["upload_id"],
                body,
                v,
                op,
                cursor=q.get("cursor"),
            )
        elif e == "E47":
            data, operation = storage.complete_upload(
                actor, ids["team_id"], ids["upload_id"], body, v, op
            )
        elif e == "E48":
            data, operation = storage.cancel_upload(
                actor, ids["team_id"], ids["upload_id"], body.reason, v, op
            )
        else:
            data, operation = prs.sync_prs(
                actor,
                ids["team_id"],
                ids["project_id"],
                body,
                v,
                op,
                q.get("continuation"),
            )

        if operation["idempotency_replayed"] and status == 201:
            response.status_code = 200
        return validated(result_type, mutation_response(data, operation))
    for attempt in range(2):
        try:
            users = _preflight(e, actor, ids, body)
            with write_session() as db:
                db.info["teamwork_write"] = True
                db.info["actor_id"] = actor.user_id
                list(
                    db.scalars(
                        select(User)
                        .where(User.id.in_(sorted(users)))
                        .order_by(User.id)
                        .with_for_update()
                    )
                )
                grant = _authorize(e, actor, ids, db=db)
                if hasattr(grant, "root") and grant.root.creator_user_id not in users:
                    fail("STATE_CONFLICT", 409)
                state = begin_operation(actor, key, op, db=db)
                data = (
                    _replay(actor, state.row.response_ref, ids, db=db)
                    if state.replayed
                    else _call(e, actor, ids, body, v, op, q, db=db)
                )
                if not state.replayed:
                    complete_operation(state, _reference(e, data, ids, status), db=db)
                result = mutation_response(data, operation_view(state))
                if status != 204:
                    result = validated(result_type, result)
                replayed = state.replayed
            if status == 204:
                return Response(status_code=204)
            if replayed and status == 201:
                response.status_code = 200
            text = warnings.shared_text(
                body.model_dump(exclude_unset=True) if body else {}
            )
            if text:
                result["warnings"] = warnings.safe_discussion_warnings(text)
            return result
        except IntegrityError:
            fail("STATE_CONFLICT", 409)
        except OperationalError as exc:
            code = exc.orig.args[0] if getattr(exc.orig, "args", ()) else None
            if code in (1205, 1213) and attempt == 0:
                continue
            fail(
                "STATE_CONFLICT" if code in (1205, 1213) else "SERVICE_UNAVAILABLE",
                409 if code in (1205, 1213) else 503,
            )
