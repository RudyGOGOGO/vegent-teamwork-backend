from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.progress import ProgressPatch
from app.teamwork.schemas.responses import Mutation, Page, Progress, ProgressEvent

router = APIRouter(tags=["Vegent Team Work"])


@router.put(
    "/api/teams/{team_id}/projects/{project_id}/progress",
    response_model=Mutation[Progress],
    status_code=200,
    operation_id="E39",
)
def e39(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: ProgressPatch,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E39",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Progress],
        200,
        team_id=team_id,
        project_id=project_id,
    )


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/progress-events",
    response_model=Page[ProgressEvent],
    status_code=200,
    operation_id="E40",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
        ]
    },
)
def e40(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E40",
        actor,
        request,
        Page[ProgressEvent],
        team_id=team_id,
        project_id=project_id,
    )
