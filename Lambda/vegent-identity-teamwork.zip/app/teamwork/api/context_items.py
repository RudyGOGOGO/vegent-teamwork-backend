from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import LifecycleBody
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.context_item import ContextItemCreate, ContextItemPatch
from app.teamwork.schemas.responses import (
    ContextItem,
    Mutation,
    Page,
)

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/context-items",
    response_model=Page[ContextItem],
    status_code=200,
    operation_id="E53",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "kind",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e53(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E53", actor, request, Page[ContextItem], team_id=team_id, project_id=project_id
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/context-items",
    response_model=Mutation[ContextItem],
    status_code=201,
    operation_id="E54",
)
def e54(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: ContextItemCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E54",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[ContextItem],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.put(
    "/api/teams/{team_id}/projects/{project_id}/context-items/{item_id}",
    response_model=Mutation[ContextItem],
    status_code=200,
    operation_id="E55",
)
def e55(
    team_id: ID,
    project_id: ID,
    item_id: ID,
    request: Request,
    response: Response,
    body: ContextItemPatch,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E55",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[ContextItem],
        200,
        team_id=team_id,
        project_id=project_id,
        item_id=item_id,
    )


@router.delete(
    "/api/teams/{team_id}/projects/{project_id}/context-items/{item_id}",
    response_model=None,
    status_code=204,
    operation_id="E56",
)
def e56(
    team_id: ID,
    project_id: ID,
    item_id: ID,
    request: Request,
    response: Response,
    body: LifecycleBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E56",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        project_id=project_id,
        item_id=item_id,
    )
