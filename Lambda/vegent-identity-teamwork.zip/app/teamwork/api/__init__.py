from fastapi import APIRouter

from . import (
    categories,
    comments,
    context,
    context_items,
    conversions,
    dashboard,
    members,
    progress,
    projects,
    prs,
    resources,
    tasks,
)

router = APIRouter()
router.include_router(members.router)
router.include_router(comments.router)
router.include_router(context.router)
router.include_router(context_items.router)
router.include_router(conversions.router)
router.include_router(resources.router)
router.include_router(dashboard.router)
router.include_router(projects.router)
router.include_router(categories.router)
router.include_router(tasks.router)
router.include_router(progress.router)
router.include_router(prs.router)
