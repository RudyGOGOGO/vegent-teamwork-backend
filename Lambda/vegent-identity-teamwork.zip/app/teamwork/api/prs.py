from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.pr import PRSync
from app.teamwork.schemas.responses import PR, Mutation, Page, SyncResult

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/prs",
    response_model=Page[PR],
    status_code=200,
    operation_id="E41",
    openapi_extra={
        "parameters": [
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "reviewing_me",
                "in": "query",
                "required": False,
                "schema": {"type": "boolean"},
            },
            {
                "name": "sort",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e41(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E41", actor, request, Page[PR], team_id=team_id, project_id=project_id
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/prs/sync",
    response_model=Mutation[SyncResult],
    status_code=200,
    operation_id="E42",
    openapi_extra={
        "parameters": [
            {
                "name": "continuation",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            }
        ]
    },
)
def e42(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: PRSync,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E42",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[SyncResult],
        200,
        team_id=team_id,
        project_id=project_id,
    )
