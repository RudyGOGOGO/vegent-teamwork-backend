from typing import Annotated

from fastapi import APIRouter, Depends, Header, Request, Response

from app.core.security import get_current_user
from app.schemas.user import Actor
from app.teamwork.api import execution
from app.teamwork.schemas.common import Empty, LifecycleBody
from app.teamwork.schemas.common import PathID as ID
from app.teamwork.schemas.responses import Mutation, Page, Task
from app.teamwork.schemas.task import TaskCreate, TaskPatch, TaskStatus

router = APIRouter(tags=["Vegent Team Work"])


@router.get(
    "/api/teams/{team_id}/projects/{project_id}/tasks",
    response_model=Page[Task],
    status_code=200,
    operation_id="E32",
    openapi_extra={
        "parameters": [
            {
                "name": "assignee_user_id",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "cursor",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "lifecycle_status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
            {
                "name": "limit",
                "in": "query",
                "required": False,
                "schema": {"type": "integer", "minimum": 1},
            },
            {
                "name": "status",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
            },
        ]
    },
)
def e32(
    team_id: ID,
    project_id: ID,
    request: Request,
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.read(
        "E32", actor, request, Page[Task], team_id=team_id, project_id=project_id
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/tasks",
    response_model=Mutation[Task],
    status_code=201,
    operation_id="E33",
)
def e33(
    team_id: ID,
    project_id: ID,
    request: Request,
    response: Response,
    body: TaskCreate,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E33",
        actor,
        request,
        response,
        body,
        key,
        None,
        Mutation[Task],
        201,
        team_id=team_id,
        project_id=project_id,
    )


@router.put(
    "/api/teams/{team_id}/projects/{project_id}/tasks/{task_id}",
    response_model=Mutation[Task],
    status_code=200,
    operation_id="E34",
)
def e34(
    team_id: ID,
    project_id: ID,
    task_id: ID,
    request: Request,
    response: Response,
    body: TaskPatch,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E34",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Task],
        200,
        team_id=team_id,
        project_id=project_id,
        task_id=task_id,
    )


@router.put(
    "/api/teams/{team_id}/projects/{project_id}/tasks/{task_id}/status",
    response_model=Mutation[Task],
    status_code=200,
    operation_id="E35",
)
def e35(
    team_id: ID,
    project_id: ID,
    task_id: ID,
    request: Request,
    response: Response,
    body: TaskStatus,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E35",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Task],
        200,
        team_id=team_id,
        project_id=project_id,
        task_id=task_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/tasks/{task_id}/archive",
    response_model=Mutation[Task],
    status_code=200,
    operation_id="E36",
)
def e36(
    team_id: ID,
    project_id: ID,
    task_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E36",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Task],
        200,
        team_id=team_id,
        project_id=project_id,
        task_id=task_id,
    )


@router.post(
    "/api/teams/{team_id}/projects/{project_id}/tasks/{task_id}/unarchive",
    response_model=Mutation[Task],
    status_code=200,
    operation_id="E37",
)
def e37(
    team_id: ID,
    project_id: ID,
    task_id: ID,
    request: Request,
    response: Response,
    body: Empty,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E37",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        Mutation[Task],
        200,
        team_id=team_id,
        project_id=project_id,
        task_id=task_id,
    )


@router.delete(
    "/api/teams/{team_id}/projects/{project_id}/tasks/{task_id}",
    response_model=None,
    status_code=204,
    operation_id="E38",
)
def e38(
    team_id: ID,
    project_id: ID,
    task_id: ID,
    request: Request,
    response: Response,
    body: LifecycleBody,
    key: Annotated[str, Header(alias="Idempotency-Key")],
    if_match: Annotated[str, Header(alias="If-Match")],
    actor: Annotated[Actor, Depends(get_current_user)],
):
    return execution.write(
        "E38",
        actor,
        request,
        response,
        body,
        key,
        if_match,
        None,
        204,
        team_id=team_id,
        project_id=project_id,
        task_id=task_id,
    )
