import hmac
import secrets
from datetime import timedelta

from sqlalchemy import select

from app.core.security import (
    assert_current_actor,
    create_unusable_password_hash,
    get_password_hash,
    hash_proof,
    normalize_email,
    validate_password,
)
from app.models.team_member import TeamMember
from app.models.user import User
from app.schemas.auth import ServiceError
from app.services.auth import issue_session, revoke_user_sessions
from app.services.team_members import (
    active_member,
    lock_team,
    lock_users,
    transaction,
    utcnow,
    write_audit,
)


def authorize_unlock(actor, target, *, db):
    current = assert_current_actor(actor, db=db)
    if actor.user_id == target.id or not target.is_active:
        raise ServiceError("FORBIDDEN", 403)
    if current.role == "admin":
        return None
    if target.role == "admin":
        raise ServiceError("FORBIDDEN", 403)
    tids = db.scalars(
        select(TeamMember.team_id)
        .where(
            TeamMember.user_id == target.id,
            TeamMember.status == "active",
            TeamMember.invited_by_user_id == actor.user_id,
        )
        .order_by(TeamMember.team_id)
    ).all()
    eligible = []
    for tid in tids:
        team = lock_team(db, tid)
        membership = active_member(db, tid, actor.user_id)
        target_membership = active_member(db, tid, target.id)
        if (
            team.is_active
            and membership
            and membership.team_role == "team_admin"
            and target_membership
            and target_membership.invited_by_user_id == actor.user_id
        ):
            eligible.append(tid)
    if not eligible:
        raise ServiceError("FORBIDDEN", 403)
    return min(eligible)


@transaction
def unlock_user(actor, target_user_id, team_scope=None, *, db):
    rows = lock_users(db, actor.user_id, target_user_id)
    current = assert_current_actor(actor, db=db)
    target = rows.get(target_user_id)
    if not target:
        raise ServiceError(
            "NOT_FOUND" if current.role == "admin" else "FORBIDDEN",
            404 if current.role == "admin" else 403,
        )
    scope = authorize_unlock(actor, target, db=db)
    if team_scope is not None and scope != team_scope:
        raise ServiceError("FORBIDDEN", 403)
    token = secrets.token_urlsafe(32)
    target.password_hash = create_unusable_password_hash()
    target.needs_registration = True
    revoke_user_sessions(target, db=db)
    target.unlock_token_hash = hash_proof("unlock", token)
    target.unlock_expires_at = utcnow() + timedelta(hours=24)
    target.unlock_used_at = None
    from app.services.rate_limits import clear_login_failures

    clear_login_failures(target.email, db=db)
    write_audit(
        db,
        actor_user_id=actor.user_id,
        action="unlock_registration",
        team_id=scope,
        target_user_id=target.id,
    )
    return {
        "user_id": target.id,
        "needs_registration": True,
        "unlock_token": token,
        "expires_at": target.unlock_expires_at,
    }


@transaction
def complete_registration_after_unlock(email, new_password, unlock_token, *, db):
    email = normalize_email(email)
    validate_password(new_password)
    target = db.scalar(select(User).where(User.email == email).with_for_update())
    digest = hash_proof("unlock", unlock_token)
    if (
        not target
        or not target.is_active
        or not target.needs_registration
        or not target.unlock_token_hash
        or not hmac.compare_digest(target.unlock_token_hash, digest)
        or target.unlock_used_at
        or not target.unlock_expires_at
        or target.unlock_expires_at <= utcnow()
    ):
        raise ServiceError("INVALID_UNLOCK_TOKEN", 400)
    target.password_hash = get_password_hash(new_password)
    target.needs_registration = False
    target.token_version += 1
    target.unlock_used_at = utcnow()
    target.unlock_token_hash = None
    write_audit(
        db,
        actor_user_id=target.id,
        action="registration_completed",
        target_user_id=target.id,
    )
    return issue_session(target, db=db, now=utcnow())
