import functools
import re
import secrets
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError, OperationalError

from app.core.security import assert_current_actor, require_system_admin
from app.models.audit_log import AuditLog
from app.models.invitation import Invitation
from app.models.team import Team
from app.models.team_member import TeamMember
from app.models.user import User
from app.schemas.auth import ServiceError


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def transaction(fn):
    @functools.wraps(fn)
    def run(*args, db, **kwargs):
        for attempt in range(2):
            try:
                with db.begin():
                    result = fn(*args, db=db, **kwargs)
                    db.flush()
                    return result
            except IntegrityError:
                raise ServiceError("STATE_CONFLICT", 409) from None
            except OperationalError as exc:
                code = exc.orig.args[0] if getattr(exc.orig, "args", ()) else None
                if code in (1205, 1213):
                    if attempt == 0:
                        continue
                    raise ServiceError("STATE_CONFLICT", 409) from None
                raise ServiceError("SERVICE_UNAVAILABLE", 503) from None

    return run


def lock_users(db, *ids):
    rows = db.scalars(
        select(User)
        .where(User.id.in_(sorted(set(ids))))
        .order_by(User.id)
        .with_for_update()
    ).all()
    return {u.id: u for u in rows}


def lock_team(db, team_id):
    team = db.scalar(select(Team).where(Team.id == team_id).with_for_update())
    if not team:
        raise ServiceError("FORBIDDEN", 403)
    return team


def write_audit(
    db,
    *,
    actor_user_id,
    action,
    team_id=None,
    target_user_id=None,
    target_email=None,
    resource_type=None,
    resource_id=None,
    detail=None,
):
    if actor_user_id is None and action not in ("login_failed", "auth_rate_limited"):
        raise ValueError("Audit actor required")
    snapshots = dict(detail or {})
    for prefix, uid in (("actor", actor_user_id), ("target", target_user_id)):
        user = db.get(User, uid) if uid else None
        if user:
            snapshots.update(
                {prefix + "_name": user.display_name, prefix + "_email": user.email}
            )
    row = AuditLog(
        actor_user_id=actor_user_id,
        action=action,
        team_id=team_id,
        target_user_id=target_user_id,
        target_email=target_email,
        resource_type=resource_type,
        resource_id=resource_id,
        detail=snapshots,
    )
    db.add(row)
    return row


def active_member(db, team_id, user_id):
    return db.scalar(
        select(TeamMember).where(
            TeamMember.team_id == team_id,
            TeamMember.user_id == user_id,
            TeamMember.status == "active",
        )
    )


def admin_count(db, team_id, exclude=None):
    q = (
        select(func.count())
        .select_from(TeamMember)
        .join(User, User.id == TeamMember.user_id)
        .where(
            TeamMember.team_id == team_id,
            TeamMember.status == "active",
            TeamMember.team_role == "team_admin",
            User.is_active.is_(True),
        )
    )
    if exclude is not None:
        q = q.where(User.id != exclude)
    return db.scalar(q)


def user_view(user):
    return {
        k: getattr(user, k)
        for k in (
            "id",
            "user_name",
            "email",
            "display_name",
            "bio",
            "role",
            "auth_source",
            "is_active",
        )
    }


def team_view(db, team, actor):
    creator = db.get(User, team.created_by_user_id)
    result = {
        k: getattr(team, k)
        for k in (
            "id",
            "team_name",
            "slug",
            "description",
            "created_at",
            "updated_at",
            "is_active",
        )
    }
    result["created_by"] = {
        "user_id": creator.id,
        "display_name": creator.display_name,
        "email": creator.email,
    }
    result["member_count"] = db.scalar(
        select(func.count())
        .select_from(TeamMember)
        .join(User, User.id == TeamMember.user_id)
        .where(
            TeamMember.team_id == team.id,
            TeamMember.status == "active",
            User.is_active.is_(True),
        )
    )
    membership = active_member(db, team.id, actor.user_id)
    if (
        db.get(User, actor.user_id).role == "admin"
        or membership
        and membership.team_role == "team_admin"
    ):
        result["pending_invitation_count"] = db.scalar(
            select(func.count())
            .select_from(Invitation)
            .where(
                Invitation.team_id == team.id,
                Invitation.status == "pending",
                Invitation.expires_at > utcnow(),
            )
        )
    return result


def member_view(db, row):
    user = db.get(User, row.user_id)
    inviter = db.get(User, row.invited_by_user_id)
    return {
        "member_id": row.id,
        "user_id": user.id,
        "display_name": user.display_name,
        "email": user.email,
        "bio": user.bio,
        "team_role": row.team_role,
        "joined_at": row.joined_at,
        "invited_by_name": inviter.display_name,
        "invited_by_email": inviter.email,
        "status": row.status,
    }


def page_result(items, page, limit):
    return {
        "items": items[(page - 1) * limit : page * limit],
        "total": len(items),
        "page": page,
        "limit": limit,
    }


@transaction
def create_team(actor, team_name, description, *, db):
    require_system_admin(actor, db=db)
    if db.scalar(select(Team.id).where(Team.team_name == team_name)):
        raise ServiceError("DUPLICATE", 409)
    slug = re.sub("[^a-z0-9]+", "-", team_name.lower()).strip("-")[:80] or "team"
    if db.scalar(select(Team.id).where(Team.slug == slug)):
        slug += "-" + secrets.token_hex(6)
    team = Team(
        team_name=team_name,
        slug=slug,
        description=description,
        created_by_user_id=actor.user_id,
    )
    db.add(team)
    db.flush()
    write_audit(db, actor_user_id=actor.user_id, action="team_created", team_id=team.id)
    return team_view(db, team, actor)


@transaction
def list_teams(actor, page, limit, *, db):
    user = assert_current_actor(actor, db=db)
    q = select(Team).order_by(Team.created_at, Team.id)
    if user.role != "admin":
        q = q.join(TeamMember).where(
            TeamMember.user_id == user.id,
            TeamMember.status == "active",
            Team.is_active.is_(True),
        )
    return page_result([team_view(db, t, actor) for t in db.scalars(q)], page, limit)


@transaction
def get_team(actor, team_id, *, db):
    from app.services.team_permission import require_team_permission

    return team_view(db, require_team_permission(actor, team_id, "view", db=db), actor)


@transaction
def update_team(actor, team_id, changes, *, db):
    from app.services.team_permission import require_team_permission

    team = lock_team(db, team_id)
    require_team_permission(actor, team_id, "edit", db=db)
    old = team.team_name
    fields = changes.model_dump(exclude_unset=True)
    for key, value in fields.items():
        setattr(team, key, value)
    if fields:
        write_audit(
            db,
            actor_user_id=actor.user_id,
            action="team_renamed" if old != team.team_name else "team_updated",
            team_id=team_id,
            detail={"old_name": old, "new_name": team.team_name},
        )
    db.flush()
    return team_view(db, team, actor)


@transaction
def deactivate_team(actor, team_id, *, db):
    require_system_admin(actor, db=db)
    team = lock_team(db, team_id)
    if team.is_active:
        team.is_active = False
        write_audit(
            db, actor_user_id=actor.user_id, action="team_deactivated", team_id=team_id
        )
    db.flush()
    return team_view(db, team, actor)


@transaction
def list_members(actor, team_id, page, limit, *, db):
    from app.services.team_permission import require_team_permission

    require_team_permission(actor, team_id, "view_members", db=db)
    rows = db.scalars(
        select(TeamMember)
        .join(User, User.id == TeamMember.user_id)
        .where(
            TeamMember.team_id == team_id,
            TeamMember.status == "active",
            User.is_active.is_(True),
        )
        .order_by(TeamMember.joined_at, TeamMember.id)
    ).all()
    return page_result([member_view(db, x) for x in rows], page, limit)


@transaction
def list_member_history(actor, team_id, page, limit, *, db):
    from app.services.team_permission import require_team_permission

    require_team_permission(actor, team_id, "view_history", db=db)
    rows = db.scalars(
        select(AuditLog)
        .where(
            AuditLog.team_id == team_id,
            AuditLog.action.in_(
                ["member_removed", "role_changed", "invitation_revoked"]
            ),
        )
        .order_by(AuditLog.created_at.desc(), AuditLog.id.desc())
    )
    return page_result(
        [
            {
                "id": r.id,
                "action": r.action,
                "created_at": r.created_at,
                "detail": r.detail,
                **{
                    key: (r.detail or {}).get(key)
                    for key in (
                        "actor_name",
                        "actor_email",
                        "target_name",
                        "target_email",
                    )
                },
            }
            for r in rows
        ],
        page,
        limit,
    )


def mutate_member(actor, team_id, member_id, role, *, db):
    from app.services.team_permission import require_team_permission

    target_id = db.scalar(
        select(TeamMember.user_id).where(
            TeamMember.id == member_id, TeamMember.team_id == team_id
        )
    )
    if target_id:
        lock_users(db, actor.user_id, target_id)
    lock_team(db, team_id)
    require_team_permission(
        actor, team_id, "change_role" if role else "remove_member", db=db
    )
    row = db.scalar(
        select(TeamMember)
        .where(TeamMember.id == member_id, TeamMember.team_id == team_id)
        .with_for_update()
    )
    if not row:
        raise ServiceError("NOT_FOUND", 404)
    target = db.get(User, row.user_id)
    current = assert_current_actor(actor, db=db)
    if (
        row.user_id == actor.user_id
        or target.role == "admin"
        and (role is not None or current.role != "admin")
    ):
        raise ServiceError("FORBIDDEN", 403)
    if row.status != "active":
        if role:
            raise ServiceError("STATE_CONFLICT", 409)
        return
    if role == row.team_role:
        return member_view(db, row)
    if (
        row.team_role == "team_admin"
        and target.is_active
        and (role is None or role != "team_admin")
        and admin_count(db, team_id, exclude=row.user_id) == 0
    ):
        raise ServiceError("LAST_ADMIN", 409)
    if role is not None and not target.is_active:
        raise ServiceError("STATE_CONFLICT", 409)
    old = row.team_role
    if role:
        row.team_role = role
    else:
        row.status = "removed"
        row.removed_at = utcnow()
        row.removed_by_user_id = actor.user_id
    write_audit(
        db,
        actor_user_id=actor.user_id,
        action="role_changed" if role else "member_removed",
        team_id=team_id,
        target_user_id=row.user_id,
        detail={"member_id": row.id, "former_team_role": old, "new_team_role": role},
    )
    db.flush()
    return member_view(db, row) if role else None


@transaction
def change_team_role(actor, team_id, member_id, team_role, *, db):
    return mutate_member(actor, team_id, member_id, team_role, db=db)


def remove_member_in_transaction(actor, team_id, member_id, *, db, now=None):
    from app.teamwork.services.cascade import MembershipRemoval

    row = db.scalar(
        select(TeamMember).where(
            TeamMember.id == member_id, TeamMember.team_id == team_id
        )
    )
    was_active = row is not None and row.status == "active"
    mutate_member(actor, team_id, member_id, None, db=db)
    if was_active and row.status == "removed":
        return MembershipRemoval(actor, team_id, row.user_id, row.id, row.removed_at)
    return None


@transaction
def remove_member(actor, team_id, member_id, *, db):
    import os

    removal = remove_member_in_transaction(actor, team_id, member_id, db=db)
    if (
        removal is not None
        and os.environ.get("VEGENT_TEAMWORK_ENABLED", "false").lower() == "true"
    ):
        from app.teamwork.services.cascade import cascade_team_removal

        cascade_team_removal(removal, db=db)
    return None
