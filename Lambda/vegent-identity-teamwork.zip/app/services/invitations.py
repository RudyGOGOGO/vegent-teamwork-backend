import secrets
from datetime import timedelta

from sqlalchemy import select

from app.core.security import hash_proof, validate_verizon_email
from app.models.invitation import Invitation
from app.models.user import User
from app.schemas.auth import ServiceError
from app.services.team_members import (
    active_member,
    lock_team,
    page_result,
    transaction,
    utcnow,
    write_audit,
)
from app.services.team_permission import require_team_permission


def invitation_view(db, row):
    inviter = db.get(User, row.invited_by_user_id)
    claimant = db.get(User, row.claimed_user_id) if row.claimed_user_id else None
    result = {
        k: getattr(row, k)
        for k in (
            "team_id",
            "invitee_name",
            "invitee_email",
            "invitee_bio",
            "team_role",
            "status",
            "created_at",
            "expires_at",
            "claimed_at",
        )
    }
    if row.status == "pending" and row.expires_at <= utcnow():
        result["status"] = "expired"
    return {
        **result,
        "invitation_id": row.id,
        "invited_by_name": inviter.display_name,
        "invited_by_email": inviter.email,
        "claimed_user_name": claimant.display_name if claimant else None,
    }


def expire_pending_invitations(actor, team_id, now, *, db):
    rows = db.scalars(
        select(Invitation)
        .where(
            Invitation.team_id == team_id,
            Invitation.status == "pending",
            Invitation.expires_at <= now,
        )
        .with_for_update()
    ).all()
    for row in rows:
        row.status = "expired"
        write_audit(
            db,
            actor_user_id=actor.user_id,
            action="invitation_expired",
            team_id=team_id,
            resource_id=row.id,
        )
    db.flush()
    return len(rows)


@transaction
def create_invitation(
    actor,
    team_id,
    invitee_name,
    invitee_email,
    invitee_bio,
    team_role,
    invited_by_user_id,
    *,
    db,
):
    email = validate_verizon_email(invitee_email)
    team = lock_team(db, team_id)
    require_team_permission(actor, team_id, "invite", db=db)
    if actor.user_id != invited_by_user_id:
        raise ServiceError("FORBIDDEN", 403)
    expire_pending_invitations(actor, team_id, utcnow(), db=db)
    if db.scalar(
        select(Invitation.id).where(
            Invitation.team_id == team_id,
            Invitation.invitee_email == email,
            Invitation.status == "pending",
        )
    ):
        raise ServiceError("DUPLICATE", 409)
    if not team.is_active:
        raise ServiceError("FORBIDDEN", 403)
    user = db.scalar(select(User).where(User.email == email))
    if user and active_member(db, team_id, user.id):
        raise ServiceError("DUPLICATE", 409)
    token = secrets.token_urlsafe(32)
    row = Invitation(
        team_id=team_id,
        invitee_name=invitee_name,
        invitee_email=email,
        invitee_bio=invitee_bio,
        team_role=team_role,
        invited_by_user_id=actor.user_id,
        invite_token_hash=hash_proof("invite", token),
        expires_at=utcnow() + timedelta(days=30),
    )
    db.add(row)
    db.flush()
    write_audit(
        db,
        actor_user_id=actor.user_id,
        action="invitation_created",
        team_id=team_id,
        target_email=email,
        resource_id=row.id,
    )
    return invitation_view(db, row), token


@transaction
def list_invitations(actor, team_id, status, page, limit, *, db):
    require_team_permission(actor, team_id, "view_invitations", db=db)
    if status is not None and status not in (
        "pending",
        "expired",
        "claimed",
        "revoked",
    ):
        raise ServiceError("VALIDATION_ERROR", 422)
    items = [
        invitation_view(db, r)
        for r in db.scalars(
            select(Invitation)
            .where(Invitation.team_id == team_id)
            .order_by(Invitation.created_at, Invitation.id)
        )
    ]
    return page_result(
        [r for r in items if status is None or r["status"] == status], page, limit
    )


def mutate(actor, team_id, invitation_id, resend, *, db):
    team = lock_team(db, team_id)
    require_team_permission(actor, team_id, "resend" if resend else "revoke", db=db)
    row = db.scalar(
        select(Invitation)
        .where(Invitation.id == invitation_id, Invitation.team_id == team_id)
        .with_for_update()
    )
    if not row:
        raise ServiceError("NOT_FOUND", 404)
    if row.status != "pending" or row.expires_at <= utcnow():
        raise ServiceError("STATE_CONFLICT", 409)
    token = None
    if resend:
        if not team.is_active:
            raise ServiceError("FORBIDDEN", 403)
        token = secrets.token_urlsafe(32)
        row.invite_token_hash = hash_proof("invite", token)
        row.expires_at = utcnow() + timedelta(days=30)
    else:
        row.status = "revoked"
    write_audit(
        db,
        actor_user_id=actor.user_id,
        action="invitation_resent" if resend else "invitation_revoked",
        team_id=team_id,
        target_email=row.invitee_email,
        resource_id=row.id,
        detail={"target_name": row.invitee_name, "target_email": row.invitee_email},
    )
    db.flush()
    return (invitation_view(db, row), token) if resend else invitation_view(db, row)


@transaction
def revoke_invitation(actor, team_id, invitation_id, *, db):
    return mutate(actor, team_id, invitation_id, False, db=db)


@transaction
def resend_invitation(actor, team_id, invitation_id, *, db):
    return mutate(actor, team_id, invitation_id, True, db=db)
