import hashlib
import ipaddress
import json
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, select
from sqlalchemy.dialects.mysql import insert

from app.db.session import get_session_factory
from app.models.system_config import SystemConfig
from app.schemas.auth import ServiceError
from app.services.team_members import write_audit


def trusted_source_ip(event):
    try:
        return str(
            ipaddress.ip_address(event["requestContext"]["identity"]["sourceIp"])
        )
    except (KeyError, ValueError, TypeError):
        raise ServiceError("SERVICE_UNAVAILABLE", 503) from None


def key(kind, value):
    return "auth:" + kind + ":" + hashlib.sha256(value.encode()).hexdigest()


def locked_counter(db, name, now):
    db.execute(
        insert(SystemConfig)
        .values(
            config_key=name, config_value="{}", expires_at=now + timedelta(minutes=15)
        )
        .on_duplicate_key_update(config_key=name)
    )
    row = db.scalar(
        select(SystemConfig).where(SystemConfig.config_key == name).with_for_update()
    )
    return row, json.loads(row.config_value)


def admit_auth_attempt(email, source_ip, *, now, ip_already_admitted=False):
    timestamp = int(now.replace(tzinfo=timezone.utc).timestamp())
    denied = False
    with get_session_factory()() as db, db.begin():
        keys = [] if ip_already_admitted else [("i", source_ip, 100)]
        if email:
            keys.append(("e", email, 10))
        for kind, value, limit in keys:
            row, state = locked_counter(db, key(kind, value), now)
            if row.expires_at and row.expires_at <= now:
                state = {}
            if state.get("locked_until_epoch", 0) > timestamp:
                denied = True
                break
            if timestamp >= state.get("window_start_epoch", 0) + 60:
                state["window_start_epoch"] = timestamp
                state["request_count"] = 0
            if state.get("request_count", 0) >= limit:
                denied = True
                break
            state["request_count"] = state.get("request_count", 0) + 1
            row.config_value = json.dumps(state)
            row.expires_at = datetime.fromtimestamp(
                max(
                    state.get("window_start_epoch", timestamp) + 120,
                    state.get("locked_until_epoch", 0),
                    timestamp + 900 if kind == "e" else timestamp + 120,
                ),
                timezone.utc,
            ).replace(tzinfo=None)
        if denied:
            write_audit(
                db, actor_user_id=None, action="auth_rate_limited", target_email=email
            )
    if denied:
        raise ServiceError("RATE_LIMITED", 429)


def record_login_failure(email, source_ip, *, now):
    timestamp = int(now.replace(tzinfo=timezone.utc).timestamp())
    with get_session_factory()() as db, db.begin():
        row, state = locked_counter(db, key("e", email), now)
        if row.expires_at and row.expires_at <= now:
            state = {}
        state["failure_count"] = state.get("failure_count", 0) + 1
        if state["failure_count"] >= 5:
            state["locked_until_epoch"] = timestamp + 900
        row.config_value = json.dumps(state)
        row.expires_at = now + timedelta(seconds=900)
        write_audit(db, actor_user_id=None, action="login_failed", target_email=email)


def clear_login_failures(email, *, db):
    row = db.scalar(
        select(SystemConfig)
        .where(SystemConfig.config_key == key("e", email))
        .with_for_update()
    )
    if row:
        state = json.loads(row.config_value)
        state["failure_count"] = 0
        state["locked_until_epoch"] = 0
        row.config_value = json.dumps(state)


def cleanup_expired_counters(*, now, limit=100):
    with get_session_factory()() as db, db.begin():
        ids = db.scalars(
            select(SystemConfig.id)
            .where(
                SystemConfig.config_key.like("auth:%"), SystemConfig.expires_at < now
            )
            .order_by(SystemConfig.expires_at, SystemConfig.id)
            .limit(min(max(limit, 0), 100))
            .with_for_update(skip_locked=True)
        ).all()
        if ids:
            db.execute(delete(SystemConfig).where(SystemConfig.id.in_(ids)))
        return len(ids)
