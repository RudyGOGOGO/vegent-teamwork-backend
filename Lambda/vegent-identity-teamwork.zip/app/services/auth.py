import secrets
from datetime import timedelta, timezone

from sqlalchemy import func, select, update

from app.core.security import (
    assert_current_actor,
    create_access_token,
    dummy_password_hash,
    get_bcrypt_cost,
    hash_proof,
    normalize_email,
    require_system_admin,
    verify_password,
)
from app.models.invitation import Invitation
from app.models.refresh_token import RefreshToken
from app.models.system_config import SystemConfig
from app.models.team import Team
from app.models.team_member import TeamMember
from app.models.user import User
from app.schemas.auth import ServiceError
from app.services.team_members import (
    admin_count,
    lock_team,
    lock_users,
    page_result,
    transaction,
    user_view,
    utcnow,
    write_audit,
)


def issue_session(user, *, db, now):
    token = secrets.token_urlsafe(32)
    db.add(
        RefreshToken(
            user_id=user.id,
            token_hash=hash_proof("refresh", token),
            token_version=user.token_version,
            expires_at=now + timedelta(days=30),
            revoked=False,
        )
    )
    return {**access(user, now), "refresh_token": token, "refresh_expires_in": 2592000}


def access(user, now):
    timestamp = int(now.replace(tzinfo=timezone.utc).timestamp())
    return {
        "access_token": create_access_token(
            {
                "sub": user.user_name,
                "user_id": user.id,
                "token_version": user.token_version,
                "iat": timestamp,
                "exp": timestamp + 3600,
                "iss": "vegent-identity",
                "aud": "vegent",
            }
        ),
        "token_type": "bearer",
        "expires_in": 3600,
    }


def revoke_user_sessions(user, *, db, clear_unlock=True):
    user.token_version += 1
    db.execute(
        update(RefreshToken).where(RefreshToken.user_id == user.id).values(revoked=True)
    )
    if clear_unlock:
        user.unlock_token_hash = None
        user.unlock_expires_at = None
        user.unlock_used_at = None


@transaction
def account_status(email, *, db):
    user = db.scalar(select(User).where(User.email == normalize_email(email)))
    if user:
        return {
            "status": (
                "not_invited"
                if not user.is_active
                else "needs_registration"
                if user.needs_registration
                else "registered"
            )
        }
    pending = db.scalar(
        select(Invitation.id)
        .join(Team)
        .where(
            Invitation.invitee_email == normalize_email(email),
            Invitation.status == "pending",
            Invitation.expires_at > utcnow(),
            Team.is_active.is_(True),
        )
        .limit(1)
    )
    return {"status": "pending_registration" if pending else "not_invited"}


@transaction
def login(email, password, *, db):
    dummy = dummy_password_hash(get_bcrypt_cost())
    user = db.scalar(
        select(User).where(User.email == normalize_email(email)).with_for_update()
    )
    if not user:
        verify_password(password, dummy)
        raise ServiceError("INVALID_CREDENTIALS", 401)
    verified = verify_password(password, user.password_hash)
    if not verified or not user.is_active or user.needs_registration:
        raise ServiceError("INVALID_CREDENTIALS", 401)
    from app.services.rate_limits import clear_login_failures

    clear_login_failures(user.email, db=db)
    write_audit(db, actor_user_id=user.id, action="login_succeeded")
    return issue_session(user, db=db, now=utcnow())


@transaction
def refresh(refresh_token, *, db):
    digest = hash_proof("refresh", refresh_token)
    uid = db.scalar(
        select(RefreshToken.user_id).where(RefreshToken.token_hash == digest)
    )
    user = (
        db.scalar(select(User).where(User.id == uid).with_for_update()) if uid else None
    )
    row = (
        db.scalar(
            select(RefreshToken)
            .where(RefreshToken.token_hash == digest)
            .with_for_update()
        )
        if user
        else None
    )
    if (
        not user
        or not row
        or row.revoked
        or row.expires_at <= utcnow()
        or row.token_version != user.token_version
        or not user.is_active
        or user.needs_registration
    ):
        raise ServiceError("INVALID_TOKEN", 401)
    return access(user, utcnow())


@transaction
def logout(actor, refresh_token, *, db):
    lock_users(db, actor.user_id)
    assert_current_actor(actor, db=db)
    row = db.scalar(
        select(RefreshToken)
        .where(
            RefreshToken.user_id == actor.user_id,
            RefreshToken.token_hash == hash_proof("refresh", refresh_token),
        )
        .with_for_update()
    )
    if row and not row.revoked:
        row.revoked = True
        write_audit(db, actor_user_id=actor.user_id, action="logout")


@transaction
def get_me(actor, *, db):
    return user_view(assert_current_actor(actor, db=db))


@transaction
def update_me(actor, changes, *, db):
    lock_users(db, actor.user_id)
    user = assert_current_actor(actor, db=db)
    fields = changes.model_dump(exclude_unset=True)
    for key, value in fields.items():
        setattr(user, key, value)
    if fields:
        write_audit(db, actor_user_id=user.id, action="profile_updated")
    return user_view(user)


@transaction
def list_users(actor, page, limit, include_inactive, search, *, db):
    require_system_admin(actor, db=db)
    q = select(User).order_by(User.created_at, User.id)
    if not include_inactive:
        q = q.where(User.is_active.is_(True))
    if search:
        q = q.where(User.email.contains(search, autoescape=True))
    return page_result([user_view(u) for u in db.scalars(q)], page, limit)


@transaction
def get_user(actor, user_id, *, db):
    require_system_admin(actor, db=db)
    user = db.get(User, user_id)
    if not user:
        raise ServiceError("NOT_FOUND", 404)
    return user_view(user)


def admin_mutation(actor, user_id, kind, value, *, db):
    guard = db.scalar(
        select(SystemConfig)
        .where(SystemConfig.config_key == "identity_admin_guard")
        .with_for_update()
    )
    if guard is None:
        raise ServiceError("SERVICE_UNAVAILABLE", 503)
    lock_users(db, actor.user_id, user_id)
    require_system_admin(actor, db=db)
    user = db.get(User, user_id)
    if not user:
        raise ServiceError("NOT_FOUND", 404)
    if kind == "is_active" and actor.user_id == user_id:
        raise ServiceError("FORBIDDEN", 403)
    if kind == "role" and not user.is_active:
        raise ServiceError("STATE_CONFLICT", 409)
    old = getattr(user, kind)
    if old == value:
        return user_view(user)
    if (
        kind in ("role", "is_active")
        and user.role == "admin"
        and db.scalar(
            select(func.count())
            .select_from(User)
            .where(User.role == "admin", User.is_active.is_(True), User.id != user_id)
        )
        == 0
    ):
        raise ServiceError("LAST_ADMIN", 409)
    teams = set(
        db.scalars(
            select(TeamMember.team_id).where(
                TeamMember.user_id == user_id, TeamMember.status == "active"
            )
        )
    )
    if kind == "email":
        teams.update(
            db.scalars(
                select(Invitation.team_id).where(
                    Invitation.invitee_email == old, Invitation.status == "pending"
                )
            )
        )
    for tid in sorted(teams):
        team = lock_team(db, tid)
        membership = db.scalar(
            select(TeamMember).where(
                TeamMember.team_id == tid,
                TeamMember.user_id == user_id,
                TeamMember.status == "active",
            )
        )
        if (
            kind == "is_active"
            and team.is_active
            and membership
            and membership.team_role == "team_admin"
            and admin_count(db, tid, exclude=user_id) == 0
        ):
            raise ServiceError("LAST_ADMIN", 409)
        if kind == "email":
            for invitation in db.scalars(
                select(Invitation)
                .where(
                    Invitation.team_id == tid,
                    Invitation.invitee_email == old,
                    Invitation.status == "pending",
                )
                .with_for_update()
            ):
                invitation.status = "revoked"
                write_audit(
                    db,
                    actor_user_id=actor.user_id,
                    action="invitation_revoked",
                    team_id=tid,
                    target_email=old,
                    resource_id=invitation.id,
                )
    setattr(user, kind, value)
    revoke_user_sessions(user, db=db)
    write_audit(
        db,
        actor_user_id=actor.user_id,
        action={
            "role": "global_role_changed",
            "email": "email_changed",
            "is_active": "user_deactivated",
        }[kind],
        target_user_id=user_id,
        detail={"old": old, "new": value},
    )
    db.flush()
    return user_view(user)


@transaction
def change_user_email(actor, user_id, email, *, db):
    return admin_mutation(actor, user_id, "email", normalize_email(email), db=db)


@transaction
def change_global_role(actor, user_id, role, *, db):
    return admin_mutation(actor, user_id, "role", role, db=db)


@transaction
def deactivate_user(actor, user_id, *, db):
    return admin_mutation(actor, user_id, "is_active", False, db=db)
