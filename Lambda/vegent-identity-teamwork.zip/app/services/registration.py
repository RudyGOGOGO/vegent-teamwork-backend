import secrets

from sqlalchemy import select

from app.core.security import (
    assert_current_actor,
    get_password_hash,
    hash_proof,
    validate_password,
    validate_verizon_email,
)
from app.models.invitation import Invitation
from app.models.team_member import TeamMember
from app.models.user import User
from app.schemas.auth import ServiceError
from app.services.auth import issue_session
from app.services.team_members import (
    active_member,
    lock_team,
    lock_users,
    member_view,
    transaction,
    utcnow,
    write_audit,
)


def validate_invitation_claim(email, team_id, invite_token, *, db, now):
    row = db.scalar(
        select(Invitation)
        .where(
            Invitation.invite_token_hash == hash_proof("invite", invite_token),
            Invitation.team_id == team_id,
        )
        .with_for_update()
    )
    if (
        not row
        or row.invitee_email != email
        or row.status != "pending"
        or row.expires_at <= now
    ):
        raise ServiceError("INVALID_INVITATION", 400)
    return row


def claim(db, row, user):
    if active_member(db, row.team_id, user.id):
        raise ServiceError("STATE_CONFLICT", 409)
    member = TeamMember(
        team_id=row.team_id,
        user_id=user.id,
        team_role=row.team_role,
        status="active",
        invited_by_user_id=row.invited_by_user_id,
        joined_at=utcnow(),
    )
    db.add(member)
    row.status = "claimed"
    row.claimed_user_id = user.id
    row.claimed_at = utcnow()
    db.flush()
    write_audit(
        db,
        actor_user_id=user.id,
        action="invitation_claimed",
        team_id=row.team_id,
        target_user_id=user.id,
        resource_id=row.id,
    )
    return member


@transaction
def register_by_invite(email, password, invite_token, *, db):
    email = validate_verizon_email(email)
    validate_password(password)
    tid = db.scalar(
        select(Invitation.team_id).where(
            Invitation.invite_token_hash == hash_proof("invite", invite_token)
        )
    )
    if not tid:
        raise ServiceError("INVALID_INVITATION", 400)
    team = lock_team(db, tid)
    if not team.is_active:
        raise ServiceError("INVALID_INVITATION", 400)
    row = validate_invitation_claim(email, tid, invite_token, db=db, now=utcnow())
    if db.scalar(select(User.id).where(User.email == email)):
        raise ServiceError("STATE_CONFLICT", 409)
    username = email.split("@")[0][:36] + "-" + secrets.token_hex(6)
    user = User(
        user_name=username,
        email=email,
        password_hash=get_password_hash(password),
        display_name=row.invitee_name,
        bio=row.invitee_bio,
        role="user",
        auth_source="password",
        is_active=True,
        needs_registration=False,
        token_version=0,
        preferences="{}",
    )
    db.add(user)
    db.flush()
    claim(db, row, user)
    write_audit(
        db,
        actor_user_id=user.id,
        action="registration_completed",
        target_user_id=user.id,
    )
    return issue_session(user, db=db, now=utcnow())


@transaction
def accept_invitation(actor, team_id, invite_token, *, db):
    lock_users(db, actor.user_id)
    user = assert_current_actor(actor, db=db)
    team = lock_team(db, team_id)
    if not team.is_active:
        raise ServiceError("FORBIDDEN", 403)
    row = validate_invitation_claim(
        user.email, team_id, invite_token, db=db, now=utcnow()
    )
    return member_view(db, claim(db, row, user))
