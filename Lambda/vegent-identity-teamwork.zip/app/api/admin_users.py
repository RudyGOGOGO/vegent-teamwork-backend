from fastapi import APIRouter, Depends, Query

from app.core.security import get_current_user
from app.db.session import get_db
from app.schemas.auth import DTO
from app.schemas.user import Actor, EmailUpdate, GlobalRoleUpdate
from app.services import auth, unlock

router = APIRouter(prefix="/api/admin/users")


@router.get("")
def list_users(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    include_inactive: bool = False,
    search: str | None = None,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return auth.list_users(actor, page, limit, include_inactive, search, db=db)


@router.get("/{user_id}")
def get_user(
    user_id: int, actor: Actor = Depends(get_current_user), db=Depends(get_db)
):
    return auth.get_user(actor, user_id, db=db)


@router.put("/{user_id}")
def update_email(
    user_id: int,
    body: EmailUpdate,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return auth.change_user_email(actor, user_id, body.email, db=db)


@router.put("/{user_id}/role")
def update_role(
    user_id: int,
    body: GlobalRoleUpdate,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return auth.change_global_role(actor, user_id, body.role, db=db)


@router.post("/{user_id}/deactivate")
def deactivate_user(
    user_id: int,
    body: DTO,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return auth.deactivate_user(actor, user_id, db=db)


@router.post("/{user_id}/unlock-registration")
def unlock_registration(
    user_id: int,
    body: DTO,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return unlock.unlock_user(actor, user_id, db=db)
