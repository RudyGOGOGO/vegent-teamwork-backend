from fastapi import APIRouter
from sqlalchemy import text

from app.core.config import get_bcrypt_cost
from app.db.session import get_session_factory

router = APIRouter()


@router.get("/api/health")
def health():
    from fastapi.responses import JSONResponse

    try:
        get_bcrypt_cost()
        with get_session_factory()() as db:
            db.execute(text("SELECT 1"))
        return {"status": "ok", "service": "vegent-identity"}
    except Exception:
        return JSONResponse({"status": "unavailable"}, status_code=503)
