from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    Computed,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR

from app.db.base import Base


class TeamMember(Base):
    __tablename__ = "team_members"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger, nullable=False)
    user_id = Column(Integer, nullable=False)
    team_role = Column(VARCHAR(20), nullable=False)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'active'"))
    invited_by_user_id = Column(Integer, nullable=False)
    joined_at = Column(DATETIME(fsp=6), nullable=False)
    removed_at = Column(DATETIME(fsp=6), nullable=True)
    removed_by_user_id = Column(Integer, nullable=True)
    active_user_id = Column(
        Integer,
        Computed(
            "CASE WHEN status='active' THEN user_id ELSE NULL END", persisted=True
        ),
        nullable=True,
    )
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    updated_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        UniqueConstraint("team_id", "active_user_id", name="uq_team_active_user"),
        Index("idx_members_team", "team_id", "status", "joined_at", "id"),
        Index("idx_members_user", "user_id", "status", "team_id"),
        Index("idx_members_inviter", "invited_by_user_id", "team_id", "user_id"),
        Index("idx_members_remover", "removed_by_user_id"),
        ForeignKeyConstraint(["team_id"], ["teams.id"], name="fk_member_team"),
        ForeignKeyConstraint(["user_id"], ["users.id"], name="fk_member_user"),
        ForeignKeyConstraint(
            ["invited_by_user_id"], ["users.id"], name="fk_member_inviter"
        ),
        ForeignKeyConstraint(
            ["removed_by_user_id"], ["users.id"], name="fk_member_remover"
        ),
        CheckConstraint(
            "team_role IN ('team_admin','team_member')", name="ck_member_role"
        ),
        CheckConstraint("status IN ('active','removed')", name="ck_member_status"),
        CheckConstraint(
            "\n    (status='active' AND removed_at IS NULL AND removed_by_user_id IS NULL) OR\n    (status='removed' AND removed_at IS NOT NULL AND removed_by_user_id IS NOT NULL)",
            name="ck_member_removed",
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
