from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import CHAR, DATETIME, VARCHAR

from app.db.base import Base


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    user_id = Column(Integer, nullable=False)
    token_hash = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=False
    )
    token_version = Column(Integer, nullable=False)
    device_id = Column(VARCHAR(100), nullable=True)
    expires_at = Column(DATETIME(fsp=6), nullable=False)
    revoked = Column(Boolean, nullable=False, server_default=text("FALSE"))
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        UniqueConstraint("token_hash", name="uq_refresh_hash"),
        Index("idx_refresh_user", "user_id", "revoked", "expires_at"),
        ForeignKeyConstraint(["user_id"], ["users.id"], name="fk_refresh_user"),
        CheckConstraint("token_version >= 0", name="ck_refresh_version"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
