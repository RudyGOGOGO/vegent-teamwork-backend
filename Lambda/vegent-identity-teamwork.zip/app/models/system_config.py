from sqlalchemy import (
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR

from app.db.base import Base


class SystemConfig(Base):
    __tablename__ = "system_configs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    config_key = Column(VARCHAR(100), nullable=False)
    config_value = Column(VARCHAR(4096), nullable=False, server_default=text("'{}'"))
    version = Column(Integer, nullable=False, server_default=text("1"))
    updated_by = Column(Integer, nullable=True)
    expires_at = Column(DATETIME(fsp=6), nullable=True)
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    updated_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        UniqueConstraint("config_key", name="uq_system_config_key"),
        Index("idx_system_config_expiry", "expires_at"),
        Index("idx_system_config_actor", "updated_by"),
        ForeignKeyConstraint(["updated_by"], ["users.id"], name="fk_config_actor"),
        CheckConstraint("JSON_VALID(config_value)", name="ck_system_config_json"),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )

    def get_json(self):
        import json

        return json.loads(self.config_value)

    def set_json(self, value):
        import json

        self.config_value = json.dumps(dict(value))
