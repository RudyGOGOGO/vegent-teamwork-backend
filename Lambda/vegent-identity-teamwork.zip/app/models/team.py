from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR

from app.db.base import Base


class Team(Base):
    __tablename__ = "teams"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    team_name = Column(VARCHAR(100), nullable=False)
    slug = Column(VARCHAR(100), nullable=False)
    description = Column(Text, nullable=True)
    created_by_user_id = Column(Integer, nullable=False)
    is_active = Column(Boolean, nullable=False, server_default=text("TRUE"))
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    updated_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        UniqueConstraint("team_name", name="uq_teams_name"),
        UniqueConstraint("slug", name="uq_teams_slug"),
        Index("idx_teams_created_by", "created_by_user_id"),
        ForeignKeyConstraint(
            ["created_by_user_id"], ["users.id"], name="fk_team_creator"
        ),
        CheckConstraint(
            "CHAR_LENGTH(TRIM(team_name)) BETWEEN 2 AND 100", name="ck_team_name"
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
