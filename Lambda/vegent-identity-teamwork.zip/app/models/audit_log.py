from sqlalchemy import (
    JSON,
    BigInteger,
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Index,
    Integer,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR

from app.db.base import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger, nullable=True)
    actor_user_id = Column(Integer, nullable=True)
    action = Column(VARCHAR(50), nullable=False)
    target_user_id = Column(Integer, nullable=True)
    target_email = Column(VARCHAR(100), nullable=True)
    resource_type = Column(VARCHAR(50), nullable=True)
    resource_id = Column(BigInteger, nullable=True)
    detail = Column(JSON, nullable=True)
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        Index("idx_audit_team", "team_id", "created_at", "id"),
        Index("idx_audit_actor", "actor_user_id", "created_at"),
        Index("idx_audit_target", "target_user_id", "created_at"),
        ForeignKeyConstraint(["team_id"], ["teams.id"], name="fk_audit_team"),
        ForeignKeyConstraint(["actor_user_id"], ["users.id"], name="fk_audit_actor"),
        ForeignKeyConstraint(["target_user_id"], ["users.id"], name="fk_audit_target"),
        CheckConstraint(
            "\n    actor_user_id IS NOT NULL OR action IN ('login_failed','auth_rate_limited')",
            name="ck_audit_actor",
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
